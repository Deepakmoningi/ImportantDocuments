﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generics
{
    // There are five types of constraints 
    // Applying constraint to interface
    // 1) where T: Icomparable
    // Applying constraint to class
    // 2) where T : Product, T can be a product or any of its children
    // Applying constraint to value type
    // 3) where T : struct
    // Applying constraint to reference type
    // 4) where T : class
    public class Utilities<T> where T : IComparable // Applied generic at class level
    {
        // Normal way to get Max value among two integers:

        //public int Max(int a,int b)
        //{
        //    return a > b ? a : b;
        //}

        // creating Generic method using constraints
        public T Max(T a,T b)
        {
            // we cant compare a with b like this a>b because at this point of time the compiler dont know about the type of a and b and during run time client(Program.cs/We) will give those types to us:
            // but we can use CompareTo() method which is present indide the Icomparable interface that is why we have implemented that interface with our class
            return a.CompareTo(b)>0 ? a : b;
        }
    }
}

﻿using Generics;

public class Program
{
    static void Main()
    {
        var myObj = new Utilities<int>(); // passing the type int so during run time it will go and replace with <T> in utilities<T>

        var res = myObj.Max(4, 5); // If we declare the generic at method level then we dont have to specify <T> while calling the Max() method, Compiler will infer the type of the <T> automatically based on the parameters passed for the Max() method.

        Console.WriteLine(res);

        // Product is a base class
        var dcObj = new DiscountCalculator<Product>(); // Creating Instance and we have to pass the class like above we passed <int>

        var result = dcObj.calculateDiscount(new Product() { Price=500,Title="Mufasa"});
        Console.WriteLine(result);

    }
}
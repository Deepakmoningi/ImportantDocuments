﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generics
{
    // Applying constraint to class
    // 2) where T : Product, T can be a product or any of its children

    // Product is a base class
    // Book is a derived
    

    // Constraint: The where TProduct : Product constraint ensures that TProduct must be a type that inherits from Product. This means TProduct can be Product itself or any derived class like Book.
    // We can pass any class here Like product or any inherited class of product like book here thats why we have to specify Product here
    public class DiscountCalculator<TProduct> where TProduct:Product
    {
        public float calculateDiscount(TProduct product)
        {
            return product.Price;
        }
    }
}

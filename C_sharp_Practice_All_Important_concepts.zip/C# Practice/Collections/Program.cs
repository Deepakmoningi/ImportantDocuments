﻿using Collections;
using System.Collections;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

public class collections
{
    
    // array: Generic
    int[] numbers = new int[] { 1, 2, 3, 4, 5, 6 };
    
    // arrayList: Non generic
    ArrayList myArrayList = new ArrayList()
    {
       1, "Deepak",22.11
    };

    // List : Generic
    List<string> myList = new List<string>()
    {
        "Deepak", "Moningi"
    };

    // Hash table: Non generic

    Hashtable ht = new Hashtable()
    {
        {1,"Deepak"},
        {"two","Mani" },
        {"three","Kumar" },
        {4,7.0}
    };

    // Dictionary: Generic

    Dictionary<int, string> myDictionary = new Dictionary<int, string>()
    {
        {1,"Deepak" },
        {2,"Moningi" }
    };

    // student class

    List<Student> studentList = new List<Student>()
    {
        new Student()
        {
            Id = 1,
            Name="Deepak",
            RollNo=1,
            Address="Tekkali"
        },

        new Student(){
             Id = 2,
            Name="Raju",
            RollNo=2,
            Address="SKLM"
        }
    };

    public void testMethod()
    {
        Student studObj = new Student()
        {
            Id = 1,
            Name = "Deepak",
            RollNo = 1,
            Address = "TKL"
        };
        Student studObj1 = new Student()
        {
            Id = 2,
            Name = "varma",
            RollNo = 2,
            Address = "TKL"
        };
    }

    List<Student> myStudents = new List<Student>();
    

    public void printArray()
    {
        foreach(var number in numbers)
        {
            Console.WriteLine(number);
        }
    }

    public void printArrayList()
    {
        foreach (var thing in myArrayList)
        {
            Console.WriteLine(thing);
        }
    }

    public void printList()
    {
        foreach (var text in myList)
        {
            Console.WriteLine(text);
        }
        
    }

    public void printHashTable()
    {
        foreach (DictionaryEntry item in ht)
        {
            Console.WriteLine("Key {0}, value {1}", item.Key, item.Value);
        }
    }

    public void printDictionary()
    {
        foreach (var item in myDictionary)
        {
            Console.WriteLine("Key {0}, value {1}", item.Key, item.Value);
        }
    }

    public static void printstudentList()
    {
        var studentObj = new collections(); // here collections is a class

        foreach (var student in studentObj.studentList)
        {
            Console.WriteLine(student.Name);
        }
    }

    

    static void Main()
    {
        collections cObj = new collections();
        cObj.printArray();
        cObj.printArrayList();
        cObj.printList();
        cObj.printHashTable();
        cObj.printDictionary();
        //cObj.printstudentList();
        collections.printstudentList();

    }
}
﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");

using oopsRealTime;
using static oopsRealTime.inheritance;

namespace oopsPrinciples
{
    class oopsPractice
    {
        static void Main()
        {
            // Encapsulation
            encapsulation encapsulationObj=new encapsulation();

            Console.WriteLine(encapsulationObj.DepositAmount(500));

            Console.WriteLine(encapsulationObj.withDrawAmount(200));

            encapsulationObj.AccessUsername = "Varun"; // setting/ modifying the username

            Console.WriteLine(encapsulationObj.AccessUsername); // accessing/getting the username // Varun // w/o 20 line it will log "Simham"

            // single Inheritance

            PermanentEmployee pEmpObj = new PermanentEmployee();
            pEmpObj.getSalary(); // 10000

            // multi level inheritance

            GrandParent childObj= new Child();

            childObj.Greet();// expected o/p: greetings from child, but actual o/p: greetings from grandparent

            // to over come this we need to use new keyword to hide the base class greet method or override the base class method using virtual keyword in base class and override keyword in derived class


            // after using virtual in base class and override in derived class :
            GrandParent childObj1 = new Child(); // now the output will be : greetings from child only because we are overiding

            childObj1.Greet();
            // Even though we are using parent reference(left side) but while run time the compiler will check what is the actual object which is on right side,
            // if the right side class object is childs object then it will override the base class method only when we use virtual in base class method and override in derived/ child class method
            // this  is what [method overriding] which is run time polymorphism.

            Parent parentObj= new Parent();
            parentObj.Greet(); // Greertings from grand Parent (GP)
            parentObj.Wish(); // Parent's wish (P)
            parentObj.work(); // Retired (GP)
            parentObj.onlyGrandParent(); // Only grand parent(GP)

            Console.WriteLine("Test here:");
            Child cObj = new Child();
            cObj.work(); // studying and playing (C)

            // heirarichal inheritance

            Animal animalObj= new Animal();//Animal method (Base class)

            Animal pigObject = new Pig();//Pig method (derived class 1)
                
            Animal dogObject = new Dog();//Dog Method (derived class 2)

            animalObj.animalSound();

            pigObject.animalSound();

            dogObject.animalSound(); // this is  called as method over riding
            // here also on the left side the reference is a base class but while the run time it will see for right side which is a actual object.
            // this will only happen(overriding) when we add virtual and override keywords to our methods


            // interfaces and multiple inheritance

            AB ab =new AB();
            ab.printBase1();
            ab.printBase2();

        }

    }

    
}



﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopsRealTime
{
    //single inheritance
    //Inheritance will create a Parent-child relationship between two classes,
    //where child class will automatically get the properties and methods of the parent to child
    // Why inheritance:
    // it is required for reusability and abstraction of code
    // using one method in two different places
    internal class inheritance
    {
        public class Employee
        {
            public int Id { get; set; }

            public void getSalary()
            {
                int salary =10000;
                Console.WriteLine("Salary{0}",salary);
            }
        }

        public class PermanentEmployee:Employee
        {
            // no methods here
        }

      
    }
}

﻿using oopsPrinciples;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopsRealTime
{
    // Encapsulation means wrapping of data and methods into a single unit
    // Why encapsulation: for security here we don't want to show the balance so we marked it as private 
    // but we need to access it for that we can use the below public methods to deposit and withdraw amount like bank

    // with this no one can access the balance variable directly without the methods

    // The meaning of Encapsulation, is to make sure that "sensitive" data is hidden from users.To achieve this, you must:

    // declare fields/ variables as private  
    // provide public get and set methods, through properties, to access and update the value of a private field

    class encapsulation
    {
        private float balance; // data

        public string withDrawAmount(int amount)// function/method
        {
            balance = balance - amount;

            string strAmount = amount.ToString();

            Console.WriteLine(balance);

            return strAmount + " rupees Withdraw Successful";


        }


        public string DepositAmount(int amount)
        {
            balance = balance + amount;

            string strAmount = amount.ToString();

            Console.WriteLine(balance);

            return strAmount + " rupees Deposit Successful";

        }

        private string UserName="Simham"; // field

        public string AccessUsername // property
        {
            get
            {
                return UserName;
            }

            set
            {
                UserName = value;
            }

            // here get and set are methods 
        }

        // public string AccessUsername { get; set; } // this is short hand syntax for the property, with this we can restrict the get/read and set/write methods


        // if we want to restrict the write/modification of our private UserName field then we can remove the set {} method inside the AccessUserName property
        // this is the main usage of encapsulation in C# here only the data(fields) and methods(property) will work as a single unit.
    }
}

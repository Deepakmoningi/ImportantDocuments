﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopsRealTime
{
    //public class Base1
    //{
    //    public void printMessage()
    //    {
    //        Console.WriteLine("Hello from Base1");
    //    }
    //}

    //public class Base2
    //{
    //    public void printMessage()
    //    {
    //        Console.WriteLine("Hello from Base2");
    //    }
    //}

    //public class derived : Base1, Base2
    //{

    //}

    // if we write the code like above c# will give error: Class 'class' cannot have multiple base classes: 'class_1' and 'class_2'
    // because c# don't support multiple inheritance because it will confuse to use which class
    // c# class can inherit atmost one base class only



    // kud venkat's example
    // Replaced the classes with the interfaces:
    interface IBase1
    {
        void printBase1();
    }

    interface IBase2
    {
        void printBase2();
    }

    //public class DerivedA : IBase1
    //{
    //    public void printBase1()
    //    {
    //        Console.WriteLine("Hello from Base1");
    //    }
    //}

    //public class DerivedB : IBase2
    //{
    //    public void printBase2()
    //    {
    //        Console.WriteLine("Hello from Base2");
    //    }
    //}

    // This AB class has a capabalities of both DerivedA and DerivedB classes
    public class AB : IBase1, IBase2
    {
        //DerivedA DA = new DerivedA();
        //DerivedB DB = new DerivedB();
        public void printBase1()
        {
           // DA.printBase1();
           Console.WriteLine("Hello from Base1");
        }

        public void printBase2()
        {
           // DB.printBase2();
           Console.WriteLine("Hello from Base2");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopsRealTime
{
    public class GrandParent
    {
        public virtual void Greet()
        {
            Console.WriteLine("Greertings from grand Parent");
        }

        public void work()
        {
            Console.WriteLine("Retired");
        }

        public void onlyGrandParent()
        {
            Console.WriteLine("Only grand parent");
        }
    }

    public class Parent : GrandParent
    {
        public void Wish()
        {
            Console.WriteLine("Parent's wish");
        }

    }

    public class Child : Parent
    {
        public void work()
        {
            Console.WriteLine("studying and playing");
        }

        public override void Greet() // overriding the grand parents Greet() method.
        {
            Console.WriteLine("Greertings from child");

        }

        public void onlyChild()
        {
            Console.WriteLine("This is only for child");
        }

    }
}


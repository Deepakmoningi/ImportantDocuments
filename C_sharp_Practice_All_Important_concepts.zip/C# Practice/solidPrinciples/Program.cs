﻿namespace solidPrinciples
{
    class Program
    {
        static void Main()
        {

            Account acc = new Account();
            acc.Name = "Deepak";
            acc.Address = "tekkali";
            acc.balance = 29000;

            savingsAccount sobj = new savingsAccount();

            otherAccount oObj = new otherAccount();

            CurrentAccount cObj = new CurrentAccount();

            sobj.caluclateintrest(acc);

            oObj.caluclateintrest(acc);

            cObj.caluclateintrest(acc);


            List<Account> accountDetails = new List<Account>()
            {
            new Account{Name="Deepak", Address="tekkali", balance=100},
            new Account{Name="Raju", Address="Srikakulam", balance=50},
            };

            foreach(Account account in accountDetails)
            {
                Console.WriteLine($"Name: {account.Name} and Address : {account.Address}");
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace solidPrinciples
{
    public class savingsAccount : IAccount
    {
        public void caluclateintrest(Account accountObj)
        {
            Console.WriteLine( accountObj.balance * 0.5);
        }
    }

    public class otherAccount : IAccount
    {
        public void caluclateintrest(Account accountObj)
        {
            Console.WriteLine(accountObj.balance * 0.90);

        }
    }

    public class CurrentAccount : IAccount
    {
        public void caluclateintrest(Account accountObj)
        {
            Console.WriteLine(accountObj.balance * 0.7);

        }
    }




}

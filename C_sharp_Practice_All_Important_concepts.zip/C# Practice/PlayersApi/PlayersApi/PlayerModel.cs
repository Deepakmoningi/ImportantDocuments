﻿using System.ComponentModel.DataAnnotations;

namespace PlayersApi
{
    public class PlayerModel
    {
        [Key]
        public int Player_Id { get; set; }

        public string? Player_Name { get; set; }

        public string? Role { get; set; }

        public bool In_Team { get; set; }
    }
}

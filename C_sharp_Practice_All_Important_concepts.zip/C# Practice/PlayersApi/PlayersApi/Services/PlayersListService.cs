﻿namespace PlayersApi.Services
{
    public class PlayersListService
    {
        List<PlayerModel> dataList = new List<PlayerModel>()
        {
            new PlayerModel
            {
                Player_Id = 7,
                Player_Name = "DHONI",
                Role = "C",
                In_Team = true
            },

            new PlayerModel
            {
                Player_Id= 10,
                Player_Name = "Sachin",
                Role = "X",
                In_Team = false
            },

            new PlayerModel
            {
                Player_Id= 45,
                Player_Name = "RO",
                Role = "VC",
                In_Team = true,
            }
        };

        public void AddPlayer(PlayerModel pObj)
        {
            dataList.Add(pObj); // create
        }

        public List<PlayerModel> getAllPlayers()
        {
            return dataList; // read
        }

        public PlayerModel getPlayerById(int id)
        {
            var player = dataList.Find(p => p.Player_Id == id); // read

            //var playerList = new List<PlayerModel>()
            //{
            //    new PlayerModel()
            //    {
            //        Player_Id = player.Player_Id,
            //        Player_Name = player.Player_Name,
            //        Role = player.Role,
            //        In_Team = player.In_Team,
            //    }
            //};

            return player;

        }

        public void updatePlayer(PlayerModel pObj)
        {
            var player = dataList.Find(p => p.Player_Id == pObj.Player_Id); // update

            player.Player_Id = pObj.Player_Id;
            player.Player_Name = pObj.Player_Name;
            player.Role = pObj.Role;
            player.In_Team = pObj.In_Team;
        }

        public void deletePlayer(int id)
        {
            var player = dataList.Find(p => p.Player_Id == id); 

            dataList.Remove(player); //  delete


        }

        public List<PlayerModel> getInTeamPlayers()
        {
            return dataList.Where(p => p.In_Team == true).ToList(); // read with a filter
        }


    }
}

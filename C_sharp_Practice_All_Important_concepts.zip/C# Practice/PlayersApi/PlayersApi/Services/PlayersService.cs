﻿namespace PlayersApi.Services
{
    public class PlayersService
    {
       
            List<PlayerModel> playersList = new List<PlayerModel>()
            {
                new PlayerModel()
                {
                    Player_Id = 1,
                    Player_Name = "Deepak",
                    Role = "AR",
                    In_Team = true
                },
                new PlayerModel()
                {
                    Player_Id = 2,
                    Player_Name = "Nani",
                    Role = "B",
                    In_Team = true
                }
            };

            //return playersList;

       
        
    }
}

﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PlayersApi.Services;

namespace PlayersApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PlayersListController : ControllerBase
    {
        private readonly PlayersListService _service;
        public PlayersListController(PlayersListService service)
        {
            _service = service;
        }

        
    }
}

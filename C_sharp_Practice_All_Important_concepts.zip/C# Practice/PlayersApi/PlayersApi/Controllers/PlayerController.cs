﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PlayersApi.Services;

namespace PlayersApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PlayerController : ControllerBase
    {
        private PlayerContext _context;
        private PlayersListService _PSService;

        public PlayerController(PlayerContext context, PlayersListService PSService)
        {
            _context = context;
            _PSService = PSService;
        }

        [HttpPost("AddPlayer")]
        public IActionResult AddPlayer(PlayerModel obj)
        {
            _context.PlayerModels.Add(obj);
            _context.SaveChanges();

            return Ok(new { message = "Player Added" });
        }

        [HttpGet("getAllPlayers")]
        public IActionResult getAllPlayers()
        {
            return Ok(new { playersData = _context.PlayerModels.ToList() });
        }

        [HttpGet("getPlayerDataById/{Id}")]
        public IActionResult getPlayerDataById(int Id)
        {
            return Ok(new { id = _context.PlayerModels.Where(p => p.Player_Id == Id).FirstOrDefault() });
        }

        [HttpPut("updatePlayer")]
        public IActionResult updatePlayerById([FromBody] PlayerModel pObj)
        {
            var player = _context.PlayerModels.Find(pObj.Player_Id);

            if (player != null)
            {
                player.Player_Id = pObj.Player_Id;
                player.Player_Name = pObj.Player_Name;
                player.Role = pObj.Role;
                player.In_Team = pObj.In_Team;

                _context.PlayerModels.Update(player);
                _context.SaveChanges();
                return Ok(new
                {
                    message = " Updated succesfully"
                });
            }
            else
            {
                return BadRequest();
            }
        }

        [HttpDelete("DeletePlayer/{id}")]
        public async Task<IActionResult> deletePlayer(int id)
        {
            var player = await _context.PlayerModels.Where(p => p.Player_Id == id).FirstOrDefaultAsync();

            if(player != null)
            {
                 _context.PlayerModels.Remove(player);
                await _context.SaveChangesAsync();

                return Ok(new
                {
                    message = "deleted"
                });
            }
            else
            {
                return BadRequest();
            }
        }

       
        // by using in memory data base (Lists)
        [HttpPost("AddDataToList")]
        public IActionResult AddPlayerToList(PlayerModel playerObj)
        {
            _PSService.AddPlayer(playerObj);
            return Ok(new { msg = " player added" });
        }

        [HttpGet("getAllPlayersFromList")]
        public IActionResult getAllPlayersList()
        {
            var result = _PSService.getAllPlayers();
            return Ok(result);
        }

        [HttpGet("getPlayersByIdFromList/{id}")]
        public IActionResult getPlayerByIDFroList(int id)
        {
           var result =  _PSService.getPlayerById(id);
            return Ok(result);
        }

        [HttpPut("UpdatePlayerInList")]
        public IActionResult updatePlayersinList(PlayerModel pObj)
        {
            _PSService.updatePlayer(pObj);
            return Ok(new
            {
                message = "updated"
            });
        }

        [HttpDelete("DeleteplayerFromList/{id}")]
        public IActionResult deletePlayerFromList(int id)
        {
            _PSService.deletePlayer(id);
            return Ok(new { message = "deleted successfullyy" });
        }

        [HttpGet("squadmemners")]
        public IActionResult getSquad()
        {
           var result =  _PSService.getInTeamPlayers();
            return Ok(result);
        }


    }
}

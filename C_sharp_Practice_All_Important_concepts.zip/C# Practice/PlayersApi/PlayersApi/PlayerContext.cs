﻿using Microsoft.EntityFrameworkCore;

namespace PlayersApi
{
    public class PlayerContext : DbContext
    {
        public PlayerContext(DbContextOptions<PlayerContext> options) :base(options)
        {

        }
        public DbSet<PlayerModel> PlayerModels { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<PlayerModel>().ToTable("Players");
        }
        
    }
}

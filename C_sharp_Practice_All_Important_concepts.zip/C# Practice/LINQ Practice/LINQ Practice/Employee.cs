﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ_Practice
{
    public class Employee
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Department { get; set; }
        public int Age { get; set; }
        public double Salary { get; set; }
        public string? Gender { get; set; }


        public List<Employee> EmployeesList()
        {
            var employees = new List<Employee>()
            {
                new Employee { Id = 1, Name = "Alice", Department = "HR", Age = 30, Salary = 60000, Gender = "Female" },
                new Employee { Id = 2, Name = "Bob", Department = "IT", Age = 25, Salary = 70000, Gender = "Male" },
                new Employee { Id = 3, Name = "Charlie", Department = "Finance", Age = 35, Salary = 80000, Gender = "Male" },
                new Employee { Id = 4, Name = "David", Department = "IT", Age = 28, Salary = 75000, Gender = "Male" },
                new Employee { Id = 5, Name = "Eve", Department = "HR", Age = 32, Salary = 65000, Gender = "Female" },
                new Employee { Id = 6, Name = "Frank", Department = "Finance", Age = 45, Salary = 90000, Gender = "Male" },
                new Employee { Id = 7, Name = "Grace", Department = "IT", Age = 29, Salary = 72000, Gender = "Female" },
                new Employee { Id = 8, Name = "Hannah", Department = "HR", Age = 26, Salary = 58000, Gender = "Female" },
                new Employee { Id = 9, Name = "Ivy", Department = "Finance", Age = 38, Salary = 85000, Gender = "Female" },
                new Employee { Id = 10, Name = "Jack", Department = "IT", Age = 31, Salary = 78000, Gender = "Male" }

            };

            return employees;
        }
    }
}

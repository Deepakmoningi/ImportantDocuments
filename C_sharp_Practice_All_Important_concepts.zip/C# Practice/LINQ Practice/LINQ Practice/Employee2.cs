﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ_Practice
{
    public class Employee2
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string JobTitle { get; set; }
        public string Department { get; set; }
        public decimal Salary { get; set; }
        public DateTime HireDate { get; set; }
        public string Gender { get; set; }
        public List<string> Skills { get; set; }
        public DateTime DateOfBirth { get; set; }


        public List<Employee2> getEmployeesData()
        {
            var employees = new List<Employee2>()
            {
                new Employee2 { Id = 1, FirstName = "John", LastName = "Smith", JobTitle = "Manager", Department = "IT", Salary = 75000, HireDate = new DateTime(2018, 5, 1), Gender = "Male", Skills = new List<string> { "C#", "SQL" }, DateOfBirth = new DateTime(1985, 3, 15) },
                new Employee2 { Id = 2, FirstName = "Jane", LastName = "Doe", JobTitle = "Developer", Department = "IT", Salary = 85000, HireDate = new DateTime(2019, 7, 23), Gender = "Female", Skills = new List<string> { "Java", "Angular" }, DateOfBirth = new DateTime(1990, 6, 20) },
                new Employee2 { Id = 3, FirstName = "Alice", LastName = "Johnson", JobTitle = "Analyst", Department = "Finance", Salary = 65000, HireDate = new DateTime(2021, 1, 10), Gender = "Female", Skills = new List<string> { "Excel", "Financial Analysis" }, DateOfBirth = new DateTime(1992, 11, 5) },
                new Employee2 { Id = 4, FirstName = "Bob", LastName = "Brown", JobTitle = "HR Specialist", Department = "HR", Salary = 55000, HireDate = new DateTime(2016, 3, 15), Gender = "Male", Skills = new List<string> { "Recruitment", "Employee Relations" }, DateOfBirth = new DateTime(1988, 9, 25) },
            };

            return employees;
        }

        // converting the object to a string representation
        // we know that every type in dot net framework will inherits the base sytem.object class directly or indirectly
        // so the system.object class have the tostring method this method will invoke automatically when we try to convert the object to string
        // so at that time we can override the tostring method and we can provide our implementation.
        // this will be called instead of calling the base class method

        // If we don't override the ToString() method, the default implementation from the System.Object class will be used.
        // The default ToString() method returns the fully qualified name of the object's type. 
        // eg: Namespace.Classname will log if we do the console.writeline for the object
        // In our case: LINQ_Practice.Employee2 will gets logged if we don't override the ToString() method and log any object that related to Employee2 class.


        public override string ToString()
        {
            return $"Id: {Id}, Name: {FirstName} {LastName}, Job Title: {JobTitle}, Department: {Department}, Salary: {Salary}, Hire Date: {HireDate:yyyy/MM/dd}, Gender: {Gender}, Skills: {string.Join(", ", Skills)}, Date of Birth: {DateOfBirth:yyyy/MM/dd}";
        }
    }



}

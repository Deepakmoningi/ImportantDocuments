﻿using LINQ_Practice;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Xml.Linq;

public class Program
{
    static void Main()
    {
        var empObj = new Employee();
        var emp2Obj = new Employee2();
        var EmployeesList = empObj.EmployeesList();
        var SecondEmployeeList = emp2Obj.getEmployeesData();

        // LINQ Questions:

        // Filter employees by department: Retrieve all employees who work in the “IT” department.

        Console.WriteLine("Employees working in IT dept:");

        var ITEmployees = EmployeesList.Where(emp => emp.Department == "IT");

        // query like syntax:

        var ITdeptEmployees = from emp in EmployeesList
                              where emp.Department == "IT"
                              select emp;

        // both lambda like syntax code and query like syntax code will gives us the same output.

        foreach (var emp in ITEmployees)// lambda
        {
            Console.WriteLine(emp.Name);
        }

        Console.WriteLine();


        // Sort employees by age: Get a list of employees sorted by age in ascending order.

        Console.WriteLine("Employees sorted by age:");

        var SortedEmployees = EmployeesList.OrderBy(emp => emp.Age);

        foreach (var emp in SortedEmployees)
        {
            Console.WriteLine($"Employee Name - {emp.Name} : Age - {emp.Age}");
        }

        Console.WriteLine();

        // Select specific fields: Create a list of anonymous types containing only the Name and Salary of each employee.
        Console.WriteLine("Creating anonymous type:");

        var FilteredEmployees = EmployeesList.Select(emp => new { Name = emp.Name, salary = emp.Salary });

        foreach (var emp in FilteredEmployees)
        {
            Console.WriteLine("Employee Name : {0} - Employee salary : {1}", emp.Name, emp.salary);
        }

        Console.WriteLine();

        //Find the highest salary: Retrieve the employee with the highest salary.
        Console.WriteLine("Highest salary:");

        var HighestSalary = EmployeesList.Max(emp => emp.Salary);

        Console.WriteLine($"Highest salary - {HighestSalary}");

        Console.WriteLine();

        // find the second highest salary:

        Console.WriteLine("Second highest salary:");

        var Emp = EmployeesList.OrderByDescending(emp => emp.Salary).Skip(1).First();

        Console.WriteLine($"Second highest salary: {Emp.Salary}");

        Console.WriteLine();
        // Calculate average salary: Calculate the average salary of all employees.

        Console.WriteLine("average salary of all employees");
        var averagesalary = EmployeesList.Average(emp => emp.Salary);
        Console.WriteLine($"Average salary - {averagesalary}");

        Console.WriteLine();

        //Filter by age and gender: Retrieve all male employees who are older than 30.
        Console.WriteLine("filtering with conditions male emp's with age > 30");

        var Empres = EmployeesList.Where(emp => emp.Gender == "Male" && emp.Age > 30);

        foreach (var emp in Empres)
        {
            Console.WriteLine($"Employee - {emp.Name} employee age - {emp.Age}");
        }

        Console.WriteLine();

        //Check if any employee is in a specific department: Check if there are any employees in the “Marketing” department.

        Console.WriteLine("employees in marketing dept");

        var employeesInmarketingDept = EmployeesList.Any(emp => emp.Department == "Marketing");

        if (employeesInmarketingDept)
        {
            Console.WriteLine("yes we have Markeitng employees");
        }
        else
        {
            Console.WriteLine("We dont have marketing employees");
        }
        Console.WriteLine();

        //Get the first employee in a department: Retrieve the first employee in the “HR” department.
        Console.WriteLine("first employee in HR dept");

        var firstEmp = EmployeesList.Where(emp => emp.Department == "HR").FirstOrDefault();

        Console.WriteLine($"First employee in HR department: {firstEmp?.Name}");

        Console.WriteLine();

        //Find employees with a specific name pattern: Retrieve all employees whose names start with the letter ‘A

        Console.WriteLine("employee names starts with A");
        var AEmployees = EmployeesList.Where(emp => emp.Name.StartsWith('A'));

        foreach (var emp in AEmployees)
        {
            Console.WriteLine($"Employee name: {emp.Name}");
        }

        Console.WriteLine();

        // Group employees by department: Group employees by their department and count the number of employees in each department.
        Console.WriteLine("Grouping the emp's by dept");
        var groupedEmps = EmployeesList.GroupBy(emp => emp.Department).Select(group => new { Department = group.Key, Count = group.GroupBy(emp => emp.Gender).Select(g => new {Gender = g.Key, Count = g.Count()}), MaxSalary = group.Max(emp => emp.Salary) });

        // we can't directly write Count = group.Count(emp => emp.Gender) in the same way as MaxSalary = group.Max(emp => emp.Salary) is because Count doesn't take a predicate like Max does.

        // The Count method simply counts the number of elements in the collection, whereas Max can take a selector function to determine the maximum value based on a specific property (Copilot).


        foreach (var emp in groupedEmps)
        {
            Console.WriteLine($"Employee Department: {emp.Department}, no.of employees: {emp.Count}, max salary: {emp.MaxSalary}");
        }

        Console.WriteLine();

        // Find employees with a specific salary range: Retrieve all employees with a salary between 50,000 and 100,000.

        Console.WriteLine("Employees salary 50k- 1L");

        var Employees = EmployeesList.Where(emp => emp.Salary >= 50000 && emp.Salary <= 100000);
        foreach (var emp in Employees)
        {
            Console.WriteLine($"Employee name: {emp.Name}, Salary: {emp.Salary}");
        }

        Console.WriteLine();

        // Sort employees by name: Get a list of employees sorted by name in alphabetical order.
        Console.WriteLine("Employees sort by name");

        var EmployeesByNameAsc = EmployeesList.OrderBy(emp => emp.Name);
        
        foreach (var emp in EmployeesByNameAsc)
        {
            Console.WriteLine(emp.Name);
        }

        Console.WriteLine();
        //Calculate total salary: Calculate the total salary of all employees.

        Console.WriteLine("Total salary of all emps");

        var totalSalary = EmployeesList.Sum(emp => emp.Salary);

        Console.WriteLine($"Sum of all salaries {totalSalary}");

        Console.WriteLine();

        // Find the youngest employee: Retrieve the youngest employee.
        Console.WriteLine("youngest employee");

        var youngEmp = EmployeesList.OrderBy(emp => emp.Age).FirstOrDefault();

        Console.WriteLine($"yongest employee: Employee Name {youngEmp?.Name}, his age {youngEmp?.Age}");

        Console.WriteLine();

        // Count employees by gender: Count the number of male and female employees.

        Console.WriteLine("No.of employees by gender");

        var Empsbygender = EmployeesList.GroupBy(emp => emp.Gender).Select(group => new { Department = group.Key, count = group.Count() });

        foreach(var emp in Empsbygender)
        {
            Console.WriteLine($"Department - {emp.Department}, count - {emp.count}");
        }

        Console.WriteLine();

        // Find employees with a specific department and salary range:
        // Retrieve all employees who are in the “IT” department and have a salary between 40,000 and 80,000.
        Console.WriteLine("emps from it with spec salary");
        var itEmployees = EmployeesList.Where(emp => emp.Department == "IT" && (emp.Salary >= 40000 && emp.Salary <= 80000));
        foreach(var emp in itEmployees)
        {
            Console.WriteLine($"Name - {emp.Name}, salary - {emp.Salary}");
        }



        // working with seperate list as dates are involved:
        Console.WriteLine();

        // Find employees hired after a specific date: Retrieve all employees hired after January 1, 2020.

        Console.WriteLine("Employees hired after 2020");

        var hiredEmployees = SecondEmployeeList.Where(emp => emp.HireDate > new DateTime(2020, 1, 1));

        foreach(var emp in hiredEmployees)
        {
            Console.WriteLine($"Name - {emp.FirstName} Hired on - {emp.HireDate:yyyy/MM/d}");
        }

        Console.WriteLine();
        // Find employees with a specific length of service: Retrieve all employees who have been with the company for more than 5 years.
        Console.WriteLine("Employees working more than five years");

        var fiveYearsAgo = DateTime.Now.AddYears(-5); // 2020;

        var fiveyearsexpemployees = SecondEmployeeList.Where(emp => emp.HireDate<=fiveYearsAgo);

        foreach(var emp in fiveyearsexpemployees)
        {
            Console.WriteLine($"Name - {emp.FirstName} Hired on - {emp.HireDate:yyyy/MM/d}");
        }

        Console.WriteLine();

        // Find employees with a specific hire date range: Retrieve all employees hired between January 1, 2015, and December 31, 2020.
        Console.WriteLine("Emps hired between specific years");

        var employeesHiredInRange = SecondEmployeeList.Where(emp => emp.HireDate >= new DateTime(2015, 1, 1) && emp.HireDate <= new DateTime(2020, 12, 31));

        foreach(var emp in employeesHiredInRange)
        {
            Console.WriteLine($"Name - {emp.FirstName} Hired on - {emp.HireDate:yyyy/MM/d}");
        }

        Console.WriteLine();

        //Find employees with a specific department and hire date:

        //Retrieve all employees who are in the “Finance” department and were hired after January 1, 2018.

        Console.WriteLine("Emps from finance and hired after 18");

        var empfromFin = SecondEmployeeList.Where(emp => emp.Department == "Finance" && emp.HireDate > new DateTime(2018, 1, 1));

        foreach (var emp in empfromFin)
        {
            Console.WriteLine($"Name - {emp.FirstName}, Department - {emp.Department}, Hired on - {emp.HireDate:yyyy/MM/d}");
        }


        Console.WriteLine();
        // Find employees with a specific skill: Retrieve all employees who have a specific skill (e.g., “C#”).

        Console.WriteLine("Employees having c# skill");

        var CsharpEmployees = SecondEmployeeList.Where(emp => emp.Skills.Contains("C#")).ToList();

        foreach(var emp in CsharpEmployees)
        {
            // inside the emp object skills is a list now and using join() converting all the list items to a single string eg: C#,Angular,.NET...
            Console.WriteLine($"Employee Name - {emp.FirstName} and skills - {string.Join(',',emp.Skills)}");

            // Console.WriteLine(emp); 
            // here we are trying to convert the each emp object in CsharpEmployees source list to string representation
            // this will log the entire object as we overrided the tostring() method in Employee2.cs class, refer the tostring() method there
        }

        Console.WriteLine(); // for line break

        //Find employees with a specific department and skill:
        //Retrieve all employees who are in the “HR” department and have the skill “Recruitment”.

        Console.WriteLine("Emp in HR dept and and a recruiter");

        var HREmps = SecondEmployeeList.Where(emp => emp.Department == "HR" && emp.Skills.Contains("Recruitment"));

        foreach(var emp in HREmps)
        {
            Console.WriteLine($"Employee name - {emp.FirstName} and his skills - {string.Join(',',emp.Skills)}, department - {emp.Department}");
        }


        // Functional delegate
        Func<decimal, bool> isEven = (num) => { return num % 2 == 0; }; // It is a Functional delegate, acts like an call back because we are using this function as a target function for each element inside the predicate in where condition.

        var EvenSalaries = SecondEmployeeList.Where(emp => isEven(emp.Salary));

        // Joins
    }

}
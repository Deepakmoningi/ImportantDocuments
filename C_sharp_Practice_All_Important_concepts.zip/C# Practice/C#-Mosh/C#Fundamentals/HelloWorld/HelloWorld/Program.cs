﻿using HelloWorld;
using System.Security.Cryptography;
using System.Text;
using System.Xml.Linq;

// Enums are nothing but types, if we have group of related constants then declare and use enums
// As the enus is a type we have to declare the enum at namespace level before program class itself.
public enum ShippingMethod
{
    RegularAirMail = 1,
    RegisterAirMail = 2,
    Express = 3
}

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Hello World"); // Hello World

        // Format string:
        // Here the format string is "{0} {1}"  and the values for this format string is byte.minValue and byte.MaxValue:
        Console.WriteLine("String Formatting/ Format string: ");
        Console.WriteLine("{0} {1}", byte.MinValue,byte.MaxValue); // 0 255

        // Type conversion:
        Console.WriteLine("Implicit and Explicit type conversions:");
        Console.WriteLine("Implicit type conversion:");
        byte b = 1;
        int i = b;
        // Here byte will take 1 byte and int can take 4 bytes, so byte can be fit in the integer 32
        // so, here no data loss will happen
        Console.WriteLine(i); // 1
        // But if we reverse this:
        // If we want to store a int which will take 4 bytes inside a byte which is taking one byte.
        // this is not possible in C#, C# compiler will give compile time error to us because we are trying to store higher level data type(int) value inisde a lower level data type(byte).
        // C# compiler is warning us with a compilation error: If you do like this data loss will be happen for your variable.
        // because we are storing a int in the byte
        // for this we can use the explicit casting, if we want, if we are ready for the data loss then we can use this and store our int data into the byte data.
        Console.WriteLine("Explicit type conversion:");
        int i1 = 1;
        byte b1 = (byte) i1; // cast : explicitly converting the datatype of a variable and storing in it.
        // here we casted integer to a byte, but here the data loss will not happen.
        // because the maximum value we can store in a byte is 255,
        // so as long as the int variable value is less than or equal to 255 the type conversion won't have any data loss.
        Console.WriteLine(b1); // 1

        // Explicit cast with Data loss example:
        Console.WriteLine("Explicit conversion with data loss:");
        int i2 = 1000;
        byte b2 = (byte)i2;
        Console.WriteLine(b2); // 232
        // as the output is 232, we can see from 1000 to 232, there is a data loss.
        // this is why c# compiler is warning us before the type conversion

        // Uncompatable conversion:
        Console.WriteLine("Uncompatable conversions:");
        // Sometime the explicit cast wont work as we expected at that time we have to use the Convert class
        // mostly string to int:

        //string number = "12345";
        //int num = (int)number; // Here we can't convert the string to integer using the explicit casting, but we can convert like what we need using the convert class provided by .net framework

        // try/catch is optional

        try
        {
            string number = "12345";
            int num = Convert.ToInt32(number);
            Console.WriteLine(num); // Now, 12345 is an integer because we converted.
            byte bnum = Convert.ToByte(number); // Over Flow Exception will come(because byte cant store 12345 as byte have less storage(1 byte)), for this only we wrote try catch to do not stop the program
            Console.WriteLine(bnum);
        }
        catch (Exception)
        {
            Console.WriteLine("Cannot convert from string(12345) to byte(12345) as there is no much space for byte datatype bnum"); // line number 71
        }

        // Operators: 
        Console.WriteLine("Operators:");
        var a = 10;
        var b3 = 3;

        Console.WriteLine(a/b3); // 3
        // while we dividing two integers in c#, it will give us the quotient
        // here we get the output 3, because we are dividing two integers right, so c# will return the int only

        // If we explicitly want the float then we have to use the explicitly cast the variables:
        Console.WriteLine((float)a/(float)b3); // 3.333

        // Operator Prescedence: the way the C# execute the operators
        Console.WriteLine("Oprator prescedence");
        var a4 = 1;
        var b4 = 2;
        var c4 = 3;
        Console.WriteLine(a4 + b4 * c4); // 7 : BODMAS
        // Multiply (*) or division (/) operators have the higher prescedence than add (+) or substract (-) operators.

        // if we want to change the presecedence(like we want to execute the addition (+) operation first instead of Mutliplication (*) operation then we have to explicitly use the ()

        Console.WriteLine((a4+b4)*c4); // 9: bacause we have used () brackets to override the default behaviour of operator prescedence in c#.

        Console.WriteLine("Primitive types are over.");
        // primitive types in c#:
        // byte - 1 byte, 8 bits = 1 byte
        // short - 2 bytes : int16 - 16 are bits
        // int - 4 bytes : int32 - 32 are bits
        // long - 8 bytes : int64 - 64 are bits
        // bool - T/F
        // float - 4 bytes : 32 bits, Single precision (7 decimal digits)
        // double - 8 bytes : 64 bits, Double precision (15-16 decimal digits)
        // decimal - 16 bytes : 128 bits, High precision (28-29 decimal digits) // not a primitive type it is a built in value type in C#


        // Non primitive types
        Console.WriteLine("Non primitive types:");
        // Non - primitive types in c#:
        // classes, arrays,strings,interfaces,delegates,enums
        // for non primitive types in c#, we have to explicitly create a memory inside the memory(stack) while declaring the variable which is a non primitive one
        // var person = new Person() // we have to use new keyword to explicitly tell c# to create a peice of memeory with the name/ identifier person of type class Person, this is also called as creating the object/ instance for a class itself.

        // person class:
        Console.WriteLine("Person class:");
        var deepak = new Person(); // deepak is a object/ instance of a type Person class, by using this instance variable we can access the members amd methods inside the Person class
        deepak.firstName = "Deepak";
        deepak.lastName = "Moningi";
        deepak.Introduce(); // Full Name: Deepak Moningi

        // Arrays in C#:
        Console.WriteLine("Arrays in C#:");
        // Array is a datastructure to store a collection of variables of the same type

        // int number1;
        // int number2;
        // int number3;
        // instead of declaring three interger vraibles we can store those three variables inside a single array.

        int[] numbers = new int[3];
        // here we are telling c# compiler that we want to create an array which is a type of integer using int[] and not the normal integer variable on the left hand side.
        // numbers is the identifier/ array name.
        // and at right side we wrote int [3] to tell the array size is 3 to the c# compiler
        // as we mentioned three, we can't store more than three interger values inside this array
        // in C# array size is fixed, we can't modify the size once we declared
        // We have to specify the size of an array while we declaring the array itself.
        // array is an object in C#, we have a class called Array when we declare the array using the above syntax in line no 138 then the compiler will create the instance of the class Array. So now the numbers variable is the instance variable for the Array class.
        // As Array is a non primitive type we have to allocate memory to it.

        // We can supply the values to our numbers array using below approaches:

        numbers[0] = 1;
        Console.WriteLine(numbers[0]); // 1

        // supplying/ inserting the values to the array while defining the array itself (object initilization syntax:)
        string[] names = new string[2] { "Deepak", "Moningi"};

        Console.WriteLine(names[1]); // Moningi

        // We can also declare an array using var keyword also
        // var testArray = new int[2];


        // strings in c#
        Console.WriteLine("Strings in C#");

        // every "keyword" we write here in "c#" will go and map to the "type" in the "dot net framework".
        // example:

        int numb; // here we used keyword "int" in c# but internally it will go and map to "Int32" type in dot net framework
        // and here the int is "struct" not a class.
        // strcut and class are almost same
        // if we class have less no.of properties and if we want to create so many instances then ppl usually create struct
        // as we use primitive datatypes like short, int, byte, long, bool, char will go and map to their corresponding types in dot net framework
        // dotnet framework configured in the way that all the primitive types in C# are structures in dot net framework


        string firstName = "Deepak";

        // here we used string keyword but it is a class as it is a non primitive type
        // if we declare using string keyword like above then it is fine because we are using C# keyword only

        String lastName = "Moningi";
        // this String is there in system name space so to use this we must have to import that namespace
        // we can create using anything string or String, anything is fine


        //string(lowercase s): This is a C# keyword that acts as an alias for the .NET System.String class. It's more commonly used in C# code because it's shorter and more intuitive.
        //String(uppercase S): This directly refers to the System.String class in the.NET Framework.Technically, it represents the same type as string.

        // similar example with int
        Int32 d= 0; // used a type in dot net framework
        int e = 0; // used a keyword in C#, both are same only

        // creating strings approaches:
        Console.WriteLine("Creating strings using different formats:");
        // string formatting
        Console.WriteLine("String formatting:");
        var myFullName = string.Format("My name is {0},{1}", firstName, lastName); // static method
        // Here {0} and {1} will act like a place holders and after ',' by using indexing we have to pass/specify the actual data for those place holders
        Console.WriteLine(myFullName); // Deepak Moningi

        // if you don't want to use the string.format() function then we can use the "$" symbol to format the string, we call this as string interpolation in c#:
        string FullName = $"{firstName} {lastName}";

        Console.WriteLine(FullName);
        // (or)
        Console.WriteLine($"My name is {firstName},{lastName}");

        // string join
        Console.WriteLine("string joining:");
        var namesArray = new string[3] { "Deepak", "Ammu", "Nani" };

        // using join method to combine all the three strings in the namesArray with ","
        // join will add one specific char to all the elements in the namesArray.
        // we can use the string class directly like this, it will go and map the String class which is there in system namespace in dotnet framework:
        var namesList = string.Join(",", namesArray);  // static method
        Console.WriteLine(namesList); // Deepak,Ammu,Nani // now this is a string because string.join will return string only

        // enums:
        Console.WriteLine("Enums: ");
        Console.WriteLine(ShippingMethod.Express); // express
        // If we want the corresponding value for our key then we have to cast that
        // Internally enum is an integer we can cast and get the numeric value for a particular enum
        var method = ShippingMethod.Express;
        Console.WriteLine((int)method); //3 casting it to the integer.

        // If we are getting any number or ID from a data base or from any other third party api
        // and we want to retrieve or get the key for that number 

        var methodId = 3;
        // As we know enums are also types as like int then we can write like this
        Console.WriteLine((ShippingMethod)methodId); // Express

        //convert to strings:
        Console.WriteLine("converting enums to strings:");
        Console.WriteLine(method.ToString()); // Express

        // Reference types and value types
        Console.WriteLine("Reference types and Value types:");
        // value types are the one's that are primitive types in C# : int, char, float , bool, double
        // while creating these we don't have to explicitly allocate memory to this variables 
        // CLR will allocate memory for these variables in the stack

        // Reference types are the one's that are non primitive types in C#: classes, array, string
        // We have to allocate memory for this non primitive type variables while declaring itself
        // CLR won't do this for us

        // value types:
        Console.WriteLine("Value Types:");

        var a5 = 10;
        var b5 = a5;
        b5++;
        Console.WriteLine(string.Format("a5:{0}, b5:{1}",a5,b5)); // a5:10,b5:11
        // here the value of b5 will be 11 and a5 will be 10
        // if we copy a value type variable's value to another value type variable then the copy will be stored.
        // so if we change/increment only b5 value is incremeneted.
        // That's why we call these as value type variables

        // Reference types:
        Console.WriteLine("Reference types:");
        var numbersArray1 = new int[3] { 1, 2, 3 };
        var numbersArray2 = numbersArray1;
        numbersArray2[0] = 0;
        Console.WriteLine(string.Format("numbersArray1[0]:{0}, numbersArray2[0]:{1}", numbersArray1[0], numbersArray2[0])); // 0,0

        // for value types the value and the identifier will be stored inside the stack
        // but for the reference types the actual value will be stored inside the heap and inside stack for the value of a identifier(numbersArray1) the reference will be stored
        // this reference is a reference (memory location) which the actual data is stored inside the heap
        // unlike the value types if we copy one reference type variable to another refernece type variable value.
        // C# will copy the numbers array1 reference and paste it as a value to the numbersArray2 it means both identifiers(numbersArray1, numbersArray2) will points to the same data inside the heap.
        // that's why we call these variables as reference types, when we copy them the reference/ memory adress will be copied instead of the actual value like value types.


        // IF/ELSE IF/ ELSE
        Console.WriteLine("IF/ELSE IF/ELSE:");
        int hour = 19;

        if(hour>0 && hour <= 12)
        {
            Console.WriteLine("It's morning");
        }

        else if(hour>12 && hour <= 18)
        {
            Console.WriteLine("It's Afternoon");
        }
        else
        {
            Console.WriteLine("It's evening");

        }

        // Arrays in deep:
        Console.WriteLine("Arrays in deep:");

       // When you initialize an array with values, you don’t need to explicitly declare its size.
        var numbersArray = new int[] { 3, 7, 9, 2, 14, 6 };

        // Length
        // we can get length using length method
        Console.WriteLine(numbersArray.Length); // 6 // Length() is instance method

        // Indexof()
        // We can also get the index of a particular element in the array
        // we have to use the Array class directly and we can use the indexOf() method using the Array class
        var index = Array.IndexOf(numbersArray, 9); // IndexOf() is a static method
        //here first paramater is the numbersArray which is our target array and the value inside the array
        Console.WriteLine(index); // 2

        // clear()
        Array.Clear(numbersArray, 0, 2);
        // first paramter is the target array,
        // second one is from which index it should clear the array
        // third one is length it is from index 0 to length 2, meaning it will clear first two elements in the array: index:0,1
        // clearing means:  if the element in the array is an int -> 0 ; boolean -> false; string -> null.
        // clearing means changing the actual values to its default values

        Console.WriteLine("After clear() method");
        foreach (var n in numbersArray)
        {
            Console.WriteLine(n); // 0,0,9,2,14,6
        }

        // copy()
        var anotherArray = new int[3];
        Array.Copy(numbersArray, anotherArray, 3);
        // 1st parameter is the source array,
        // 2nd parameter is the destination array
        // 3 rd paramater is to tell how many elements you want to copy from the source array to the destination array from index 0
       
        Console.WriteLine("After Copy() method:");
        foreach(var n in anotherArray)
        {
            Console.WriteLine(n); // 0,0,,9
        }

        // Sort()
        Array.Sort(numbersArray); // Array is a class and Sort is a static method of Array class
        // it will sort the passed array in the ascending order
        Console.WriteLine("After Sort() method:");
        foreach(var n in numbersArray)
        {
            Console.WriteLine(n); // 0,0 2,6,9,14 
        }

        // Rerverse()
        Array.Reverse(numbersArray);
        // it will reverse the passed array
        Console.WriteLine("After Reverse() method:");
        foreach(var n in numbersArray)
        {
            Console.WriteLine(n); // 14,9,6,2,0,0
        }


        // Lists in C#:
        Console.WriteLine("Lists in C#:");
        var numbersList = new List<int>() { 1,2,3,4 };
        // when we want to declare a list in c# then we have to use new List<int>();
        // <> these angle barackets are to denote the type of list 
        // List is also same like arrays, but if we don't know how many elements we want to store in the array we can go with the list
        // in the list we can store one or more elements of a same type like array but the size is not fixed here


        // we can add elements to the list after declaring the list itslef but in array we can't as the size is fixed here:
        // adding one element to the list, but it should be integer because we created the integer list only

        numbersList.Add(1);

        // we can also add the sequence/ more than one element to the list using Addrange() method 
        // we can add an entire array elements to the list
        // we can also add entire list elements to the list
        // we can create a list/ array elements and add to the list also

        numbersList.AddRange(new int[3] { 5, 6, 7 });

        foreach(var number in numbersList)
        {
            Console.WriteLine(number);
        }

        // 1,2,3,4,1,5,6,7

        // we can fetch the index of a particular number
        Console.WriteLine("index of 1:" + numbersList.IndexOf(1)); // it will give the first occurance of 1 :0

        Console.WriteLine("Last index of 1" + numbersList.LastIndexOf(1)); // it will give the last occurance of the provided element in the list:4

        // we can get the length of the list using Count() method

        Console.WriteLine("Count/length of the list: " + numbersList.Count());

        // we can remove an element using remove() method, we have to pass the element that we want to remove

        // using foreach()

        //foreach(var number in numbersList)
        //{
        //    // if we want to remove all the 1's in the list then,
        //    if(number == 1)
        //    {
        //        numbersList.Remove(number);
        //        // it won't remove all the one's in the list because in c#, compiler won't allow you to modify the list/array in the foreach loop
        //        // we must have to use the for loop to remove the elements from the list
        //    }
        //}

        // using for loop:
        for(int j = 0; j < numbersList.Count; j++)
        {
            if (numbersList[j] == 1)
            {
                numbersList.Remove(numbersList[j]);
            }
        }
        // this for loop will remove all the elements which are 1 from the numbersList

        Console.WriteLine("After removing 1's from the list: ");

        foreach (var number in numbersList)
        {
            Console.WriteLine(number); // it will display all the numbers except 1 because we removed the 1's
        }

        // we can clear all the elements in the list at once using clear() method

        numbersList.Clear();

        Console.WriteLine("Count of the list: "+ numbersList.Count()); // count will be 0 as we cleeared the list.

        // Date times in C#:
        Console.WriteLine("Date times in C#:");

        // we create a particular date time like this:
        // Date time is a struct in C#
        var dateTime = new DateTime(2015, 1, 1); // even though Date time is a struct and value type we have to create the Instance of the Date time struct as we are creating the custom date time object.

        Console.WriteLine(dateTime); // o/p: 01-01-2015 00:00:00

        // If we want current date time as per system we dont have to create instance we can simplyu use the Static Now Prop of Date Time Struct:
        // we can get the today's date and time:
        var now = DateTime.Now;
        // here DateTime is the structure which is same like a class and
        // Now is a static property inside the Date time structure, as it is a static proprty we don't need to create an instance/object to access the Now proprty;

        // date time object is  immutable in c# but we have some methods to modfiy the datetime.

        // we can get tommorrow and yesterday also:

        // here we added one more day(tomorrow) to our original day(now)
        var tommorow = now.AddDays(1);

        Console.WriteLine(tommorow); //01 - 11 - 2024 16:49:22

        Console.WriteLine(now); // 31 - 10 - 2024 16:49:22
        
        // here we can see that for tomorrow variable the adddays() method is returning the new date time object after adding one more day to it.

        // but after we again printing the now, it printed current date time only, it means date times are immutable.

        // once we declare those we can't modify the original date time objects value

        // AddDays() is just returning a new date time by taking the now (date time variable) as a reference.


        var yesterday = now.AddDays(-1);


        // we can format the date time to the strings also:

        Console.WriteLine(now.ToLongDateString()); // 31 October 2024
        Console.WriteLine(now.ToShortDateString()); // 31 - 10 - 2024
        Console.WriteLine(now.ToLongTimeString()); // 16:24:17
        Console.WriteLine(now.ToShortTimeString()); // 04:24 PM

        // here with these methods we are able to only get either date or a time

        // if we want to get both date and time then we have to use the to string() method directly

        Console.WriteLine(now.ToString()); // 31-10-2024 16:29:08

        // we can also specify the format to the to Srting method

        Console.WriteLine(now.ToString("yyyy-MM-dd")); // 2024-10-31

        // we can also add time to it:

        Console.WriteLine(now.ToString("yyyy-MM-dd hh:mm")); // 2024 - 10 - 31 04:32


        // strings in detail:
        Console.WriteLine("Strings in detail in c#:");

        var fullName = "Deepak Moningi";

        // splitting the name with " " between my first name and last name using two methods
        // 1) indexOf() - to get the index of the empty space
        // 2) substring() - to seperate two strings using the index

        var indexOfWhiteSpace = fullName.IndexOf(" "); //6

        // now we will split the string with this index.

        var myFirstName = fullName.Substring(0, indexOfWhiteSpace);
        // it will retrieve a substring from a given string
        // param 1: to tell the start index and 
        // param 2: length, how many characters we want to extract from the start index.

        var myLastName = fullName.Substring(indexOfWhiteSpace + 1);
        // here we only passed the start index, so C# will split from the mentioned index from the end of the string


        Console.WriteLine(myFirstName); // Deepak

        Console.WriteLine(myLastName); // Moningi

        // we can do the same thing using the split method in C#.
        // it is easy also, but it will split and store our result in the array of strings where the substring method returns the string itself

        var name = fullName.Split(' ');
        // splitting firstname and last name using a ' '(empty character)

        // looping for the name as it is a array
        // by the way we can loop through the normal string also as the string is ienumarable in c#

        foreach(var n in name)
        {
            Console.WriteLine(n); // Deepak, /n Moningi
        }

        // Replace method:
        fullName.Replace("Deepak", "Nani");
        Console.WriteLine(fullName);//  the o/p will be Deepak Moningi Only
        // always remember that strings are immutable only, meaning once we declare we can't change it
        // all these string class methods in dot net framework will return a new string instance only
        // if we want to see the replace method's output then we must store the result in a variable:
        // or we can directly log that using console.write line

        var replaceMethodsResult = fullName.Replace("Deepak", "Nani");
        Console.WriteLine(replaceMethodsResult); // o/p: Nani Moningi

        // methods to work with null or empty strings in c#:
        Console.WriteLine("methods to work with null or empty strings in c#:");
        string.IsNullOrEmpty(replaceMethodsResult); string.IsNullOrWhiteSpace(replaceMethodsResult);

        // string builder in C#:
        Console.WriteLine("String builder in C#:");
        // string builder is a class which will be in system.text;
        // we can use this string builder when we want to modify the string that we declared
        // we know that string is a immuatable object but this string builder is a mutable object in c#
        // by using this string builder, we can't use the searching operation methods
        // but string builder class provides methods(CRUD) to manipulate the string builder object

        // creating a string builder object:

        var builder = new StringBuilder();

        // methods of string builder:
        // append
        builder.Append('-', 10);
        // param one: is the character what we want to add 
        // param 2: how many times that we want to add the character to the builder variable
        builder.AppendLine();
        // it will add a line below the 10 - dashes, it is like <br> in html
        builder.Append("Header");
        builder.AppendLine();
        builder.Append('-', 10);
        // o/p: ---------(10)

        // header

        // -------(10)
        builder.Replace('-', '+');
        // it will replace all - with + 
        // as this is a mutable one if we modify it using replace method it wont return a new string instead it will modiffy the original string
        // o/p: ++++++(10)

        // header

        // ++++++++(10)

        builder.Remove(0, 10);
        // param 1: start index,
        // param 2: length: how many char should remove
        // it will remove all the characters from index 0 to 9 as we mentioned length as 10
        // o/p:

        // header

        // -------(10)

        // insert method
        builder.Insert(0, new string('-', 10));
        // param 1 : index,
        // param 2:  how many times it should repeat
        // with this it will go to the form like below:
        // o/p: ---------(10)

        // header

        // ++++++(10)
        Console.WriteLine(builder);

        // to access the characters in string builder, we can use the indexing:
        Console.WriteLine("first character: "+ builder[0]); // o/p : - 

        // LINQ in C#
        Console.WriteLine("LINQ in C#: ");

        // in memory collection:
        int[] numArray = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

        // SQL like query   
        var result = from number in numArray
                     where (number % 2) == 0
                     select number;

        foreach(var num in result)
        {
            Console.WriteLine(num);
        }

        // Lambda like expressions
        var minNumber = numArray
                        .OrderBy(x => x)
                        .Take(1);

        foreach(var n in minNumber)
        {
            Console.WriteLine(n);
        }

        // About IEnumarebale and Enumurable class:

        //IEnumerable<T> Interface: Defines a sequence of elements that can be enumerated.It is implemented by collections and allows iteration using foreach.

        //Enumerable Class: A static class that provides LINQ extension methods for querying collections that implement IEnumerable<T>.It includes methods like Where, Select, OrderBy, etc.

        // Linq where operator in detail:

        Console.WriteLine("Linq where operator in detail: ");
        // this where query is belong to restriction operators category.
        // these operators are like where in SQL.
        // in Linq where operator is used to filter the data source
        // we have to specify the filter expression / condition using a predicate

        // Predicate : it is a function to test each element in a collection with a condition
        // For where oprator the paramater should be a predicate and it's type is a function <int,bool>: here for the function int is i/p, bool is o/p.
        // input param in int because we are using the where extension method on interger array

        // Functional deligate which is a predicate in Where condition in LINQ

        Func<int, bool> OddorEven = (num) => { return num % 2 == 0; };
        var evenNumbers = numArray.Where(num => OddorEven(num));
        foreach(var number in evenNumbers)
        {
            Console.WriteLine(number);
        }

        // select :
        Console.WriteLine("Linq select operator: ");

        // to only get all id values from the list
        var rsult = Employee.GetAllEmployees().Select(emp => emp.EmployeeID).ToList();

        foreach(var id in rsult)
        {
            Console.WriteLine(id);
        }

        // if we want to select more than one property from the list then we have to create an anonymous type and store it in a variable like this

         var anonymousRes = Employee.GetAllEmployees().Select(emp => new
        // created a new anonymous type inside select for only select first name and gender for each employee object in list
        // as we don't know and there is no type for those two properties we have created anonymous type here new {firstname(prop), gender(prop)}
        // if we know the type of the object we are creating (meaning if the properties are there inside a seperate class then we can use that type)
        // example if firstaname  and gender are in a seperate class(test)
        // then we can project/ map the first name and gender property values from employee class to properties(first name and gender) in test class by creating an instance using new test{} in select method
        // instead all doing this Linq is allowing us to create an anonymous type using new {} like below:
        {
            fN = emp.FirstName,
            G = emp.Gender

        });
        // so now for each employee object in the employee list 
        // select method will select the firstname and gender from the employe list and project those values to the variables/ properties inside the anonymous type
        // remember if we have the test class then we have to map/project from employeelist from employee class to properties inisde the test class 
        //example: test.Fn = emp.firstname; 

        foreach (var v in anonymousRes)
        {
            Console.WriteLine($"Employee firstName: {v.fN}, Employee Gender: {v.G}");
        }

        Console.WriteLine("Find operator: ");

        var r = Employee.GetAllEmployees().Find(emp => emp.EmployeeID == 101);// find is not an extension method it is a method of List type

        // Find will return only one record/object based on the condition,
        // if it finds the object it will return the source object other wise it will return default value for the source which means null in this case as we are iterating through the reference type
        // if we are iterating through the integers then it will return 0 if it unable to find the value based on the predicate

        // pass the primary key value
        if (r != null)
        {
            Console.WriteLine(r.FirstName);
        }

        // Groupby in LINQ:
        Console.WriteLine("Group by operator in LINQ:");

        // lambda expression:
        var empgroups = Emp.GetAllEmployees().GroupBy(x => x.Department);

        // sql like query:
        var sqlempgroups = from employee in Emp.GetAllEmployees()
                           group employee by employee.Department;

        foreach (var group in sqlempgroups)
        {
            Console.WriteLine("{0} - {1}", group.Key, group.Count());
        }

        // here the group contains the key which is the department in our case and employee objects belonging to that key/ group.
        // Here group.key is the key that we are grouping which is department in each emp object.
        // group by will group the objects/records in the emp list based on their department
        // after that we can specify the condition for displaying the groups using the aggregate functions like count,sum,max,min,avg()

        // If we want the count where the dept having only male employees
        // we can specify this in count function like we want the count only for the groups those having males

        Console.WriteLine("Here:");
        foreach (var group in sqlempgroups)
        {
            Console.WriteLine("{0} - {1}", group.Key, group.Count(x=>x.Gender == "Male")); // after grouping, filtering on the intermediate result given by group by

            Console.WriteLine("------------------");
            // if we want to display all the employes in each group
            
            // we want now each emp in each groip:

            foreach(var emp in group)
            {
                // iterating through the group because that group consists each employee object in each department
                Console.WriteLine($"{emp.Name} - {emp.Department}");
            }
        }

        // testing:
        var carsresult = Car.GetAllCars().Where(x => x.TopSpeed > 100);

        foreach(var car in carsresult)
        {
            Console.WriteLine($"carname: {car.CarName}");
        }

        // if we want to group the groups with more than one column or property in the list
        // we have to create a new anonymous type to specify our grouping condition

        Console.WriteLine("group by for multiple props: ");

        var employeegroups = Emp.GetAllEmployees()
                             .GroupBy(x => new { x.Department, x.Gender }) // groups will create
         // now the keys will consists of department and gender because we have specified those as keys in group by()
         .OrderBy(g => g.Key.Department).ThenBy(g => g.Key.Gender) // groups will sort in asc
        // here we ordered the department and then by gender
        .Select(g => new
        {
            dept = g.Key.Department,
            gender = g.Key.Gender,
            employees = g.OrderBy(x => x.Name) // names will sort in each group 
        });

        // this will group first by department and then by gender:

        foreach (var group in employeegroups)
        {
            // here we have to access the dept and gender like below:
            // because we are storing those keys in the dep and gender in anonymous type in select() above

            Console.WriteLine($"{group.dept} Department {group.gender} emploeyees count = {group.employees.Count()}"); // it will log grp name and gender and no.of employes in eacg grp
            Console.WriteLine("---------------------------------");
            foreach(var emp in group.employees)
            {
                Console.WriteLine($"{emp.Name} - {emp.Gender} - {emp.Department}"); // for each grup names will log the specifid props in ascesing order
            }
        }


        // Pagination using skip() and Take() Pagination methods:

        Console.WriteLine("Pagination using skip() and Take() Pagination methods: ");
        var studentsList = Student.GetAllStudetns();
        Console.WriteLine("Please enter a page number from 1 to 4: ");
        if (int.TryParse(Console.ReadLine(), out int pagenumber))
        {
            if (pagenumber >= 1 && pagenumber <= 4)
            {
                int pageSize = 3;

                // we got the page number and page size 

                // now using skip and take methods by using thse two

                var paginatedresult = studentsList
                    .Skip((pagenumber - 1) * pageSize)
                    .Take(pageSize);

                foreach (var iten in paginatedresult)
                {
                    Console.WriteLine(iten.StudentID + iten.Name + iten.TotalMarks);
                }

                Console.WriteLine();

            }
            else
            {
                Console.WriteLine("please enter a page number beween 1 and 4:");
            }
        }
        else
        {
            Console.WriteLine("please send a valid page number:");
            Console.WriteLine("proceed:");
        }
    }

}

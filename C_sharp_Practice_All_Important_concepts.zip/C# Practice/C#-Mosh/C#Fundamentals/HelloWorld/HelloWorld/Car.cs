﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    internal class Car
    {
        public string CarName { get; set; }

        public int LaunchYear { get; set; }

        public int TopSpeed { get; set; }

        public static List<Car> GetAllCars()
        {
            return new List<Car>()
            {
                new Car {CarName = "swift", LaunchYear = 2001, TopSpeed = 100},
                new Car {CarName = "Thar", LaunchYear = 2016, TopSpeed = 120},
                new Car {CarName = "city", LaunchYear = 2016, TopSpeed = 125}
            };
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    public class Emp
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Gender { get; set; }
        public string Department { get; set; }
        public int Salary { get; set; }

        public static List<Emp> GetAllEmployees()
        {
            return new List<Emp>()
        {
            new Emp { ID = 1, Name = "Mark", Gender = "Male",
                                         Department = "IT", Salary = 45000 },

            new Emp { ID = 2, Name = "Steve", Gender = "Male",
                                         Department = "HR", Salary = 55000 },

            new Emp { ID = 3, Name = "Ben", Gender = "Male",
                                         Department = "IT", Salary = 65000 },

            new Emp { ID = 4, Name = "Philip", Gender = "Male",
                                         Department = "IT", Salary = 55000 },

            new Emp { ID = 5, Name = "Mary", Gender = "Female",
                                         Department = "HR", Salary = 48000 },

            new Emp { ID = 6, Name = "Valarie", Gender = "Female",
                                         Department = "HR", Salary = 70000 },

            new Emp { ID = 7, Name = "John", Gender = "Male",
                                         Department = "IT", Salary = 64000 },

            new Emp { ID = 8, Name = "Pam", Gender = "Female",
                                         Department = "IT", Salary = 54000 },

            new Emp { ID = 9, Name = "Stacey", Gender = "Female",
                                         Department = "HR", Salary = 84000 },

            new Emp { ID = 10, Name = "Andy", Gender = "Male",
                                         Department = "IT", Salary = 36000 }
        };
        }
    }
}

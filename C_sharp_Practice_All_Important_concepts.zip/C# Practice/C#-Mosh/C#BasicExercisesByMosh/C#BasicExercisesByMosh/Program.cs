﻿using System.Globalization;
using System.Security.Cryptography.X509Certificates;
using System.Xml.Linq;

class Program
{
    static void Main()
    {
        // control flow exercises

        // Exercise 1: number of numbers between 1 and 100 that are divisible by 3:

        //var count = 0;
        //for(var i=1; i <= 100; i++)
        //{
        //    if(i%3 == 0)
        //    {
        //        count = count + 1;
        //    }

        //}

        //Console.WriteLine($"Count : {count}");

        // Exercise 2: continuously ask the user to enter a number or "ok" to exit. 
        //var inputCount = 0;
        //while (true)
        //{
        //    Console.WriteLine("Enter a number or enter ok to exit:");
        //    var userInput = Console.ReadLine();

        //    if(int.TryParse(userInput, out int number))
        //    {
        //        inputCount = inputCount + number;
        //    }

        //    else if(userInput?.ToLower() == "ok")
        //    {

        //        break;
        //    }
        //}
        //Console.WriteLine($"Result Count : {inputCount}");

        //Exercise 3: Factorial number program:

        //Console.WriteLine("enter a number to get it's factorial");
        //var userInput = Convert.ToInt32(Console.ReadLine());
        //var result = 1;

        //for(var i = userInput; i > 0; i--)
        //{
        //    result = result * i;
        //}

        //Console.WriteLine($"Factorial for {userInput} : {result}");

        // Exercise 4 : Random number guessing program

        //Console.WriteLine("Guess and enter the random number, you have four chances only:");
        //Random rnd = new Random();
        //var randomNumber = rnd.Next(1, 11);
        //Console.WriteLine($"Random number: {randomNumber}"); // logged for debugging

        //for(int i=0; i < 4; i++)
        //{
        //    var userInput = Convert.ToInt32(Console.ReadLine());
        //    if(userInput == randomNumber)
        //    {
        //        Console.WriteLine("You Won");
        //        break;
        //    }
        //    else if (i == 3)
        //    {
        //        Console.WriteLine("You Lost");
        //    }
        //    else
        //    {
        //        Console.WriteLine("Wrong guess try again");
        //    }
        //}

        // Exercise 5: Find the maximum of the numbers and display it on the console
        //Console.WriteLine("Please enter series of numbers seperated by coma ',' : ");

        //var userInput = Console.ReadLine();

        //var numbersArray = userInput.Split(',');

        //var maxnumber = Convert.ToInt32(numbersArray[0]);

        //for(int i = 1; i < numbersArray.Length; i++)
        //{
        //    if (Convert.ToInt32(numbersArray[i]) > maxnumber)
        //    {
        //        maxnumber = Convert.ToInt32( numbersArray[i]);
        //    }
        //}

        //Console.WriteLine($"Max number is : {maxnumber}");

        // Arrays and Lists Exercises:
        // Exercise 1: Facebook likes program:

        //while (true)
        //{
        //    Console.WriteLine("Enter the names who likes the Post");

        //    var userInput = Console.ReadLine();

        //    if (string.IsNullOrWhiteSpace(userInput))
        //    {
        //        break;
        //    }

        //    else
        //    {
        //        var namesArray = userInput.Split(',');

        //        switch (namesArray.Length)
        //        {
        //            case 0:
        //                break;
        //            case 1:
        //                Console.WriteLine($"[{namesArray[0]}] liked your post");
        //                break;
        //            case 2:
        //                Console.WriteLine($"[{namesArray[0]}],[{namesArray[1]}] liked your post");
        //                break;
        //            case > 2:
        //                Console.WriteLine($"[{namesArray[0]}],[{namesArray[1]}] and [{namesArray.Length - 2 }] liked your post");
        //                break;
        //            default:
        //                Console.WriteLine("invalid input");
        //                break;
        //        }
        //    }
        //}

        // Exercise 2: name reverse program
        // string -> array -> string

        //Console.WriteLine("Enter your name: ");

        //var userInput = Console.ReadLine();

        //var nameArray = new char[userInput.Length];

        //for(int i=userInput.Length - 1; i >= 0 ; i--)
        //{
        //    nameArray[i] = userInput[userInput.Length - i - 1];
        //}

        //// name array will have all the characters
        //// array -> string

        //var resultString = "";
        //for(int i =0; i < nameArray.Length; i++)
        //{
        //    resultString = resultString + nameArray[i];
        //}

        //Console.WriteLine(resultString);

        // Exercise 3: Five unique numbers(ascending order) program:
        // sort and display the numbers from userInput
        // Bubble sort:

        //Console.WriteLine("You must have to enter five unique numbers to exit from the program:");
        //var numbersList = new List<int>();
        //while (true)
        //{
        //    var isDuplicate = false;
        //    var userInput = Convert.ToInt32(Console.ReadLine());
        //    foreach(var number in numbersList)
        //    {
        //        if(number == userInput)
        //        {
        //            Console.WriteLine($"You have already entered this number: {userInput}, Please only enter unique numbers");
        //            isDuplicate = true;
        //        }

        //    }
        //    if (!isDuplicate)
        //    {
        //        numbersList.Add(userInput);
        //    }

        //    // Instead of writing the if condition like below, we can also modify the while loop initilization(while(numbersList.Count < 5))
        //    if (numbersList.Count == 5)
        //    {
        //        Console.WriteLine($"Your {numbersList.Count} unique numbers in sorted order:");
        //        break;
        //    }

        //}

        //// implemented Bubble sort to sort the numbers in ascedning order:
        //for(int i =0; i<numbersList.Count-1; i++)
        //{
        //    for(int j=0; j< numbersList.Count - 1 - i; j++)
        //    {
        //        if (numbersList[j] > numbersList[j + 1])
        //        {
        // adjacent elements swapping:
        //            int temp = numbersList[j];
        //            numbersList[j] = numbersList[j + 1];
        //            numbersList[j + 1] = temp;
        //        }
        //    }
        //}

        //foreach(var number in numbersList)
        //{
        //    Console.WriteLine(number);
        //}

        // Exercise 4: program to ask the user to continuously enter a number or type "Quit" to exit. 
        // display unique numbers from userInput
        // var numbersList = new List<int>();
        // while (true)
        // {
        //     Console.WriteLine("Enter a number or type 'Quit' to exit from the program:");
        //     var userInput = Console.ReadLine();
        //     if(int.TryParse(userInput, out int number))
        //     {
        //         numbersList.Add(number);
        //     }
        //     else if(userInput?.ToLower() == "quit")
        //     {
        //         //DisplayUniqueNumbersUsingDictionary(numbersList);
        //         DisplayUniqueNumbersUsingList(numbersList);
        //         break;
        //     }
        //     else
        //     {
        //         Console.WriteLine("Please only Enter a number or type 'Quit' to exit from the program: ");
        //     }
        // }


        // // fetching unique numbers using a dictionary:
        //void DisplayUniqueNumbersUsingDictionary(List<int> numsList)
        //{
        //     var numsDictionary = new Dictionary<int, int>();

        //     foreach(var num in numsList)
        //     {
        //         if (numsDictionary.Keys.Contains(num))
        //         {
        //             numsDictionary[num] = numsDictionary[num] + 1;
        //         }
        //         else
        //         {
        //             numsDictionary.Add(num, 1);
        //         }
        //     }

        //     Console.WriteLine("Unique numbers from your numbers: ");

        //     foreach(var key in numsDictionary.Keys)
        //     {
        //         if (numsDictionary[key] == 1)
        //         {
        //             Console.WriteLine(key);
        //         }
        //     }
        //}

        // // fetching the unique numbers by creating another list:
        // void DisplayUniqueNumbersUsingList(List<int> numsList)
        // {
        //     var uniqueNumbersList = new List<int>();
        //     for(int i = 0; i < numsList.Count; i++)
        //     {
        //         var isDuplicate = false;

        //         for(int j = 0; j < uniqueNumbersList.Count; j++)
        //         {
        //             if (uniqueNumbersList[j] == numsList[i])
        //             {
        //                 isDuplicate = true;
        //             }
        //         }
        //         if (!isDuplicate)
        //         {
        //             uniqueNumbersList.Add(numsList[i]);
        //         }
        //     }

        //     foreach(var number in uniqueNumbersList)
        //     {
        //         Console.WriteLine(number);
        //     }
        // }

        // Exercise 5: display three small numbers from the list(user Input)
        //Console.WriteLine("please enter minimum five numbers seperated with ',' to proceed:");

        //while (true)
        //{
        //    var userInput = Console.ReadLine()?.Split(',');

        //    if(userInput?.Length == 0 || userInput?.Length < 5)
        //    {
        //        Console.WriteLine("Invalid List, Please enter minimum five numbers to proceed:");
        //    } 
        //    else if (userInput?.Length >= 5)
        //    {
        //        var InputList = new List<int>();
        //        foreach(var num in userInput)
        //        {
        //            InputList.Add(Convert.ToInt32(num));
        //        }

        //        // code to get three smallest numbers from inputList:
        //        var mini = int.MaxValue - 2;
        //        var secondMini = int.MaxValue - 1;
        //        var thirdMini = int.MaxValue;
        //        foreach(var num in InputList)
        //        {
        //            if (num < mini)
        //            {
        //                thirdMini = secondMini;
        //                secondMini = mini;
        //                mini = num;
        //            }
        //            else if(num < secondMini)
        //            {
        //                thirdMini = secondMini;
        //                secondMini = num;
        //            }
        //            else if(num < thirdMini)
        //            {
        //                thirdMini = num;
        //            }
        //        }
        //        Console.WriteLine($"First minimum number : {mini}");
        //        Console.WriteLine($"Second minimum nuumber: {secondMini}");
        //        Console.WriteLine($"Third minimum number: {thirdMini}");

        //        // code to get three largest numbers:
        //        var maxi = int.MinValue;
        //        var secondMaxi = int.MinValue + 1;
        //        var thirdmaxi = int.MinValue + 2;
        //        foreach(var num in InputList)
        //        {
        //            if (num > maxi)
        //            {
        //                thirdmaxi = secondMaxi;
        //                secondMaxi = maxi;
        //                maxi = num;
        //            }
        //            else if(num > secondMaxi)
        //            {
        //                thirdmaxi = secondMaxi;
        //                secondMaxi = num;
        //            }
        //            else if(num > thirdmaxi)
        //            {
        //                thirdmaxi = num;
        //            }
        //        }
        //        Console.WriteLine($"First Maximum number: {maxi}");
        //        Console.WriteLine($"Second Maximum number: {secondMaxi}");
        //        Console.WriteLine($"Third Maximum number: {thirdmaxi}");
        //        Console.WriteLine();
        //        break;
        //    }
        //    else
        //    {
        //        Console.WriteLine("Please provide the valid input");
        //    }
        //}

        // Working with text Exercises:
        // Exercise 1: Consecutive or not from userInput:
        //Console.WriteLine("Please enter few numbers seperated by a hyphen '-': ");
        //var userInput = Console.ReadLine()?.Split('-');
        //var inputList = new List<int>();
        //foreach(var num in userInput)
        //{
        //    inputList.Add(Convert.ToInt32(num));
        //}

        //var isConsecutive = false;

        //for (int i = 0; i < inputList.Count - 1; i++)
        //{
        //    if (inputList[i] + 1 == inputList[i+1] || inputList[i] - 1 == inputList[i + 1])
        //    {
        //        isConsecutive = true;
        //    }
        //    else
        //    {
        //        isConsecutive = false;
        //        break;
        //    }
        //}

        //if (isConsecutive)
        //{
        //    Console.WriteLine("Consecutive");
        //}
        //else
        //{
        //    Console.WriteLine("Not Consecutive");
        //}

        // Exercise 2: Duplicate or not(from userInput):
        //Console.WriteLine("Please enter few numbers seperated by a hyphen '-': ");
        //var userInput = Console.ReadLine();
        //if(String.IsNullOrEmpty(userInput) || string.IsNullOrWhiteSpace(userInput))
        //{
        //    return;
        //}

        //else
        //{
        //    var inputArray = userInput.Split('-');
        //    var inputList = new List<int>();
        //    foreach(var input in inputArray)
        //    {
        //        var isDuplicate = false;

        //        for(int i = 0; i < inputList.Count; i++)
        //        {
        //            if (inputList[i] == Convert.ToInt32(input))
        //            {
        //                isDuplicate = true;
        //                break;
        //            }
        //        }

        //        if (isDuplicate)
        //        {
        //            Console.WriteLine("Duplicate");
        //            break;
        //        }
        //        else
        //        {
        //            inputList.Add(Convert.ToInt32(input));
        //        }


        //    }
        //}

        // Exercise 3: Valid date program:
        //Console.WriteLine("Please enter a time value in 24 hour format: ");
        //var userInput = Console.ReadLine();

        // converting string to a time span type:
        // TimeSpan.TryParse(userInput, out TimeSpan result);

        //if(result > TimeSpan.FromHours(0) && result < TimeSpan.FromHours(24))
        //{
        //    Console.WriteLine("OK");
        //}
        //else
        //{
        //    Console.WriteLine("Invalid Time");
        //}

        // Date times exercies (Self learning):
        //DateTime today = DateTime.Now;

        //string format1 = today.ToString("dd/MMM/yyyy",CultureInfo.InvariantCulture);

        //// CultureInfo.InvariantCulture ->ensures that the month abbreviation is in English.
        //Console.WriteLine(format1); // 02/dec/2024

        //string format2 = today.ToString("dd/MMMM/yyyy");
        //// Here we haven't specified  culture info.invariantCulture but still we are getting the full month name(December) but the symbol between date and month is - instead of this /
        //Console.WriteLine(format2); // 02-December-2024

        //string format3 = today.ToString("dd/MMMM/yyyy hh:mm:ss", CultureInfo.InvariantCulture);
        //Console.WriteLine(format3); // 02/december/2024

        // as we used cultureinfo.invariantculture here we got the date like above.

        // Exercise 4: Pascal case conversion program:

        //Console.WriteLine("Enter few words seperated by space: ");
        //var userInput = Console.ReadLine()?.Split(' ');

        //var resultString = string.Empty;

        //foreach(var item in userInput)
        //{
        //    resultString = resultString + item.Substring(0, 1).ToUpper() + item.Substring(1).ToLower();
        //}

        //Console.WriteLine(resultString);

        // Exercise 5: Number of vowels in userInput
        //var vowels = new char[5] { 'a', 'e', 'i', 'o', 'u' };
        //Console.WriteLine("Please enter an English word: ");
        //var userInput = Console.ReadLine()?.ToLower();

        //var vowelsCount = 0;
        //foreach (var item in userInput)
        //{
        //    for (int i = 0; i < vowels.Length; i++)
        //    {
        //        if (vowels[i] == item)
        //        {
        //            vowelsCount++;
        //        }
        //    }
        //}

        //Console.WriteLine($"number of vowels from your input: {vowelsCount}");



        //----------------------------------------------------------------------------------------------------------------------------------------
        // Revision:
        // unique numbers program:
        //var numbersList = new List<int>() { 1, 2, 1, 3, 4, 5, 3 };

        //var uniqueDictionary = new Dictionary<int, int>();

        //foreach(var item in numbersList)
        //{
        //    if (uniqueDictionary.Keys.Contains(item))
        //    {
        //        uniqueDictionary[item] = uniqueDictionary[item] + 1;
        //    }
        //    else
        //    {
        //        uniqueDictionary.Add(item, 1);
        //    }
        //}

        //foreach(var key in uniqueDictionary.Keys)
        //{
        //    if (uniqueDictionary[key] == 1)
        //    {
        //        Console.WriteLine(key); // it will only display the unique numbers
        //    }
        //}

        //Console.WriteLine("break");
        //// if we want to remove the duplicates and print every number that is present in numbersList, then we can print the keys in the uniqueDictionary is enough:
        //foreach(var key in uniqueDictionary.Keys)
        //{
        //    Console.WriteLine(key); // it will log the key directly w/o any condition
        //}

        // Three min and max numbers from the list:
        //List<int> numbers = new List<int> { 34, -50, 23, 0, -2, 88, 15, -100, 72, 50, -1, 99, 10, 20, -5 };

        // Three minimum numbers:
        //var mini = int.MaxValue - 2;
        //var secondMini = int.MaxValue - 1;
        //var thirdMini = int.MaxValue;

        //for(int i = 0; i < numbers.Count; i++)
        //{
        //    if (numbers[i] < mini)
        //    {
        //        thirdMini = secondMini;
        //        secondMini = mini;
        //        mini = numbers[i];
        //    }
        //    else if (numbers[i]< secondMini)
        //    {
        //        thirdMini = secondMini;
        //        secondMini = numbers[i];
        //    }
        //    else if (numbers[i] < thirdMini)
        //    {
        //        thirdMini = numbers[i];
        //    }
        //}

        //Console.WriteLine($"First Minimum number: {mini}");
        //Console.WriteLine($"Second Minimum number: {secondMini}");
        //Console.WriteLine($"Third Minimum number: {thirdMini}");

        //// Three maximum numbers:
        //var maxi = int.MinValue;
        //var secondMaxi = int.MinValue+1;
        //var thirdMaxi = int.MinValue+2;

        //for(int i = 0; i < numbers.Count; i++)
        //{
        //    if (numbers[i] > maxi)
        //    {
        //        thirdMaxi = secondMaxi;
        //        secondMaxi = maxi;
        //        maxi = numbers[i];
        //    }
        //    else if (numbers[i]> secondMaxi)
        //    {
        //        thirdMaxi = secondMaxi;
        //        secondMaxi = numbers[i];
        //    }
        //    else if (numbers[i] > thirdMaxi)
        //    {
        //        thirdMaxi = numbers[i];
        //    }
        //}

        //Console.WriteLine("break");

        //Console.WriteLine($"First Maximum number: {maxi}");
        //Console.WriteLine($"Second Maximum number: {secondMaxi}");
        //Console.WriteLine($"Third Maximum number: {thirdMaxi}");


        // name reverse program
        // string -> array -> string

        // string
        //var userName = "Deepak";

        //var nameArray = new char[userName.Length];

        //// reveresed the string using an array
        //for (int i = 0; i < userName.Length; i++)
        //{
        //    nameArray[userName.Length - i - 1] = userName[i];
        //}

        //// storing the reversed array characters in a string

        //var resultString = string.Empty;

        //for(int i = 0; i < nameArray.Length; i++)
        //{
        //    resultString = resultString + nameArray[i];
        //}

        //Console.WriteLine(resultString);


        // Bubble sort:
        //Console.WriteLine("You must have to enter five unique numbers to exit:");
        //var numbersList = new List<int>();

        //while (true)
        //{
        //    var isDuplicate = false;
        //    var userInput = Convert.ToInt32(Console.ReadLine());

        //    for (int i = 0; i < numbersList.Count; i++)
        //    {
        //        if (userInput == numbersList[i])
        //        {
        //            Console.WriteLine($"You have already entered {userInput}, please only enter unique numbers:");
        //            isDuplicate = true;
        //        }
        //    }

        //    if (!isDuplicate)
        //    {
        //        numbersList.Add(userInput);
        //    }

        //    if (numbersList.Count == 6)
        //    {
        //        Console.WriteLine("Ascending order for the numbers that you have entered:");
        //        break;
        //    }
        //}

        //// Bubble sort for sorting the numbersList in ascending order:

        //for (int i = 0; i < numbersList.Count - 1; i++)
        //{
        //    for (int j = 0; j < numbersList.Count - 1 - i; j++)
        //    {
        //        if (numbersList[j] > numbersList[j + 1]) //8>5
        //        {
        //            // sawpping of adjacent numbers
        //            var temp = numbersList[j + 1];
        //            numbersList[j + 1] = numbersList[j];
        //            numbersList[j] = temp;
        //        }
        //    }
        //}

        //foreach (var number in numbersList)
        //{
        //    Console.WriteLine(number);
        //}

        //Console.WriteLine();


        //Console.WriteLine("descending order for the numbers that you have entered:");

        //// descending order:

        //for (int i = 0; i < numbersList.Count - 1; i++)
        //{
        //    for (int j = 0; j < numbersList.Count - 1 - i; j++)
        //    {
        //        if (numbersList[j] < numbersList[j + 1])
        //        {
        //            // swap
        //            // here we are swapping the elements if the current element is less than the adjacent element
        //            // if we do like this for each iteration in outer loop the largest element in the list will come and place to begining of the list one by one

        //            var temp = numbersList[j + 1];
        //            numbersList[j + 1] = numbersList[j];
        //            numbersList[j] = temp;
        //        }
        //    }
        //}

        //foreach (var number in numbersList)
        //{
        //    Console.WriteLine(number);
        //}


        // name reverse program:
        // string -> array -> string

        //Console.WriteLine("please enter your name:");

        //var userInput = Console.ReadLine();

        //var charArray = new char[userInput.Length];

        //// string to array: reversed here
        //for (int i = 0; i < userInput.Length; i++)
        //{
        //    charArray[i] = userInput[userInput.Length - i - 1];
        //}

        //// array to string again:
        //string result = string.Empty;

        //for (int i = 0; i < charArray.Length; i++)
        //{
        //    result = result + charArray[i];
        //}

        //Console.WriteLine(result);

        // converting userinput to pascal case program:

        //Console.WriteLine("Please enter the text: ");
        //var userinput = Console.ReadLine()?.Split(' ');

        //var result = string.Empty;


        //foreach(string text in userinput)
        //{
        //    result = result + text[0].ToString().ToUpper() + text.Substring(1).ToLower();
        //}

        //Console.WriteLine(result);

        //string MyName = "Deepak";

        //var charArray = new char[MyName.Length];

        //for (int i = 0; i < MyName.Length; i++)
        //{
        //    charArray[i] = MyName[MyName.Length - i - 1];


        //}

        //var res = new string(charArray);
        //Console.WriteLine(res);


        //var charactersArray = MyName.ToCharArray();
        //// Another approach:
        //for (int i = 0; i < MyName.Length/2; i++)
        //{
        //    var temp = charactersArray[i];
        //    charactersArray[i] = charactersArray[MyName.Length - i - 1];
        //    charactersArray[MyName.Length - i - 1] = temp;

        //}

        //var resp = new string(charArray);
        //Console.WriteLine(resp);

        // Prime numbers program (Ammu):
        // find out list of prime numbers from a given list:

        //var numbersList = new List<int>() { 3, 5, 9, 21, 25, 50, 130, 133, 14,17,2 };

        //var primeNumbers = new List<int>();

        //foreach(var number in numbersList)
        //{
        //    var isPrime = true;

        //    for(int i = 2;i< number; i++)
        //    {
        //        if (number % i == 0)
        //        {
        //            isPrime = false;
        //            break;
        //        }
        //    }
        //    if (isPrime)
        //    {
        //        primeNumbers.Add(number);
        //    }
        //}

        //foreach(var num in primeNumbers)
        //{
        //    Console.WriteLine(num);
        //}

        // Finding a peak element in an array/List (Ammu):
        // peak for first element in the array if first element is > second element then it is a peak element
        // if the above condition fails then if last element in the array is greater than last but one element then it is a peak.
        // if the above two conditions fails then the middle of both first and last elements the element should be greater than left side element and right side element

        //var numbersArray = new int[0]; 
        //var peak = 0;


        //if(numbersArray.Length == 0)
        //{
        //    peak = 0;
        //}
        //else if(numbersArray.Length == 1)
        //{
        //    peak = numbersArray[0];
        //}
        //else if (numbersArray[numbersArray.Length - 1] > numbersArray[numbersArray.Length - 2])
        //{
        //    peak = numbersArray[numbersArray.Length - 1];
        //}
        //else
        //{
        //    for (int i = 0; i < numbersArray.Length - 1; i++)
        //    {
        //        if (i == 0)
        //        {
        //            if (numbersArray[i] > numbersArray[i + 1])
        //            {
        //                peak = numbersArray[i];
        //                break;
        //            }

        //        }

        //        else if (i == numbersArray.Length - 1)
        //        {
        //            if (numbersArray[numbersArray.Length - 1] > numbersArray[numbersArray.Length - 1 - 1])
        //            {
        //                peak = numbersArray[numbersArray.Length - 1];
        //                break;
        //            }
        //        }

        //        else
        //        {
        //            if (numbersArray[i] > numbersArray[i + 1] && numbersArray[i] > numbersArray[i - 1])
        //            {
        //                peak = numbersArray[i];
        //                break;
        //            }
        //        }

        //    }
        //}
        //Console.WriteLine($"Peak: {peak}");

        // move the zeroes to the end of the array(swap):
        //var numbersArray = new int[7] { 3, 1, 0, 2, 3, 0, 1 };

        //for(int i = 0; i < numbersArray.Length-1; i++)
        //{
        //    if (numbersArray[i] == 0)
        //    {
        //        var temp = numbersArray[i];
        //        numbersArray[i] = numbersArray[i + 1];
        //        numbersArray[i + 1] = temp;
        //    }
        //}

        // correct approach(ammu)
        //var length = numbersArray.Length;

        //for (int i = 0; i < length-1; i++)
        //{
        //    if (numbersArray[i] == 0)
        //    {

        //        var j = i + 1;
        //        while (j<length)
        //        {
        //            if (numbersArray[j] != 0)
        //            {
        //                break;
        //            }
        //            j++;
        //        }
        //        if (j == length)
        //        {
        //            break;
        //        }
        //        else
        //        {
        //            var temp = numbersArray[i];
        //            numbersArray[i] = numbersArray[j];
        //            numbersArray[j] = temp;
        //        }

        //    }
        //}

        //foreach (var number in numbersArray)
        //{
        //    Console.WriteLine(number);
        //}


        // Two strings are Anagram or not:
        //var string1 = "abc";
        //var string2 = "bcd";

        //var charDictionary = new Dictionary<char, int>();
        //var isAnagram = true;


        //if (string1.Length != string2.Length)
        //{
        //    Console.WriteLine("Both are not Anagrams");
        //}
        //else
        //{
        //    foreach (char character in string1)
        //    {
        //        if (charDictionary.Keys.Contains(character))
        //        {
        //            charDictionary[character] = charDictionary[character] + 1;
        //        }
        //        else
        //        {
        //            charDictionary.Add(character, 1);
        //        }
        //    }

        //    foreach (char character in string2)
        //    {
        //        if (charDictionary.Keys.Contains(character))
        //        {
        //            charDictionary[character] = charDictionary[character] - 1;
        //        }
        //        else
        //        {
        //            isAnagram = false;
        //            break;
        //        }
        //    }

        //    if (isAnagram)
        //    {
        //        Console.WriteLine("Both are anagrams");
        //    }
        //    else
        //    {
        //        Console.WriteLine("Both are not anagrams");

        //    }

        // no need as we added length consition in line number 932:
        //    //foreach(var key in charDictionary.Keys)
        //    //{
        //    //    if (charDictionary[key] == 0)
        //    //    {
        //    //        Console.WriteLine("Both are anagrams");
        //    //    }
        //    //    else
        //    //    {
        //    //        Console.WriteLine("Both are not anagrams");
        //    //    }
        //    //}
        //}

        //// Pangram or not:
        //var myString = "The quick brown fox jumps over the lazy dog"; // [a-z]
        //var flags = new bool[26];
        //for(int i = 0; i < flags.Length; i++)
        //{
        //    flags[i] = false;
        //}

        //foreach(char character in myString.ToLower())
        //{
        //    if(character == ' ')
        //    {
        //        continue;
        //    }
        //    var index = character - 'a';
        //    flags[index] = true;
        //}

        //var isPanagaram = true;
        //foreach(bool flag in flags)
        //{
        //    if(flag == false)
        //    {
        //        isPanagaram = false;
        //        break;
        //    }
        //}

        //if (isPanagaram)
        //{
        //    Console.WriteLine("Panagram");
        //}
        //else
        //{
        //    Console.WriteLine("Not a Panagram");
        //}

        // Two min in a List:

        //var numbersList = new List<int>() { 9, 11, 10, 2, 3 };
        //var numbersList = new List<int>() { 9, 11, 10, 2, 2 };

        //var mini = int.MaxValue - 1;
        //var secondMini = int.MaxValue;

        //for(int i = 0;i<numbersList.Count;i++)
        //{
        //    if (numbersList[i] < mini)
        //    {
        //        secondMini = mini;
        //        mini = numbersList[i];
        //    }
        //    else if (numbersList[i] < secondMini && numbersList[i] != mini)
        //    {
        //        secondMini = numbersList[i];
        //    }
        //}

        //Console.WriteLine($"Mini: {mini}"); // 2

        //Console.WriteLine($"Second Mini: {secondMini}"); // 9

        //// finding two maximum numbers in a list:
        //var numbersArray = new int[5] { 11, 11, 10, 2, 7 };
        //var maxi = int.MinValue + 1;
        //var secondMaxi = int.MinValue;
        //for(int i= 0; i < numbersArray.Length; i++)
        //{
        //    if (numbersArray[i] > maxi)
        //    {
        //        secondMaxi = maxi;
        //        maxi = numbersArray[i];
        //    }
        //    else if (numbersArray[i]>secondMaxi && numbersArray[i] != maxi)
        //    {
        //        secondMaxi = numbersArray[i];
        //    }
        //}

        //Console.WriteLine($"Maxi: {maxi}"); // 11

        //Console.WriteLine($"Second Maxi: {secondMaxi}"); // 10


        // reversing a string:
        //string -> array -> string
        //var myString = "Deepak";

        //var charArray = myString.ToCharArray();

        //for (int i = 0; i < charArray.Length / 2; i++)
        //{
        //    // swapping:
        //    var temp = charArray[i];
        //    charArray[i] = charArray[myString.Length - i - 1];
        //    charArray[myString.Length - i - 1] = temp;
        //}

        //var res = new String(charArray);
        //Console.WriteLine(res);


        // another approach

        //for (int i = 0; i < charArray.Length; i++)
        //{
        //    charArray[i] = myString[myString.Length - 1 - i];
        //}

        //var res1 = new String(charArray);
        //Console.WriteLine(res1);

        // reversing a number:
        // pallindrome or not:

        //var userInput = 1114;
        //var originalInput = userInput;

        //var remainder = 0;
        //var reverse = 0;

        //while (userInput != 0)
        //{
        //    remainder = userInput % 10; // 4
        //    reverse = reverse * 10 + remainder; //0+4 
        //    userInput = userInput / 10; // quotient : 123

        //}

        //Console.WriteLine(reverse);
        //if(originalInput == reverse)
        //{
        //    Console.WriteLine("Pallidnrome number");
        //}
        //else
        //{
        //    Console.WriteLine("Not a Pallidnrome number");
        //}

        // string pallindrome:
        //var myString = "malayala";
        //var isPallindrome = true;
        //for(int i = 0; i < myString.Length / 2; i++)
        //{
        //    if (myString[i].ToString().ToLower() != myString[myString.Length - 1 - i].ToString().ToLower())
        //    {
        //        isPallindrome = false;
        //        break;
        //    }
        //}

        //if (isPallindrome)
        //{
        //    Console.WriteLine("Pallindrome");
        //}
        //else
        //{
        //    Console.WriteLine("Not a pallindrome");
        //}

        // Pascal case conversion:
        //var myString = "education is important";
        //var stringArray = myString.Split(' ');
        //var result = string.Empty;
        //foreach (string text in stringArray)
        //{
        //    result = result + text.Substring(0, 1).ToUpper() + text.Substring(1).ToLower();
        //}

        //Console.WriteLine(result);


        // factorial program:
        //var input = 5;
        //var factorial = 1;

        //for(int i = input; i > 0; i--)
        //{
        //    factorial = factorial * i;
        //}

        // Console.WriteLine(factorial); //120

        // sorting the numbers using bubble sort
        // ascending order

        //var numbersList = new List<int>() { 7, 25, 4, 18, 3, 9 };
        //var ListLength = numbersList.Count;

        //for(int i = 0; i < ListLength - 1; i++)
        //{
        //    for(int j = 0; j < ListLength - i - 1; j++)
        //    {
        //        if (numbersList[j] > numbersList[j + 1]) // for ascending order
        //        //if(numbersList[j] < numbersList[j+1]) // for descending order
        //        {
        //            var temp = numbersList[j];
        //            numbersList[j] = numbersList[j + 1];
        //            numbersList[j + 1] = temp;
        //        }
        //    }
        //}

        //foreach(var number in numbersList)
        //{
        //    Console.WriteLine(number);
        //}

        // Reversing a string 
        // String -> Array -> string:
        //var myString = "Simham";

        //var myArray = myString.ToCharArray();

        //for(int i = 0; i < myArray.Length/2; i++)
        //{
        //    var temp = myArray[i];
        //    myArray[i] = myArray[myArray.Length - 1 - i];
        //    myArray[myArray.Length - 1 - i] = temp;
        //}

        //var ReversedString = new string(myArray);

        //Console.WriteLine($"The Reversed format of string {myString} is {ReversedString}");

        // Duplicate or not:
        // Compiler should tell if we entered the number already or not:
        // User should enter 5 numbers to exit from the program:

        Console.WriteLine("Please enter 5 unique numbers to exit from the program:");
        var UniqueNumbersList = new List<int>();
        while (true)
        {
            if (UniqueNumbersList.Count == 5)
            {
                Console.WriteLine("Thank you for entering 5 unique numbers:");
                break;
            }

            Console.WriteLine("Please enter a number: ");
            var InputNumber = Convert.ToInt32(Console.ReadLine());
            var IsDuplicate = false;

            for(int i = 0; i < UniqueNumbersList.Count; i++)
            {
                if (UniqueNumbersList[i] == InputNumber)
                {
                    IsDuplicate = true;
                    break;
                }
        
            }

            if (IsDuplicate)
            {
                Console.WriteLine("Please enter Unique numbers only");
            }
            else
            {
                UniqueNumbersList.Add(InputNumber);
            }
        }

        var Result = string.Join(',', UniqueNumbersList);

        Console.WriteLine(Result);
        

        // Another version of string reverse, using Helper method
        // String reverse program:(1st round Carrier)
        // i/p: "Deepak Moningi", o/p: "kapeed igninom"


        //var userInput = "Deepak Moningi";

        //var namesArray = userInput.Split(" ");


        //for(int i=0;i<namesArray.Length;i++)
        //{
        //    namesArray[i] = reverseString(namesArray[i]); // helper method
        //}

        //// converting namesArray to the string (resultString)
        //var resultString = string.Join(" ", namesArray); // join method will return a string, it will convert the array to string by adding specified delimeter between each element in the array

        //Console.WriteLine(resultString); // "Kapeed igninoM"


    }

    //public static string reverseString(string inputString)
    //{
    //    var charArray = inputString.ToCharArray();

    //    for(int i = 0; i < charArray.Length/2; i++)
    //    {
    //        var temp = charArray[i];
    //        charArray[i] = charArray[charArray.Length - 1 - i];
    //        charArray[charArray.Length - 1 - i] = temp;
    //    }

    //    return new string(charArray);
    //}
  
}
﻿using System.Collections;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        //// Input validation program:
        //Console.WriteLine("Please enter a number between 1 to 10 and click enter button:");
        //var userInput = Console.ReadLine();
        //var input = Convert.ToInt32(userInput);

        //if(input>=1 && input <= 10)
        //{
        //    Console.WriteLine("Valid");
        //}
        //else
        //{
        //    Console.WriteLine("Invalid");
        //}

        //// Max of two numbers:
        //Console.WriteLine("Please enter two numbers:");
        //var firstInput = Convert.ToInt32(Console.ReadLine());
        //var secondInput = Convert.ToInt32(Console.ReadLine());
        //if (firstInput > secondInput)
        //{
        //    Console.WriteLine(string.Format("maximum number is: {0}",firstInput));

        //}
        //else
        //{
        //    Console.WriteLine(string.Format("maximum number is: {0}", secondInput));
        //}


        // vehicle speed program : my code

        //Console.WriteLine("Please enter the Speed Limit:");
        //var speedLimit = Convert.ToInt32(Console.ReadLine());
        //var demeritPoints = 0;
        //var maxDemeritPoints = 12;

        //while(maxDemeritPoints == 12)
        //{

        //    Console.WriteLine("Please enter the Car speed:");
        //    var carSpeed = Convert.ToInt32(Console.ReadLine());
        //    if (carSpeed < speedLimit)
        //    {
        //        Console.WriteLine("OK");
        //    }
        //    else if (carSpeed > speedLimit)
        //    {
        //        if(carSpeed >= (speedLimit + 5))
        //        {
        //            demeritPoints = demeritPoints + 1;

        //            if (demeritPoints == 12)
        //            {
        //                Console.WriteLine(string.Format("License Suspended as you reached the maximum demerit points: {0}",demeritPoints));
        //                break;
        //            }

        //            Console.WriteLine(string.Format("Demeritpoints: {0}",demeritPoints));
        //        }
        //        else
        //        {
        //            Console.WriteLine("You are crossing ther speed limit and you may get demerit point");
        //        }

        //    }

        //}

        // vehicle program : copilot:

        //Console.WriteLine("Please enter the Speed Limit:");
        //var speedLimit = Convert.ToInt32(Console.ReadLine());
        //var demeritPoints = 0;

        //while (true)
        //{

        //    Console.WriteLine("Please enter the Car speed:");
        //    var carSpeed = Convert.ToInt32(Console.ReadLine());
        //    if (carSpeed <= speedLimit)
        //    {
        //        Console.WriteLine("OK");
        //    }
        //    else
        //    {
        //            demeritPoints = demeritPoints + (carSpeed-speedLimit)/5;
        //            if (demeritPoints > 12)
        //            {
        //                Console.WriteLine(string.Format("License Suspended as you reached more than maximum demerit points 12: {0}", demeritPoints));
        //                break;
        //            }
        //            else
        //            {
        //                Console.WriteLine(string.Format("Demeritpoints: {0}", demeritPoints));

        //            }
        //    }
        //}




        // Name echo program: using break;
        //while (true)
        //{
        //    Console.Write("Enter your name: ");
        //    var input = Console.ReadLine();

        //    if (string.IsNullOrWhiteSpace(input))
        //    {
        //        break;
        //    }

        //    Console.WriteLine("Echo: "+ input);
        //}

        // Name echo program using continue:
        //while (true)
        //{
        //    Console.Write("enter your name:");
        //    var input = Console.ReadLine();

        //    if (!(string.IsNullOrWhiteSpace(input))) // if user entered the name then this condition will  be true bcoz is null or white space will return false 
        //    {
        //        Console.WriteLine("Echo: "+ input);
        //        continue; // to send the compiler to while loop starting
        //    }

        //    break; // if user not entered or enetered any white spaces (as it won't go to the above if loop) then it will break and control won't go to the next line
        //}


        // Control flow exercises:

        // Number of numbers bewtween one to hundred divisible by 3:
        //var numberCount = 0; 
        //for(var i=1; i <= 100; i++)
        //{
        //    if(i % 3 == 0)
        //    {
        //        numberCount = numberCount + 1;
        //    }

        //}
        //Console.WriteLine(numberCount);



        // Adding user input numbers as a sum program:
        //var inputSum = 0;
        //while (true)
        //{
        //    Console.Write("enter a number or \"ok\" to exit:");
        //    var userInput = Console.ReadLine();

        // if(int.TryParse(userInput, out int number))
        //    {
        //        inputSum = inputSum + number;
        //    }
        //    else if(userInput.ToLower() == "ok")
        //    {
        //        Console.WriteLine(string.Format("Your input sum is: {0}",inputSum));
        //        break;
        //    }
        //    else 
        //    {
        //        Console.WriteLine("invalid input, Please enter a number or ok to exit");
        //    }

        //}


        // factorial program:
        //int factorialValue = 1;
        //Console.Write("Please enter a number to get it's factorial:");
        //var userInput =  Convert.ToInt32(Console.ReadLine());
        //for(int i= userInput; i>=1; i--)
        //{
        //    factorialValue = factorialValue * i;
        //}

        ////for(int i = 1; i <= userInput; i++)
        ////{
        ////    factorialValue = factorialValue * i;
        ////}

        //Console.WriteLine($"{userInput}! = {factorialValue}");


        // secret random number guesing program:

        //var random = new Random();
        //var secretNumber = random.Next(1,11); // code to generate a random number between 1 and 10 , here it will include min but not max that's why wrote 11 as max
        //Console.WriteLine($"{secretNumber}");
        //for(int i = 1; i <= 4; i++)
        //{
        //    Console.Write("You have four chances, Guess and enter the secret number that is generated by the Random class:");
        //    var userInput = Convert.ToInt32(Console.ReadLine());
        //    if(userInput == secretNumber)
        //    {
        //        Console.WriteLine("You won");
        //        break;
        //    }
        //    else
        //    {
        //        // we can use the i variable like this too:
        //        if (i == 4)
        //        {
        //            Console.WriteLine("You lost");
        //            break;
        //        }
        //        Console.WriteLine("Wrong guess, Try again");
        //    }
        //}

        // Max and second max of provided numbers : (my approach) 
        // minus here is while transferring all the numbers from numbers to newnumbers array we are excluding the max numbers 
        // as we are excluding that in the new numbers array the instead of max number it will fill with 0,
        // this is not a good practice so instead, please see the coe from line number 242

        //var numbers = new int[5] { 5, 3, 8, 1, 4 };

        //var newNumbers = new int[5];

        //for (int i=0; i < numbers.Length; i++)
        //{
        //    if (numbers[i] == numbers.Max())
        //    {
        //        continue;
        //    }
        //    newNumbers[i] = numbers[i];
        //}


        //Console.WriteLine(numbers.Max()); // first max number : 8

        //Console.WriteLine(newNumbers.Max()); //second max number :5



        //max and second max of provided numbers: (copilot)
        //var numbers = new int[5] { 5, 3, 8, 1, 4 };

        //var newNumbers = new List<int>(); // created list to get the storage with dynamic size, we don't have to declare the size of the list

        //for(int i =0; i<numbers.Length; i++)
        //{
        //    if (numbers[i] == numbers.Max())
        //    {
        //        continue; // skipping the max(8) and control will go to 247 line 
        //    }

        //    newNumbers.Add(numbers[i]); // adding numbers to new numbers list except max(8)
        //    // we have to use .add to add the values to the list 

        //}

        //Console.WriteLine(numbers.Max()); //8

        //Console.WriteLine(newNumbers.Max()); //5

        // max number from the user input:
        //Console.WriteLine(@"Please enter five numbers seperated with a coma to get the max number from it ",":");
        //var userInput = Console.ReadLine();

        //var test = userInput.Split(",");

        //var numbersArray = new int[5]; // we can also create the integer list here:

        //for(int i=0; i<test.Length; i++)
        //{
        //    numbersArray[i] = Convert.ToInt32(test[i]);
        //}


        //var maxNumber = numbersArray.Max();
        //Console.WriteLine(maxNumber); //8


        // finding the max number in the array with out using built in methods (Max());
        // var numbersArray = new int[6] { 29, 5, 3, 8, 1, 4 }; 
        // Now, here the numbersArray is the instance variable of the type Array class.
        // So we can use the non static properties and methods of array class using this instance variable.

        //var maxNumber = 0;

        //for(int i =0; i < numbersArray.Length; i++)
        //{

        //    if(numbersArray[i] >= maxNumber)
        //    {
        //        maxNumber = numbersArray[i];

        //    }
        //    else
        //    {
        //        continue;
        //    }

        //}

        //Console.WriteLine(maxNumber);

        // finding the second max in the array with out using built in methods (Max()): my code

        //var numbersArray = new int[5] {5, 3, 8, 1, 4 };
        //var MaxNumber = 0;

        //for(int i = 0; i< numbersArray.Length; i++)
        //{
        //    if (numbersArray[i] >= MaxNumber)
        //    {
        //        MaxNumber = numbersArray[i];
        //    }
        //    else
        //    {
        //        continue;
        //    }
        //}

        //Console.WriteLine(MaxNumber);

        //// we got the max number:
        //var numbersList = new List<int>();
        //foreach(var number in numbersArray)
        //{
        //    if(number == MaxNumber)
        //    {
        //        continue;
        //    }
        //    else
        //    {
        //        numbersList.Add(number);
        //    }
        //}

        //// we will get second max from the list : numbers List
        //var secondMax = 0;
        //for(int i=0; i < numbersList.Count; i++)
        //{
        //    if (numbersList[i] > secondMax)
        //    {
        //        secondMax = numbersList[i];
        //    }
        //    else
        //    {
        //        continue;
        //    }
        //}

        //Console.WriteLine(secondMax);

        // finding the second max in the array with out using built in methods (Max()): Copilot

        //var numbersArray = new int[11] { 0, 5, 0, 29, 3, 8, 29, 1, 21, 4, 21 };
        //var maxNumber = 0;
        //// to get the first max number:

        //for(int i = 0; i < numbersArray.Length; i++)
        //{
        //    if (numbersArray[i] >= maxNumber)
        //    {
        //        maxNumber = numbersArray[i];
        //    }
        //}

        //Console.WriteLine(maxNumber); // we got max number

        //// to get the second max number
        //var secondMaxNumber = 0;
        //for(int i = 0; i < numbersArray.Length; i++)
        //{
        //    if ((numbersArray[i] != maxNumber) && (numbersArray[i] >= secondMaxNumber))
        //    {
        //        secondMaxNumber = numbersArray[i];
        //    }
        //}

        //Console.WriteLine(secondMaxNumber); // we got second max number

        // Find min and second min number without using built in methods:

        //var numbersArray = new int[7] { 5, 0, 3, -1, 8, 1, 4 };

        //var minNumber = numbersArray[0]; // assigining 5

        // we know that we have already assigned first value inside an array to the minNumber variable
        // so if we check the if condition it will satisfy anyways to to skip that we are starting the i from 1 and 
        // as the inex will stop at 4th index we kept condition like i<numbersArray.length i.e; i<5: 1,2,3,4 : four iterations for four numbers in the array.

        //for(int i = 1; i<numbersArray.Length; i++)
        //{
        //    if (numbersArray[i] <= minNumber)
        //    {
        //        minNumber = numbersArray[i];
        //    }
        //}
        //Console.WriteLine(minNumber); // we got the min number 1

        //var secondMinNumber = numbersArray[0]; //5
        //for(int i=1; i<numbersArray.Length; i++)
        //{
        //    if ((numbersArray[i] != minNumber) && numbersArray[i]<= secondMinNumber)
        //    {
        //        secondMinNumber = numbersArray[i];
        //    }

        //}

        //Console.WriteLine(secondMinNumber); // we got second min number : 3


        // Arrays and lists:
        // exercises:

        // Facebook likes program: (my code)


        //var loopVariable = true;
        //while (loopVariable)
        //{
        //    Console.Write(@"Enter the people names those who liked the post seperated with the coma ',' and click the enter button: ");
        //    var names = Console.ReadLine();

        //    var namesArray = !string.IsNullOrEmpty(names) ? names?.Split(",") : [];
        //    // here we wrote some condition using the ternary operator ?.
        //    // because when user don't enter anything in console.readline(),
        //    // C# will retrive it as an empty string and while using the split on the empty string it will store that empty string as an element at first position in the array.
        //    // So, for the switch case, if array having length one still user is not providing any input.
        //    // that's why before creating an array using split we are checking the names string and if string is not null or empty then we creating array with those values
        //    // if user provided null or empty then we are assgining empty array, and the length of empty array will be 0 and control will go to the case 0 and it will terminate the program.

        //    switch(namesArray?.Length)
        //    {
        //        case 0  : // namesArray.Length = 0
        //            Console.WriteLine(" ");
        //            loopVariable = !loopVariable;
        //            break;


        //        case 1: // namesArray.Length = 1
        //            Console.WriteLine($"[{namesArray[0]}] likes your post.");
        //            break; 

        //        case 2: // namesArray.Length = 2
        //            Console.WriteLine($" [{namesArray[0]}] and [{namesArray[1]}] like your post.");
        //            break;

        //        case >=3: // namesArray.Length >=3  
        //            Console.WriteLine($" [{namesArray[0]}], [{namesArray[1]}] and [{namesArray.Length - 2}] like your post.");
        //            break;

        //        default: // if namesArray.Length!= 0,1,2,>3
        //            Console.WriteLine("Invalid input");
        //            break;

        //    }

        //}

        // Array Initialization: You can't initialize an empty array with [], use new string[0] instead. (Copilot Suggestion)

        // Facebook likes program: (Copilot)

        //while (true)
        //{
        //    Console.Write(@"Enter the people names those who liked the post seperated with the coma ',' and click the enter button: ");
        //    var names = Console.ReadLine();

        //    if (string.IsNullOrEmpty(names))
        //    {
        //        break;
        //    }

        //    var namesArray = names.Split(",");

        //    switch (namesArray.Length)
        //    {
        //        case 0:
        //            Console.WriteLine("");
        //            break;


        //        case 1: // namesArray.Length = 1
        //            Console.WriteLine($"[{namesArray[0]}] likes your post.");
        //            break;

        //        case 2: // namesArray.Length = 2
        //            Console.WriteLine($" [{namesArray[0]}] and [{namesArray[1]}] like your post.");
        //            break;

        //        case >= 3: // namesArray.Length >=3  
        //            Console.WriteLine($" [{namesArray[0]}], [{namesArray[1]}] and [{namesArray.Length - 2}] like your post.");
        //            break;

        //        default: // if namesArray.Length!= 0,1,2,>3
        //            Console.WriteLine("Invalid input");
        //            break;
        //    }
        //}


        // name reverse program:
        // string -> array-> string 

        //Console.WriteLine("Please enter your name to get the reverse of your name:");
        //var name = Console.ReadLine();
        //var nameArray = new char[name.Length]; 

        //for(int i=0; i < name.Length; i++)
        //{
        //    nameArray[i] = name[i];
        //}

        //// now in the character array we have our name

        //var resultString = "";

        //for(int i = nameArray.Length-1 ; i>=0; i--)
        //{
        //    // resultString[i] = nameArray[i]; // my idea: it won't work beacuse I have declared the string and in c# once the string is declared we can't modify it.

        //    resultString = resultString + nameArray[i]; // copilit idea
        //    // appending the string like this as we can't made any changes to the string once it is declared but we can append

        //    //Console.Write(nameArray[i]); we can also log the reversed string like this but as per question we have to store the reversed string into a string and then log the string to the console.
        //}

        //Console.WriteLine(resultString);


        // five unique numbers program with Contains() in built method:

        //Console.WriteLine("You must have to enter five unique numbers to exit:");
        //var numbersList = new List<int>();

        //while (numbersList.Count < 5 )
        //{
        //    var userInput = Convert.ToInt32(Console.ReadLine());

        //    if (numbersList.Contains(userInput))
        //    {
        //        Console.WriteLine("Error: Please enter unique numbers only");
        //        continue;
        //    }

        //    numbersList.Add(userInput);
        //}

        //numbersList.Sort();
        //foreach(var number in numbersList)
        //{
        //    Console.Write(number);
        //}


        // copilot is ok with my code 
        // but with out built in methods:
        // copilot code
        //Console.WriteLine("You must have to enter five unique numbers to exit:");
        //var numList = new List<int>();
        //while (numList.Count < 5)
        //{
        //    var userInput = Convert.ToInt32(Console.ReadLine());

        //    var isDuplicate = false;


        //    foreach (var number in numList)
        //    {
        //        if(number == userInput)
        //        {
        //            isDuplicate = true;
        //            break;
        //        }
        //    }

        //    if (isDuplicate)
        //    {
        //        Console.WriteLine("Error: please enter only unique numbers");
        //    }
        //    else
        //    {
        //        numList.Add(userInput);
        //    }
        //}

        // enter number or quit program:

        //var numbersList = new List<int>();
        //var uniqueNumberList = new List<int>(); 
        //while (true)
        //{
        //    Console.Write("Enter a number or type 'Quit' to exit from the program:");
        //    var userinput = Console.ReadLine();

        //    if(int.TryParse(userinput, out int number))
        //    {
        //        numbersList.Add(number);
        //    }

        //    else if(userinput?.Trim().ToLower() == "quit")
        //    {
        //        // code to display the unique numbers inside the numbersList
        //        foreach(var num in numbersList)
        //        {
        //            bool isDuplicate = false;

        //            foreach(var n in uniqueNumberList)
        //            {
        //                if(n == num)
        //                {
        //                    isDuplicate = true; // making isDuplicate is true because there is already a same number(num) in unique number list
        //                    break;
        //                }
                            
        //            }
                        

        //            if (!isDuplicate) // if the number(num) is not there in the unique number list then control will come here and add the number(num) to unique number list
        //            {
        //                uniqueNumberList.Add(num);
        //            }   
        //        }
        //        break;// breaking the while loop as at this point every number will shift to unique numbers list uniquely

        //    }

        //}

        //foreach(var n in uniqueNumberList)
        //{
        //    Console.WriteLine(n);
        //}


        // 3 small numbers in the list:


        //var threeMinNumbersList = new List<int>();

        //while (true)
        //{
        //    Console.Write("you must have to enter 5 numbers seperated with ',': ");
        //    var userInput = Console.ReadLine();

        //    var stringArray = userInput?.Split(",");

        //    var intList = new List<int>();  

        //    for(int i = 0; i<stringArray?.Length; i++)
        //    {
        //        intList.Add(Convert.ToInt32(stringArray[i]));
        //    }


        //    if(intList.Count < 5)
        //    {
        //        Console.WriteLine("Invalid List");
        //        continue;

        //    }

        //    else
        //    {
        //        // code to get the three small numbers in intList


        //        var firstMinNumber = intList[0];

        //        for (int i = intList.Count-1; i >= 0; i--)
        //        {
        //            if (intList[i] <= firstMinNumber)
        //            {
        //                firstMinNumber = intList[i];
        //            }                    
        //        }
        //        // we can get the first min number like this
        //        // adding first min number to the list 
        //        threeMinNumbersList.Add(firstMinNumber);

        //        var secondMinNumber = intList[0];
        //        for(int i=intList.Count-1; i >= 0; i--) 
        //        {
        //            if ((intList[i] != firstMinNumber) && intList[i]<=secondMinNumber)
        //            {
        //                secondMinNumber = intList[i];
        //            }
        //        }
        //        // we can get the second min number 
        //        // adding second min number to the 
        //        threeMinNumbersList.Add(secondMinNumber);

        //        var thirdMinNumber = intList[0];

        //        for(int i = intList.Count-1; i > 0; i--)
        //        {
        //            if ((intList[i] != firstMinNumber && intList[i]!= secondMinNumber) && intList[i] <= thirdMinNumber)
        //            {
        //                thirdMinNumber = intList[i];
        //            }
        //        }
        //        threeMinNumbersList.Add(thirdMinNumber);
        //        break;
        //    }
        //}

        //foreach (var number in threeMinNumbersList)
        //{
        //    Console.WriteLine(number); // i/p: 5,8,3,1,4 -> o/p : 1,3,4
        //}


        // working with text exercises:
        // consecutive or not program:

        //Console.Write("Enter a few numbers seperated with a '-' and click enter:");
        //var inputArray = Console.ReadLine()?.Split('-');


        //var numbersList = new List<int>();

        //foreach(var inp in inputArray)
        //{
        //    numbersList.Add(Convert.ToInt32(inp));
        //}

        //var isConsecutinve = false;

        //for (int i = 0; i < numbersList.Count-1; i++)
        //{
        //    // i/p: 20,19,18 : after || 
        //    // i/p: 18,19,20 : before ||
        //    if (numbersList[i] + 1 == numbersList [i+1] || numbersList[i] - 1 == numbersList[i + 1])
        //    {
        //        isConsecutinve = true;
        //    }
        //    else
        //    {
        //        isConsecutinve = false;
        //        break;
        //    }
        //}

        //if (isConsecutinve)
        //{
        //    Console.WriteLine("Consecutive");
        //}
        //else
        //{
        //    Console.WriteLine("Not Consecutive");
        //}



        // enter or find a duplicate program:

        // Console.Write("Enter few numbers seperated with '-' and click enter or directly click enter button to EXIT:");
        // var userInput = Console.ReadLine();

        // if (string.IsNullOrEmpty(userInput))
        // {
        //     return;
        // }

        // var userInputArray = userInput.Split('-');
        // var numbersList = new List<int>();

        // var uniqueNumbersList = new List<int>();

        // foreach(var number in userInputArray)
        // {
        //     numbersList.Add(Convert.ToInt32(number));
        // }

        //foreach(var num in numbersList)
        // {
        //     var isDuplicate = false;
        //     foreach(var n in uniqueNumbersList)
        //     {
        //         if(num == n)
        //         {
        //             isDuplicate = true;
        //             break;
        //         }
        //     }

        //     if (isDuplicate)
        //     {
        //         Console.WriteLine("Duplicate");
        //         break;
        //     }
        //     else
        //     {
        //         uniqueNumbersList.Add(num);
        //     }
        // }

        // Valid 24 hour format time checking program:(copilot)
        //Console.Write("Please enter a valid 24 hour format time:");
        //var userInput = Console.ReadLine();

        //if (string.IsNullOrEmpty(userInput))
        //{
        //    Console.WriteLine("Invalid Time");
        //    return;
        //}

        //TimeSpan.TryParse(userInput, out TimeSpan time);

        //if(time > TimeSpan.FromHours(0) && time < TimeSpan.FromHours(24))
        //{
        //    Console.WriteLine("OK");
        //}
        //else
        //{
        //    Console.WriteLine("Invalid time");
        //}



        // pascal case conversion programL: (my code):
        //Console.Write("Enter a few words seperated with a space ' ' and click enter button: ");
        //var userInput = Console.ReadLine()?.Split(' ');

        //foreach (var word in userInput)
        //{
        //    Console.Write
        //    (
        //        word
        //       .ToLower()
        //       .Replace(word[0].ToString(), word[0].ToString().ToUpper())
        //    );

        //    // if i/p is students then o/p : StudentS // not correct


        //}

        // In my code there is a biggest drawback of using the replace() method:

        // Firstly, I don't know how this replace() method works

        // after speaking with copilot, i know that if we use replace method on a string then what the target we specified it will replace it with every occurance in the string
        // but we only want our first word to be capital and rest to be lower
        // tahts's why I got 

        // Pascal case conversion program:

        //Console.Write("Enter a few words seperated with a space ' ' and click enter button: ");
        //var userInput = Console.ReadLine()?.Split(' ');

        //var pascalString = "";

        //foreach(var word in userInput)
        //{
        //    pascalString = pascalString + word[0].ToString().ToUpper() + word.Substring(1).ToLower(); 
        //}

        //Console.WriteLine(pascalString);


        // Count of number of vowels in a string program:

        //Console.Write("Please enter a english word: ");
        //var userInput = Console.ReadLine();

        //var vowelsArray = new char[5] { 'a', 'e', 'i', 'o', 'u' };

        //var count = 0;

        ////foreach(var character in userInput)
        ////{
        ////    if (vowelsArray.Contains(character))
        ////    {
        ////        count++;
        ////    }
        ////}

        //foreach(var vowel in vowelsArray)
        //{
        //    foreach(var character in userInput)
        //    {
        //        if(character == vowel)
        //        {
        //            count++;
        //        }
        //    }
        //}

        //Console.WriteLine(count);

        //Console.Write("Enter the number of elements: ");
        //var userInput = Convert.ToInt32(Console.ReadLine());

        //var numbersArray = new int[userInput];
        //Console.WriteLine($"Please enter {userInput} values:");


        //for (int i = 0; i < userInput; i++)
        //{
        //    var input = Convert.ToInt32(Console.ReadLine());
        //    numbersArray[i] = input;
        //}

        //foreach(var number in numbersArray)
        //{
        //    Console.Write(number);
        //}

        //var firstMinValue = numbersArray[0];

        //for(int i=0; i < userInput; i++)
        //{
        //    if (numbersArray[i] < firstMinValue)
        //    {
        //        firstMinValue = numbersArray[i];
        //    }
        //}

        //Console.WriteLine($"First Minimum number: {firstMinValue}");

        //var secondMinValue = numbersArray[0];

        //for(int i=0; i < userInput; i++)
        //{
        //    if (numbersArray[i] != firstMinValue && numbersArray[i] < secondMinValue)
        //    {
        //        secondMinValue = numbersArray[i];
        //    }

        //}
        //Console.Write($"Second Minimum number: {secondMinValue}");


        //var minimum = int.MaxValue - 1;

        //var secondMinimum = int.MaxValue;

        //for(int i=0; i < userInput; i++)
        //{
        //    if (numbersArray[i] < minimum )
        //    {
        //        secondMinimum = minimum;
        //        minimum = numbersArray[i];

        //    }
        //}

        
        //Console.WriteLine(minimum);

        //if(secondMinimum == int.MaxValue-1)
        //{
        //    Console.WriteLine("There is no second min");
        //}

       

    }
}
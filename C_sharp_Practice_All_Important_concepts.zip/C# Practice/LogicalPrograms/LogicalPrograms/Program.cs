﻿using System;
using System.Linq;

Console.WriteLine("Hello, World!");


// retrive the index of the first duplicate number from the below list:

// Using Dictionary:

var NumbersArray = new int[6] { 1,3,5,7,9,1};


var NumbersDictionary = new Dictionary<int, int>();


var Index = 0;

for (int i=0; i<NumbersArray.Length;i++)
{
    if (NumbersDictionary.Keys.Contains(NumbersArray[i]))
    {
        Index = i;
        break;
    }
    else
    {
        NumbersDictionary.Add(NumbersArray[i], 1);
    }
}

Console.WriteLine($"The index of duplicate element is: {Index}");


//using a List with contains() method (Alternative):


var numbers = new List<int>();


for (int i = 0; i < NumbersArray.Length; i++) {

    if (numbers.Contains(NumbersArray[i]))
    {
        Index = i;
        break;
    }
    else
    {
        numbers.Add(NumbersArray[i]);
    }
}

Console.WriteLine($"The index of duplicate element is: {Index}");



//using a List without contains() In builts method:

var NumbersList = new List<int>();

var MyIndex = 0;

for(int i = 0; i < NumbersArray.Length; i++)
{
    for(int j = 0; j < NumbersList.Count; j++)
    {
        if (NumbersList[j] == NumbersArray[i])
        {
            MyIndex = i;
            break;
        }
    }
    NumbersList.Add(NumbersArray[i]);
}

Console.WriteLine($"The index of duplicate element is: {MyIndex}");




// Find the index of a element inside array:

// Get the index of number 9 from the below array:


var MyArray = new int[5] { 9, 88, 13, 3, 8 };

var TargetNumber = 88;

var StoreIndex = 0;

// Using built in function:
//Array.Sort(MyArray);

// To sort the array using Bubble sort w/o built in (Array.Sort(Source array)) function:

for(int i = 0; i < MyArray.Length - 1; i++)
{
    for(int j = 0; j < MyArray.Length - 1 - i; j++)
    {
        if (MyArray[j] > MyArray[j + 1])
        {
            var temp = MyArray[j];
            MyArray[j] = MyArray[j + 1];
            MyArray[j + 1] = temp;
        }
    }
}


// Binary search:
// for binary search the array should be sorted, so we sorted the array in ascending order using bubble sort:

var Low = 0;
var High = MyArray.Length - 1;

while (Low <= High)
{
    var Mid = (Low + High) / 2;

    if (MyArray[Mid] == TargetNumber)
    {
        StoreIndex = Mid;
        break;
    }
    else if (MyArray[Mid] < TargetNumber)
    {
        Low = Mid + 1;
    }
    else
    {
        High = Mid - 1;
    }
}


Console.WriteLine($"The index of number: {TargetNumber} is at {StoreIndex}");


// 

















﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception_handling___custom_exceptions
{
    public class YouTubeException:Exception
    {
        public YouTubeException(string Message,Exception innerException):base(Message, innerException)
        {

        }
    }
}

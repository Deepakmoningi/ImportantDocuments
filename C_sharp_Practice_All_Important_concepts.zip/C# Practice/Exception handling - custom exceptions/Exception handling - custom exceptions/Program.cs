﻿using Exception_handling___custom_exceptions;

public class Program 
{ 
    // custom exceptions
    // .Net framework provides us a lot of exceptions by default then what is the need to create our own custom exceptions?
    // answer: if none of of the default exceptions wont describe or handle our problem then we can to create our own exception:
    // example: 
    public static void Main()
    {
        //pre requisite: inner exception:


        // global exception handling block:
        try
        {
            var YouTubeObj = new YouTubeApi();
            var MoshVideos =  YouTubeObj.GetVideos("Mosh"); 
            // here we will get exception because we are throwing an exception in YouTubeApi class inside the catch block so the control will come here(the caller of that method)

        }
        catch(Exception ex)
        {
            // handling our custom YouTube exception inside the catch block:
            Console.WriteLine($"Our custom exception: {ex.Message}"); // Unable to fetch videos from the YouTube: our Custom exception

            // here the actual exception is : Some low level YouTube error(original exception), im real life the exception may be socket issue, server issue or network issue
            // if we send the exceptions like above the users wont understood so by using the custom exception we can send the custom exception(YoutubeException("Unable to fetch the videos/data from youtube"))

            // but for developers they have to debug to know the actual issue, they can get the actual exception(inner exception) that we have wrapped inside our custom exception(YoutubeException(msg,ex)), this we can acheive using inner exceptions:

            Console.WriteLine($"Original exception: {ex.InnerException?.Message}"); // logs the original exception, the exception that is the main reason for compiler to get here

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception_handling___custom_exceptions
{
    public class YouTube
    {
        public int Video_Id { get; set; }

        public string?  Channel_Name { get; set; }

    }
}

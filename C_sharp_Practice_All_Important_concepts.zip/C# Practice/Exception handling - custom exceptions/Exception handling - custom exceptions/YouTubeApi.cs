﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception_handling___custom_exceptions
{
    public class YouTubeApi
    {
        public List<YouTube> GetVideos(string Username)
        {
            try
            {
                // simulating a exception:
                // base/original exception
                throw new Exception("Some low level YouTube error");
            }
            catch (Exception ex)
            {
                // handling the exception here:
                // here we want to throw a custom exception:
                // wrapping up the original exception(ex) inside the current exception object(YouTubeException):
                throw new YouTubeException("Unable to fetch videos from the YouTube", ex);
                // 1st param is message which is a string
                // 2nd parameter is a exception to wrap the original exception inside the current/custom exception

            }
        }
    }
}

﻿using System;
public class StringInterviewQuestions
{
    static void Main()
    {
        // Program 1: pallindrome or not program:
        //Console.WriteLine("Enter the string:");
        //var userInput = Console.ReadLine();

        //var isPallindrome = true;

        //for(int i = 0; i < userInput.Length / 2; i++)
        //{
        //    if (userInput[i].ToString().ToLower() != userInput[userInput.Length - i - 1].ToString().ToLower())
        //    {
        //        isPallindrome=false;
        //        break;
        //    }
        //}

        //if (isPallindrome)
        //{
        //    Console.WriteLine($"{userInput} is a Pallindrome:");
        //}
        //else
        //{
        //    Console.WriteLine($"{userInput} is not a Pallindrome:");

        //}

        // Program2 :reversing a string program:
        //Console.WriteLine("Enter the string:");
        //var userInput = Console.ReadLine();

        // converting the userInput string to char array as the string is immutable and we can't swap one char with another char in string like we do in the array
        //var charArray = userInput.ToCharArray();

        //for(int i = 0;i < userInput.Length / 2; i++)
        //{
        //    var temp = charArray[userInput.Length - i - 1];
        //    charArray[userInput.Length - i - 1] = charArray[i];
        //    charArray[i] = temp;
        //}

        // again making the array to string(reversed string)
        //var reversedString = new string(charArray);
        //Console.WriteLine(reversedString);

        // Program 3: Reverse a number porgram:
        //Console.WriteLine("Enter the number:");
        //var userInput = Console.ReadLine();


        //if(int.TryParse(userInput, out int inputNumber))
        //{
        //    var remainder = 0;
        //    var reversed = 0;
        //    while (inputNumber != 0)
        //    {
        //        remainder = inputNumber % 10; // (we will get remainder) if input number is 1234 then for first iteration we will get the remainder as 4
        //        reversed = reversed * 10 + remainder; // after first iteration the reversed will be 0*10+4 = 4 and for second iteration 4*10 + 3 = 43 and next 432  and next 4321(reversed for the inputString) 
        //        inputNumber = inputNumber / 10; // (we will get quotient) if input number is 1234 then for first iteration we will get the quotient as 123
        //    }

        //    Console.WriteLine($"Reverse for the number you entered:{reversed}");

        //}

        //else
        //{
        //    Console.WriteLine("Invalid number");
        //}

        // Program 4:Print duplicate character in a string:
        //Console.WriteLine("Enter the string:");
        //var userInput = Console.ReadLine();

        //var myDictionary = new Dictionary<char, int>();

        //foreach(char character in userInput)
        //{
        //    if (myDictionary.Keys.Contains(character))
        //    {
        //        myDictionary[character] = myDictionary[character] + 1;
        //    }
        //    else
        //    {
        //        myDictionary.Add(character, 1);
        //    }
        //}

        //Console.WriteLine("Duplicate characters in the string:");
        //// if we want to display the duplicate characters and the count of them:
        //foreach(var key in myDictionary.Keys)
        //{
        //    if (myDictionary[key] > 1)
        //    {
        //        Console.WriteLine($"{key} - {myDictionary[key]}"); // it will only log the duplicate characters and their coount as we wrote > 1 in if condition:
        //    }
        //}

        //Console.WriteLine();
        //Console.WriteLine("Unique characters in the string");
        //// if we want to display only the unique characters
        //foreach(var key in myDictionary.Keys)
        //{
        //    if (myDictionary[key] == 1)
        //    {
        //        Console.WriteLine($"{key}"); // it will only log the unique characters as we wrote == 1 in if condtion
        //    }
        //}


        // check one string is a rotation of another string:
        // this is not like a pallindrome 
        // eg: string in ABCD
        // then if we start from B then the rotated string will be BCDA.
        // and if we start from C then the rotated string will be CDAB.
        // and if we start from D then the rotated string will be DABC.
        // but we cant make our rotated string using combinations for the main String: ADBC : this is not valid string(we must have to follow the order(order there in main string))

        // Now we have to check now whether these rotated strings are there in our string ABCD or not.
        // if our string contains the rotated strings then we can say that the input string is a rotation of another string.

        //var myString = "ABCD";
        //Console.WriteLine($"Please enter the rotated string from {myString}:");
        //var rotatedString = Console.ReadLine();

        //if(myString.Length != rotatedString.Length)
        //{
        //    Console.WriteLine($"No the provided string: {rotatedString} is not a rotation for the main string: {myString}");
        //}
        //else
        //{
        //    var concatinatedString = myString + myString;
        //    if (concatinatedString.Contains(rotatedString))
        //    {
        //        Console.WriteLine($"Yes the provided string: {rotatedString} is a rotation for the main string: {myString}");
        //    }
        //    else
        //    {
        //        Console.WriteLine($"No the provided string: {rotatedString} is not a rotation for the main string: {myString}");

        //    }
        //}


        // check given two strings are anagrams or not:
        // anagram: it is same like the previous program but here the string can have any format using the first string characters:
        // example: our string is [a,b,d](wrote in array approach for understanding)
        // if the input is [a,d,b] or [b,d,a] or [d,b,a] like this then the both strings are anagrams

        //var myString = "abc";
        //Console.WriteLine($"please enter the string to check for anagram with this string {myString}");
        //var userInput = Console.ReadLine();

        //var myDictionary = new Dictionary<char, int>();

        //// for adding all the characters of userInput into the dictionary
        //foreach (char character in userInput)
        //{
        //    if (myDictionary.Keys.Contains(character))
        //    {
        //        myDictionary[character] = myDictionary[character] + 1;
        //    }
        //    else
        //    {
        //        myDictionary.Add(character, 1);
        //    }
        //}

        //// comparing and reducing the count if the myString's charatcer is present in userInput:
        //var isAnagram = true;
        //foreach (char character in myString)
        //{
        //    if (myDictionary.Keys.Contains(character))
        //    {
        //        myDictionary[character] = myDictionary[character] - 1;
        //    }
        //    else
        //    {
        //        isAnagram = false;
        //        break;
        //    }
        //}

        //foreach (var key in myDictionary.Keys)
        //{
        //    if (myDictionary[key] != 0)
        //    {
        //        isAnagram = false;
        //        break;
        //    }
        //}
        //if (isAnagram)
        //{

        //    Console.WriteLine("Both strings are Anagrams");
        //}
        //else
        //{
        //    Console.WriteLine("Both strings are not Anagrams");
        //}

        // check if valid Paranthesis:
        // we have to check whether the given string is a valid or not.
        // here valid means for every opeing bracket there must be only equal number of/single same closing bracket
        // eg: if the string is (), this is a valid paranthesis string:
        // eg: uf the string is (){, this is not a valid parenthesis because there is no closing paranethesis } for {

        //var myString = "(((()";
        //var myStack = new Stack<char>();

        //foreach(char character in myString)
        //{
        //    // for the first character in the string to push into the stack:
        //    // or push the character into the stack if the stack is empty:
        //    if(myStack.Count == 0)
        //    {
        //        myStack.Push(character);
        //    }

        //    else if (
        //            myStack.Peek() == '(' && character == ')' ||
        //            myStack.Peek() == '{' && character == '}' ||
        //            myStack.Peek() == '[' && character == ']'
        //            )
        //    {
        //        myStack.Pop();
        //    }

        //    else
        //    {
        //        myStack.Push(character);
        //    }
        //}

        //if(myStack.Count == 0)
        //{
        //    Console.WriteLine("Valid Paranthesis");
        //}
        //else
        //{
        //    Console.WriteLine("Not a valid Paranthesis");
        //}

        // is valid Pallindrome or not?
        // this program is like pallindrome or not but here the input String is much complex,
        // a normal pallindrome program's input should look like: ABBA, MADAM
        // but for this program the input like this: "A man, a plan, a canal: panama",
        // it may contain spaces and specail characters, but we hve to tell whether it is pallindrome or not.
        // we need to iterate the total string and foreach string we have to check whether it is aplabet or a number,
        // if the value is a alphabet or a number then only we will add those into a string or a char array.

        //var myString = "A man, a plan, a canal: panama";
        //var resultString = string.Empty;

        //foreach(char character in myString)
        //{
        //    if (char.IsLetterOrDigit(character))
        //    {
        //        // this result string will now have only alphabests and numbers in it
        //        resultString = resultString + character.ToString().ToLower();
        //    }
        //}

        // first approach(alternative)
        //// now we will reverse the resultString and compare with the previous version of resultString(before reversing), 
        //// if both are same then it's a pallindrome:
        //var tempString = new string(resultString.Reverse().ToArray());
        //// Here, as we can't modify the original string in c#(as strings are immutable)
        //// so we are storing the modified string into a variable(tempString)
        //// so inside the tempString the modified string(instance of a original string in another format(reversed)) will be there
        //// we are using new String() constuctor because resultString.Reverse().ToArray() will return the result like below:
        //// if the resultString is "Abba"
        //// then the reverse method will return the char array like this: ['a','b','b','A']
        //// So to make this char array into a string we have to use the new String() constructor, then it will become "abbA"
        //// if the reverse string(temp string) and source/main string(without specail characters) are same then it is a pallindrome:
        //if(resultString == tempString)
        //{
        //    Console.WriteLine("Pallindrome");

        //}
        //else
        //{
        //    Console.WriteLine("Not a pallindrome");

        //}

        // another approach(easy one):
        //var isPallindrome = true;
        //for(int i = 0; i < resultString.Length / 2; i++)
        //{
        //    if (resultString[i] != resultString[resultString.Length - 1 - i])
        //    {
        //        isPallindrome = false;
        //        break;
        //    }
        //}

        //if (isPallindrome)
        //{
        //    Console.WriteLine("Pallindrome");
        //}
        //else
        //{
        //    Console.WriteLine("Not a pallindrome");
        //}


        // check if the given string is a pangram or not:
        // pangram means: if the input string contains every alphabet from a - z or A - Z then the string is a pangram
        // the input string may contains duplicates also like "aba" or "abAB"
        // but all the 26 alphabets should must have in the input String.

        //var myString = "The quick brown fox jumps over the lazy dog"; // this string has all the 26 characters
        //var myString = "The quick brown fox jumps over the lzy dog"; // this string has 25 characters removed 'a' for testing purpose:

        //var flags = new bool[26];

        //// making all the elements in the array to false:
        //for(int i = 0; i < flags.Length; i++)
        //{
        //    flags[i] = false;
        //}

        //// iterating through the input string and if the character is between the below conditions then we will make that characters index to true in flags array.
        //// example if the character is B or b then we will do character(small) - a => here char is b, b's asciii is 98. so, 98-97(a's ascii value) => we will get 1
        //// and we will make that index value in array as true and lastly we loop if any index in array from 0 to 25 is false then the input string is not a pangram
        //foreach(char character in myString)
        //{
        //    if(myString.Length < 26)
        //    {
        //        break;
        //    }
        //    else
        //    {
        //        if(character >= 'a' && character <= 'z')
        //        {
        //            flags[character - 'a'] = true;
        //        }
        //        else if(character >='A' && character <= 'Z')
        //        {
        //            flags[character - 'A'] = true;
        //        }
        //    }
        //}

        //var isPanagram = true;
        //foreach(bool boolean in flags)
        //{
        //    if(boolean == false)
        //    {
        //        isPanagram = false;
        //        break;
        //    }
        //    else
        //    {
        //        isPanagram = true;
        //    }
        //}

        //if (isPanagram)
        //{
        //    Console.WriteLine("Pangram");
        //}
        //else
        //{
        //    Console.WriteLine("Not a Pangram");
        //}


        // valid paranthesis program(Another approach)

        ////var myString = "[{}]()";
        //var myString = "[}]()";// removed opening flower brace for checking
        //var SBCount = 0;
        //var FBCount = 0;
        //var RBCount = 0;
        //// declared all Square brackets(SB), Flower brackets(FB), Rounded brackets(RB) count to 0,
        //// approach:
        //// we will traverse the myString and if we get any opening bracket('[','{','(') then we will increment our counter variables with 1
        //// and if we get any closing brackets (']','}',')') then we will decrement our counter variables with 1
        //// it means if we get opening bractet we make our count variable 1 and if we get closing bracket again we are making our counter varibales 0
        //// at last in every count variable the value should be 0, it means for every opening bracket there is a closing bracket 
        //// eg if there are 5 opening flower brackets then in the input string there must should be five closing flower brackets.
        //// flow: +1+1+1+1+1 = 5(for 5 opening flower brackets),   5-1-1-1-1-1 = 0 (for 5 closing flower brakctes).
        //// so at last the FBCOunt variable variable will be 0, so this is a valid paranthesis.

        //var isValidParanthesis = true;
        //foreach (char character in myString)
        //{
        //    if (character == '[')
        //    {
        //        SBCount++;
        //    }
        //    else if (character == '{')
        //    {
        //        FBCount++;
        //    }
        //    else if (character == '(')
        //    {
        //        RBCount++;
        //    }
        //    else
        //    {
        //        if (character == ']' && SBCount > 0) // checking whether there is pair(opening bracket) or not before decremeninting the counter values
        //        {
        //            SBCount--;
        //        }
        //        else if (character == '}' && FBCount > 0)
        //        {
        //            FBCount--;
        //        }
        //        else if (character == ')' && RBCount > 0)
        //        {
        //            RBCount--;
        //        }
        //        else
        //        {
        //            isValidParanthesis = false;
        //            break;
        //        }

        //    }
        //}

        //if (SBCount == 0 && FBCount == 0 && RBCount == 0 && isValidParanthesis)
        //{
        //    Console.WriteLine("valid Paranthesis");
        //}
        //else
        //{
        //    Console.WriteLine("Not a valid paranthesis");
        //}


        // interview question: Delloitte, HCA healthcare:

        //var userInput = "Mahendra Singh Dhoni";

        //var userInput = "  Mahendra  Dhoni";

        //var namesArray = userInput.Split(" ");

        //var nameArray = userInput.Split(" ",StringSplitOptions.RemoveEmptyEntries);

        //if(nameArray.Length == 3)
        //{
        //    Console.WriteLine(nameArray[1]);
        //}
        //else
        //{
        //    Console.WriteLine("No middle name");
        //}

        // revision:

        // Check a given string is Pallindrome or not:

        var MyString = "Malayalam";
        var IsPallindrome = true;

        for(int i = 0; i < MyString.Length / 2; i++)
        {
            if (MyString[i] != MyString[MyString.Length - 1 - i])
            {
                IsPallindrome = false;
                break;
            }
        }

        if (IsPallindrome)
        {
            Console.WriteLine("Given String is Pallindrome");
        }
        else
        {
            Console.WriteLine();
        }

    }
}
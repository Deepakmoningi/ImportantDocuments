﻿// We can log our exceptions into a text file:
// To log the messages or exceptions to the file we have to use third party Logging provider
// NLog Logging provider
// steps
// 1) Install the Nlog nuget package (Nlog.web.aspNetcore)
// 2) We have to configure one file(text file) Nlog.Config inside our project folder
// 3) because while run time the Nlog will serach for this file(which is having configurations required for Nlog)
// 4) This Nlog.config file consists of file name that where the logs should store, etc.
// 5) 
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Logging.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FileLogController : ControllerBase
    {
        private readonly ILogger<FileLogController> _logger;

        public FileLogController(ILogger<FileLogController> logger)
        {
            _logger = logger;
        }
        [HttpGet]
        public void GetError()
        {
            try
            {
                throw new Exception();

            }
            catch(Exception ex)
            {
                _logger.LogInformation("An unexpected error occured");
            }
        }
    }
}

﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

// We can implement logging by using ILogger interface,
// We can inject Ilogger interface to the class on where we want to use logging 
// so the .Net compiler will inject the logger instance for us
// we can use logger instance and call seperate methods to log the specific errors to the debug console
// Logging will happen because dot net core will use logging provider to log the messages to the console or debug window
// we control the log level(start from which category) in the appsettings.json file
namespace Logging.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LogController : ControllerBase
    {
        private readonly ILogger<LogController> _logger;
        // here in the constructor we are using generic concept so then in debug console we csn actually see that the exception is logged inside the particular controller, so we can categorize the exceptions based on its name by seing the controllers name:
        public LogController(ILogger<LogController> logger)
        {
            _logger = logger;
        }

        [HttpPost]
        public void PrintMessage()
        {
            Console.WriteLine("Hello");
            _logger.LogInformation("Logger working fine");
        }

        [HttpGet]
        public void test()
        {
            //string myString = null;

            int? myNumber = null;

            Console.WriteLine(myNumber.GetHashCode);

            
        }
    }
}

﻿public class Program
{
    public static void Main()
    {
        // Normal exceptions:
        //try
        //{
        //    int i = 5;
        //    int j = 0;
        //    int k = i / j;
        //    Console.WriteLine(k);
        //}
        //catch(Exception ex)
        //{
        //    Console.WriteLine(ex.Message);
        //}





        // inner exceptions:
        try
        {
            string filePath = @"C:\Users\2135997\Practice\C# Practice\ExceptionHandling\Log.txt";
            StreamWriter sw = null;
            try
            {
                // The below code may generate below errors at run time:
                // if we enter alphabets instead of numbers we will get exception(Format exception),
                // if we enter very big number then in the program will fail(Overflow exception) because int can store upto 32 bits only,
                // if we pass 0 for seconmd number(denominator) then we will get exception(Divide by zero excpetion)
                // To handle the exception that occurs inside this small bit of code we are using catch block
                Console.WriteLine("Enter first number:");
                int FN = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter second number:");
                int SN = Convert.ToInt32(Console.ReadLine());

                int result = FN / SN;

                Console.WriteLine($"Result: {result}");
            }

            catch (Exception ex)
            {
                //// We are logging the exception into a text file if any:
                ////  using stream writer class to write the exception details to the text file:

                //string filePath = @"C:\Users\2135997\Practice\C# Practice\ExceptionHandling\Log.txt";
                //StreamWriter sw = new StreamWriter(filePath);

                //// we want to enter the exception type that we encounter into the Log file
                //// to get the type of the exception, we can use getType() method inside the base exception class:
                //// we should use .Name() to access the name of the exception we encounter

                //// streamwriter.write is a method to write the data into the file:
                //sw.Write(ex.GetType().Name);
                //sw.Close();

                //// Not only catching the exception we can pass the message to the user:
                //Console.WriteLine("There is a problem, please try again later");

                // to demonstrate the inner exceptions, we are chinging the flow,
                // we are changing the file name and we are checking if the specified file is there or not if it is not there then we will throw an excption:

                // go to 25 and 26 line, declared the variables there to get the scope for both try and finally blocks:
                //string filePath = @"C:\Users\2135997\Practice\C# Practice\ExceptionHandling\Log.txt";
                //StreamWriter sw = null;
                if (File.Exists(filePath))
                {
                    sw = new StreamWriter(filePath);
                    sw.Write(ex.GetType().Name);
                    //sw.Close(); // closing it in finally block

                    Console.WriteLine("There is a problem, please try again later");

                }
                else
                {
                    // if we are unable to find the file then we are throwing an exception:
                    // we are throwing an exception with a message:
                    // here we are throwing an exception not handling it, so application will craches if this exception raises:
                    // if we want to handle this exception that is thrown by us intentionally then we have to wrap our entire code with a try block and handle this exception inside a catch block:
                    throw new FileNotFoundException(filePath + "is not present", ex);
                    //throw new FileNotFoundException(filePath + "is not present");

                    // here the second paramater is the original exception,
                    // because the control will come here only if any exception occurs inside the try block,
                    // and we are writing that exception  into the text file 
                    // and what if the file specified is not present in our system again we are throwing another exception here,
                    // but here we dont want to loose our original/main exception(which is the try block) so that ex(second parameter) holds that exception.
                    // and we are wrapping up that main exception inside the current exception,
                    // we have to pass the original ex object to the constructor of the current excpetion,
                    // simply if we want to retain the exception that who(main ex) is the reason for landing us to the catch block then we have to pass that exception object to the constructor of the current exception
                }
            }
            finally
            {
                if(sw != null)
                {
                    // if the file is exists then only the sw(stream writer instance) will create other wise it will be null only (Line number 72),
                    // so we are closing the streamwriter object only if the stream writer is initiliazed, otherwise we will get null reference excpion because we are trying to invoke the close() method on the null object(sw(stream writers instance))
                    sw.Close();
                }
            }
        }
        // to handle the exception(File not found exception, which we throwed intentionally in the catch block):
        // the control will only come here if there is no file with the name Log in our PC, so we have to rename it to invoke that exception and the control will come here:
        catch(Exception exception)
        {
            // so now inside this exception object, there will be a property called inner exception that is nothing but our original exception(divide by zero) because we have wrapped the original exception inside the another/current exception
            // and there will be a property called filenotfound exception which is file not found exception

            Console.WriteLine($"current exception = {exception.GetType().Name}");// to log the current exception(File not found exception)

            //Console.WriteLine($"inner exception = {exception.InnerException.GetType().Name}");// to log the inner exception(divide by zero exception)

            // if we wont pass/wrap the original exception(ex) inside the Current excption(throw filenotfoundexception("msg",ex)) constructor then the inner excpetion property's value will be null
            // and if we try to invoke gettype() method on null object then we will get the null reference exception,
            // so its better to check if there is an inner exception or not and if there then we will log it:
            if(exception.InnerException != null)
            {
                Console.WriteLine($"inner exception = {exception.InnerException.GetType().Name}");// to log the inner exception(divide by zero exception)
            }

        }



        try
        {
            Program.methodName();
        }
        catch (Exception ex)
        {
            Console.WriteLine("in catch of parent method" + ex.Message);
        }
    }

    static void methodName()
    {
        try {
            var num1 = 1;
            var num2 = 0;
            var res = num1 / num2;
        }
        catch (ArithmeticException e)
        {
            throw new ArithmeticException("arithemetic exception");
        }
    }
}
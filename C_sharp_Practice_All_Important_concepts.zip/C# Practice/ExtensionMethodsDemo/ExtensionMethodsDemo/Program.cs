﻿namespace ExtensionMethodsDemo
{
    public class Program
    {
        static void Main()
        {
            var Post = "This is supposed to be very very very long string...";

            // shorten is our custom method but we can call it like substring(),split() (string instance methods)
            // we access substring() and split() methods with the help of string instance variable(here it is Post)
            // In the same way now we are able to access the Shorten extension method for string class because we configured the extesnion method in string class
            var ShortenPost = Post.Shorten(5);
            
            // Shorten() method is to return the first five words from the string:
            // Now I want to get only first five words from the above string but using string class we cant acheive this because we don't have any direct inbuilt method to get the result:
            // So here we are using Shorten() on Post which is a string type.

            // so normally if we want to add any method to our existing class we may alter the class and add our method inside that class
            // or we may add new class and make it deriving for the existing class and add the method inside the child class using the concept inheritance

            // but here the problem is the method(Shorten()) we want to add this method in string class.

            // string class is a defualt class and we cant modify it, we cant inherit the string class and and we cant add any methods to string class source code

            // This is where extension methods came and by using we can add our custom method to the string class without modifying the string class.

            Console.WriteLine(ShortenPost);

        }
    }
}
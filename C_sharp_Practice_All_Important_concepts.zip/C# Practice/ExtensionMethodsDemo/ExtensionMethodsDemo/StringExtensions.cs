﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionMethodsDemo
{
    public static class StringExtensions
    {

        // this method must be static and public 
        public static string Shorten(this string str, int numberOfWords)
        {
            // in the above arguments inorder to extend the string class so we have to specify it with this keyword
            // for the input string we have to give name here we gave str, it's like a identifier
            // number of words is the argument we have to must pass this argument while calling this method.

            if (numberOfWords < 0)
            {
                return "numberOfWords should be greater than or equal to 0";
            }

            if(numberOfWords == 0)
            {
                return string.Empty;
            }

            string[] words = str.Split(' ');
            if (words.Length<numberOfWords)
            {
                return str;
            }

            // if there are words > number of words, then:
            return string.Join(' ', words.Take(numberOfWords)) + "...";

            // So, if you look at words,
            // the type of words is a String array, which is an array,does not have a method called Take.
            // Later, Microsoft created an extension method called Take that can be applied on any class that implements IEnumerable interface – in this case, the String array.
        }
    }
}

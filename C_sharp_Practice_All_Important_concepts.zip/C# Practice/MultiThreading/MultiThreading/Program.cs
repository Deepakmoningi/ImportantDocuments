﻿//// Process: Process is the thing that the operating system uses to excute the program,
//// os will provide the resources that are required to exceute the program.

//// Thread: Thread is a light weight process, A process has atleast one thread which is called as Main thread.
//// And a single thread can have multiple threads:
//// Summary: A thread is inside a process and it executes the actual application code and a process can have multiple threads.
//// if an application that we are executing is the multi threaded app then there are multiple threads executes that application within a single process.

//using System;

//public class MultiThreading
//{

//    public static void Main()
//    {
//        Console.WriteLine("Main thread started:");

//        // calling the time consuming method:

//        Console.WriteLine("Starting the Time consuming work method:");
//        DoTimeConsumingWork();
//        // after 5 seconds only we will get the numbers from getnumbers() method
//        // because currently appliction in executing on single thread only(main thread)
//        // once the DoConsuming work completes its execution then only it will execute the lines below that method:

//        var numbersList = GetNumbers();

//        foreach(var num in numbersList)
//        {
//            Console.WriteLine(num);
//        }
//    }

//    public static void DoTimeConsumingWork()
//    {
//        // simulation:
//        Thread.Sleep(5000);
//        Console.WriteLine("Time consuming work completed.");
//    }

//    private static List<int> GetNumbers()
//    {
//        var numbersList = new List<int>();

//        for (int i = 0; i < 10; i++)
//        {
//            numbersList.Add(i);
//        }

//        return numbersList;
//    }
//}


//// Output:
////Main thread started:
////Starting the Time consuming work method:
////Time consuming work completed.
////0
////1
////2
////3
////4
////5
////6
////7
////8
////9
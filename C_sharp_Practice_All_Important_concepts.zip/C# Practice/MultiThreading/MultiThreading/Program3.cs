﻿// Thread Start delegate:
using System;

public class Program3
{

    public static void Main()
    {
        //Thread T1 = new Thread(Number.PrintNumbers);
        //T1.Start();

        // Thread start delegate:
        // The constructor of a Thread() there is a overload that it expects a ThreadStart()
        // The ThreadStart() is a delegate and we know that delegate is the type safe function pointer.
        // and it will point to the function which is having the same signature as ThreadStart()
        // when we creates the worker thread and we have to specify to that thread from where it should starts the execution.
        // any thread we create we have to specify the entry point for it(like from where it should start execution),
        // threadstart() delegate will do that for us it will point to that method and when the thread is invoked it will directly go to that method and executes the method
        // if we dont specify the Thread start() delegate to the constructor of the Thread the complier will create a default ThreadStart() delegate for us:

        Thread T1 = new Thread(new ThreadStart(Number.PrintNumbers));
        T1.Start();

        // we can also pass delegates to the Thread constructor like below:
        //Thread T2 = new Thread(delegate() { Number.PrintNumbers(); });

        // we can also point to the method using lambda functions:
        //Thread T3 = new Thread(() => { Number.PrintNumbers(); });
    }

}

public class Number
{
    public static void PrintNumbers()
    {
        for(int i = 0; i < 10; i++)
        {
            Console.WriteLine(i);
        }
    }

}






﻿//// Pre requisite - Program.cs
//// Process: Process is the thing that the operating system uses to excute the program,
//// os will provide the resources that are required to exceute the program.

//// Thread: Thread is a light weight process, A process has atleast one thread which is called as Main thread.
//// And a single thread can have multiple threads:
//// Summary: A thread is inside a process and it executes the actual application code and a process can have multiple threads.
//// if an application that we are executing is the multi threaded app then there are multiple threads executes that application within a single process.

//using System;

//public class Program2
//{

//    public static void Main()
//    {
//        Console.WriteLine("Main thread started:");

//        // calling the time consuming method:
//        Console.WriteLine("Starting the Time consuming work method:");

//        // creating a worker thread inside a main thread to execute the Time consuming method:

//        var Workerthread = new Thread(DoTimeConsumingWork);
//        Workerthread.Start();
//        // so now the time consuming work will exeute on different thread and the below code to get the list of numbers from the getNumbers methods will execute on main thread itself
//        // By doing this we dont have to wait for the DoTimeConsumingWork() method to complete its work.

//        var numbersList = GetNumbers();

//        foreach (var num in numbersList)
//        {
//            Console.WriteLine(num);
//        }
//    }

//    public static void DoTimeConsumingWork()
//    {
//        // simulation:
//        Console.WriteLine("Worker thread started:");
//        Thread.Sleep(5000);
//        Console.WriteLine("Time consuming work completed.");
//    }

//    private static List<int> GetNumbers()
//    {
//        var numbersList = new List<int>();

//        for (int i = 0; i < 10; i++)
//        {
//            numbersList.Add(i);
//        }

//        return numbersList;
//    }
//}


//// Output:

////Main thread started:
////Starting the Time consuming work method:
////0
////Worker thread started:
////1
////2
////3
////4
////5
////6
////7
////8
////9
////Time consuming work completed.

//// the main advantage of using multiple threads is we can offload the work of executing the time consuming work to another thread so our main thread is free to execute the below lines of code instead of waiting for the response from the DoTimeConsumingWork() method.

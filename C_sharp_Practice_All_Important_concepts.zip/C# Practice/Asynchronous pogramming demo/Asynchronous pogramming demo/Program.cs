﻿//// synchronous programming:
//public class Program
//{
//    static void Main()
//    {
//        Console.WriteLine("Main Program started for fetching data");

//        //until the fetchdata return the data to this caller here, the code below the caller wont execute because currently we are running our code synchronously:
//        var data = FetchData();

//        Console.WriteLine("Sender sent the data");

//        // for loop wont execute until the data (caller) gets the data from fetch data
//        for (int i = 0; i < 5; i++)
//        {
//            Console.WriteLine($"I's value from for loop: {i}");
//        }


//        Console.WriteLine($"The data is {data}");
//    }

//    public static string FetchData()
//    {
//        Console.WriteLine("Fetching the data:");
//        // simulating the delay like we are fetching the data from DB
//        Thread.Sleep(5000);
//        Console.WriteLine("Data fetched and sending to caller");
//        return "Most Important Data";
//    }
//}

//// output:

////Main Program started for fetching data
////Fetching the data:
////Data fetched and sending to caller
////Sender sent the data
////I's value from for loop: 0
////I's value from for loop: 1
////I's value from for loop: 2
////I's value from for loop: 3
////I's value from for loop: 4
////The data is Most Important Data


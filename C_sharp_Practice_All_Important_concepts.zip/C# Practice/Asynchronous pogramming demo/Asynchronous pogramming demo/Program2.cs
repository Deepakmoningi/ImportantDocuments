﻿// converting the synchronous program.cs code to asynchronous program2.cs code:

// We use Asynchronous programming if we have a block in operation such as database calls to get the data and to write the data

// we have two approaches to acheive the asynchronous programming:
// Traditional approaches: 1)Mutli threading, 2)callbacks
// New approach introduced in .net 4.5 : using Async/Await

// The traditional approahces are complex to learn and understand
// so the .net introduced the new asynchronous programming model which is a Task-based asynchronous model
// We can acheive this using async/await keywords.

// Why we need asynchronous programming in ASP.NET CORE WEB API

// In a web application, when a request comes to the server one thread will allocate to handle that request
// During execution of that request if there is a blocking operation that thread will go busy.
// Each machine have limited number of threads, so if we have lot of concurrent connections and if all our threads are busy while waiting for a response from the blocking operation then the server will become irresponsive
// The only way to make server responsive is to add more servers which means scaling out and it is not a good practice in software/api development
// But we can improve this using Asynchronous model:
// when a thread has to excute a blocking operation the control immediately returns to a thread and that thread is used to handle another request,
// when that blocking operation completes its execution the same thread or another thread will comeback and execute the remaining code after the blocking operation.
// with this model we are making our app scale up.




using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Asynchronous_pogramming_demo
{
    public class Program2
    {
        public static async Task Main()
        {
            Console.WriteLine("Main program started to fetch the data:");

            // calling the async method
            var GetFetchDataAsync = FetchDataAsync();

            Console.WriteLine("Waitng for the data from the FetchDataAsync mean while the below task is executing:");

            // you don't always have to await in asynchronous operation,and you can do instead, some work in between that is not dependent on the result of that asynchronous operation.
            for (int i = 0; i < 20; i++)
            {
                Console.WriteLine($"Main method is doing other task : {i+1}");
                await Task.Delay(500); // We know that fetchdata will give response after 5 seconds meanwhile for every 0.5 second we are logging i+1 value here asynchronously.
            }

            // wrote code like below to demonstrate about aawait i.e; during the waiting time the thread will execute the above for loop 
            var resultData = await GetFetchDataAsync;

            Console.WriteLine("Sender sent the data"); 

            Console.WriteLine($"The data is {resultData}");

        }

        public async static Task<string> FetchDataAsync()
        {
            Console.WriteLine("Fetching the data:");
            // simulating the delay like we are fetching the data from DB
            await Task.Delay(5000);
            Console.WriteLine("Data fetched and sending the data to caller");
            return "Most Important Data";
        }
    }
}


// output:

//Main program started to fetch the data:
//Fetching the data:
//Waitng for the data from the FetchDataAsync mean while the below task is executing:
//Main method is doing other task : 1
//Main method is doing other task : 2
//Main method is doing other task : 3
//Main method is doing other task : 4
//Main method is doing other task : 5
//Main method is doing other task : 6
//Main method is doing other task : 7
//Main method is doing other task : 8
//Main method is doing other task : 9
//Main method is doing other task : 10
//Data fetched and sending the data to caller   // asynchronous: after 5 seconds the blocking operation completed and it send the data to the caller 
//Main method is doing other task : 11
//Main method is doing other task : 12
//Main method is doing other task : 13
//Main method is doing other task : 14
//Main method is doing other task : 15
//Main method is doing other task : 16
//Main method is doing other task : 17
//Main method is doing other task : 18
//Main method is doing other task : 19
//Main method is doing other task : 20
//Sender sent the data
//The data is Most Important Data // logs the data sent by the sender


// whenever compiler sees the await keyword the compiler will know it is a costly operation and the control will immediately go to caller of that async method,
// and meanwhile the compiler will execute the code below the caller and above the await keyword line and once the async operation completed compiler will execute the code below the await keyword

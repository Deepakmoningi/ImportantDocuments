﻿// third program.cs file
// first read the drawbacks of multicast delegates(wrote as imp points in program1.cs file at the end)
// events: pure publisher subscriber model, events uses delegates and it will change the multi casting delegates to publisher subscriber model
// here everything is same like the multicast deligates only but here we have to use event keyword for the sender object to convert it into publisher - subscriber model:
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace DelegatesDemo
{
    public class Program2
    {
        static void Main()
        {
            // adding subscription: subscribers need to subscribe using += to publisher:

            SomeClass x = new SomeClass();
            Program2 program2 = new Program2(); // created the instance for all the 
            x.senderObj += program2.receiver1;
            x.senderObj += program2.receiver2;
            x.senderObj += program2.receiver3;

            // x.senderObj = null; // as we are using the events we are getting compile time error and we cant assign null to sender Obj here.
            // we can do += and -= but we cant assign null as we are allowed in multi cast delegates
            // it means the receiver/subscriber/client cannot modify/manipulate the delegate/sender/publishers instance.

            Thread t = new Thread(new ThreadStart(x.Hugeprocess));
            t.Start();

            Console.WriteLine("program.cs");
        }

        // subscribers methods
        // converted from receiver methods to subscribers for the publishers

        public void receiver1(int i)
        {
            Console.WriteLine("receiver 1 " + i.ToString());
        }

        public void receiver2(int i)
        {
            Console.WriteLine("receiver 2 " + i.ToString());
        }

        public void receiver3(int i)
        {
            Console.WriteLine("receiver 3 " + i.ToString());
        }
    }


    public class SomeClass
    {
        public delegate void Sender(int i);

        //Delegate Definition:
        //This line defines a delegate named Sender.
        //A delegate is a type that represents references to methods with a specific parameter list and return type.
        //In this case, Sender can reference any method that takes a single integer parameter and returns void.

        // converted from sender to publisher as we included the event keyword
        // also known as event publisher:
        public event Sender senderObj = null;


        //Event Declaration:
        //This line declares an event named senderObj of type Sender delegate.
        //An event is a special kind of delegate that is used to provide notifications.
        //The senderObj event can be subscribed to by methods that match the Sender delegate signature.
        //Initially, it is set to null, meaning no methods are subscribed to the event.

        public void Hugeprocess()
        {
            for (int i = 0; i < 10000; i++)
            {
                Thread.Sleep(5000);
                // invoking the event(event is raised)

                //senderObj(i); // as this line is to send the i value to the revceiver but if there are no subcribers subscribed to this event then we will encounter null reference exception
                // To handle it we can use the invoke method with nullable opertaor(?) and ?.Invoke(i) syntax safely raises the event, ensuring that it only gets called if there are subscribers.
                senderObj?.Invoke(i);
            }
        }
    }
}


// Summary:
// Delegates is meant for callbacks
// delegates can be converted into multicast delegates by using += and -=
// in multicast delegate the receiver/client can manipulate the sender's delegate object by assigning null to it
// in multicast delegate the sender delegate is exposed so the receiver can manipulate it
// Event is a pure publisher subscriber model
// event is a encapsultaion over delegates.

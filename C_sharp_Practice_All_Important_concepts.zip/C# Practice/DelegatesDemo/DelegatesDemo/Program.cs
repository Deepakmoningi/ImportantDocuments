﻿//// first program.cs file:
//// first level about delegates(basics)
//// how delegates are callbacks:
//// Threads, parallel processing, async are pre requisite for delegates

//public class Delegates
//{
//    static void Main()
//    {
//        Console.WriteLine("Delegates:");

//        SomeClass x = new SomeClass();
//        // x.HugeProcess();
//        // here above (x.HugeProcess()) we are calling the Huge process method synchronously,
//        // and the lines below that will not execute they will get execute after very very very long time(after completion the Huge process() method)
//        // because the code/logic in main method and code inside someclass(class below) are getting executed in one single main thread.
//        // So we have to call the Huge process method asynchronously
//        // Asynchronously means we have to make our huge process to run on one thread and remaning logic in another thread:
//        // Multi threading:
//        // after creating the delegate and sender object in other thread:
//        // we have to attach the receiver method to the sender object like below:
//        x.senderObj = receiver; // we are telling the delegate to point to this method.
//        // we know that delegate is the pointer to a function and we are Inside the HugeProcess method, we are invoking the delegate senderObj with the parameter i.
//        // This will call the method that senderObj is pointing to, which in this case is receiver.
//        // because delegate signature (senderObj) and the method signature is same here and we have to assign the receiver method to senderObj (line no.22)
//        // main: When you assign receiver to senderObj, the delegate senderObj holds a reference to the receiver method. This means that when you call senderObj(i), it actually calls the receiver method with the parameter i

//        // after the above line of code the program.cs main thread will keep running and as below code the code inside the other thread will execute parallely:
//        // for every five seconds sender will send i value to receiver in other thread and in this thread we are actually logging the i value to the console,
//        // with this we have acheived the parallel processing using delegates(callbacks)
//        // in output it will each i value from 0 to 9999 for each five seconds(code isnside the huge process method)
//        Thread t = new Thread(new ThreadStart(x.HugeProcess));
//        t.Start();
//        // now the huge process will go and run on some different thread.
//        // below we have the Huge process method that method will only exceute on different thread,
//        // except that method the remaining code will gets executed on the main thread
//        // So now using delegates we want the i's value inside the forloop inside the hugeprocess method.
//        // So we need to send the i's value from one thread(because huge process is executing on different thread) to another thread, to acheive this we can use callbacks.
//        // like for every five seconds the callback will happen and it will send the i value to the other thread so to make it happen we have to use delegates:

//        Console.WriteLine("Program.cs");
//    }

//    // This is the receiver method in the main thread which will receive the i value from the other thread from huge process method
//    static void receiver(int i)
//    {
//        Console.WriteLine(i);
//    }


//}


//// start reading from here:
//// Delegates:
//// Delegates as callbacks:
//// Delegates are useful while in callbacks:
//// for an instance if there are two threads and in each thread one logic is running,
//// If we want our logic 2 isnide the thread 2 needs to inform something or transfer the data to logic 1 inside the thread 1 then here we have to use the delegates.
//// Here delegates will work as callback functions
//// when the callbacks comes then the code is running asynchronously it means parallelly.
//// so here two threads are running parallelly and we want to communicate the data between the two threads then we can use the delegates.

//public class SomeClass
//{
//    // sender delegate:
//    public delegate void Sender(int i); // delegate decleration, which holds reference to methods which haves same singature as delegates
//    public Sender senderObj = null; // created the object for the delegate, now this will carry our i value and send it to the receiver in the main thread.

//    public void HugeProcess()
//    {
//        for (int i = 0; i < 10000; i++)
//        {
//            Thread.Sleep(5000);
//            // invoking the delegate
//            senderObj(i);  // here we are making the call back, after every five seconds we are sending the i value to the receiver in main thread.
//        }
//    }
//}
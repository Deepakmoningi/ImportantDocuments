﻿//// This is a test class
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace DelegatesDemo
//{
//    public class Delegates
//    {
//        static void Main()
//        {
//            Console.WriteLine("Delegates:");

//            SomeClass x = new SomeClass();
//            x.senderObj = receiver;
//            Thread t = new Thread(new ThreadStart(x.HugeProcess));
//            t.Start();

//            Console.WriteLine("Program.cs");
//            Console.ReadLine();
//        }
//        static void receiver(int i)
//        {
//            Console.WriteLine(i);
//        }


//    }

//    public class SomeClass
//    {
//        public delegate void Sender(int i); // delegate decleration
//        public Sender senderObj = null;

//        public void HugeProcess()
//        {
//            for (int i = 0; i < 10000; i++)
//            {
//                Thread.Sleep(5000);
//                senderObj(i);
//            }
//        }
//    }


//}

﻿//// second program.cs:
//// second level about delegates
//// about multicast delegates:
//// in program.cs file for one sender we have only one receiver(receiver() method) but we can actually have mutliple receivers for one sender, this is known as multicasting:

//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace DelegatesDemo
//{
//    public class program1
//    {
//        static void Main()
//        {
//            SomeClass x = new SomeClass(); 
//            // attaching the receiver to the sender:
//            // upon attaching the senderobj will have the reference of receiver1() method, it means sender object will point to recevier1() method and when we involke the senderobj() it will invoke the receviver1() method instead of invoking senderObj():
//            x.senderObj += Receiver1;
//            // previously in program.cs file we used only = but now we have to use += because we  have multiple receivers for one sender(multi cast delegates):
//            // += specifies that sender object have multiple receivers:
//            // by doing this we(receiver 1) are subscribing to the sender obj, we can also unsubscribe by using -=

//            x.senderObj += Receiver2;

//            x.senderObj += Receiver3;

//            // x.senderObj = null; // it is invalid, events will give us a compile time error if we do like this(program2.cs)

//            // as we have three receivers above, for each five seconds the sender will send the i value to the three receivers and the three receiver methods are logging the i value to the console

//            // created/configured a thread to run the hugeprocess method in another thread:
//            Thread t = new Thread(new ThreadStart(x.HugeProcess));
//            t.Start();

//            // just a add on code in the main thread along with the multi cast delegates
//            Console.WriteLine("program.cs");

//        }

//        // mutliple receiver methods to demonstrate about multi casting
//        // when the sender sends the i value from the other thread then these below all receiver methods will receive the i value from the sender
//        static void Receiver1(int i)
//        {
//            Console.WriteLine("Receiver1 " + i.ToString());
//        }

//        static void Receiver2(int i)
//        {
//            Console.WriteLine("Receiver2 " + i.ToString());
//        }

//        static void Receiver3(int i)
//        {
//            Console.WriteLine("Receiver3 " + i.ToString());
//        }
//    }

//    public class SomeClass
//    {
//        public delegate void Sender(int i);

//        public Sender senderObj = null;
//        public void HugeProcess()
//        {
//            for (int i = 0; i < 10000; i++)
//            {
//                Thread.Sleep(5000);
//                senderObj(i);
//            }
//        }
//    }
//}

//// note points:
//// in first program.cs we configured  the delegates in a way that the communication(sending i values from other thread to main thread) is happened only one-one(one sender to one receiver)
//// in this(program1.cs) file we configured  the delegates in a way that the communication is happened only one-many(one sender to may receiver using +=) this is called multi cast delegates.
//// Events are also there, which have the mechanism called as Publisher - subscriber 
//// Publisher(sender) and subscribers(receivers) are almost like the multi cast delegates only there will be one sender and multiple receivers but multicast delegates and events are different
//// because the receiver can actually manipulate the senders obj by providing the null value to it:
//// x.sender = null; // manipulating the senders obj and if we do like this(line no. 30) after that point, no other receivers will get the i values from the other thread.
//// so handle this we have events which follows pure publisher subscriber model

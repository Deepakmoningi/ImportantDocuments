import React from 'react'
import Person from './Person'

// function NameList() {
//     const names=['Amrutha','Deepak','Nani']
//     const nameList= names.map((name)=><h2>{name}</h2>);

//   return (
//     <div>
//         {/* As we are using the Map method which is a javascript method,
//         so we need to write it in curly braces because every javascript code inside the JSX should be evaluated */}
//       {
//         // names.map((name)=><h2>{name}</h2>)
//         nameList
//       }
//     </div>
//   )
// }

// changing NameList function component, changing the names -> persons


function NameList() {
    // to show that if we don't have id property/ properties inside an object.
    const names=["Bruce","Clark","Diana","Bruce"];
    const persons = [
        {
            id: 1,
            name: 'Amrutha',
            age: 22,
            skill: 'DSA'
        },
        {
            id: 2,
            name: 'Deepak',
            age: 23,
            skill: 'Angular'
        },
        {
            id: 3,
            name: 'Nani',
            age: 23,
            skill: '.Net'
        }
    ]
    //Passing the person object data as a props from this Parent component to Person/ child component
    const personList = persons.map((person) => <Person  key={person.id} person={person}></Person>)
    const nameList= names.map((name,index)=><h2 key={index}> {index} {name}</h2>)
    
    return (
        <div>
            <div>
                {personList}
            </div>
            <div>
                {nameList}
            </div>
        </div>
    )
}

export default NameList



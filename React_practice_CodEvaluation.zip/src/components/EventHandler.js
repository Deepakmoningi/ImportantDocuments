import React, { Component } from 'react'

class EventHandler extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         message:"Hello"
      }

      //this.EventHandler= this.EventHandler.bind(this);
    }

    // EventHandler(){
    //     this.setState({
    //         message:"GoodBye!"
    //     })
    //     console.log(this);
    // }

    EventHandler=() =>{
      this.setState({
        message:"GoodBye"
      })
    }
    
  render() {
    return (
      <div>
        <div>{this.state.message}</div>
        {/* <button onClick={this.EventHandler.bind(this)}>Click</button> */}
        {/* <button onClick={()=>this.EventHandler()}>Click</button> */}
        <button onClick={this.EventHandler}>Click</button>
      </div>
    )
  }
}

export default EventHandler

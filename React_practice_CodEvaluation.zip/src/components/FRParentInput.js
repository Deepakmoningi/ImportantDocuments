import React, { Component } from 'react'
import FRInput from './FRInput'

class FRParentInput extends Component {
    constructor(props) {
      super(props)
        // creating ref
      this.inputRef=React.createRef();
    }

    clickHandler = ()=>{
        // here current will points to native input element in child component and not to the child components instance
      this.inputRef.current.focus();
    }
    
  render() {
    return (
      <div>
        {/* attaching ref */}
        <FRInput ref={this.inputRef}></FRInput>
        <button onClick={this.clickHandler}>Focus Input</button>
      </div>
    )
  }
}

export default FRParentInput

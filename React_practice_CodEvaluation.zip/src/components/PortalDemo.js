import React from 'react'
import ReactDOM from 'react-dom'

function PortalDemo() {
  // This createPortal will take two paramters, 
  // first paramter is the JSX that we want to render
  // second paramater is the DOM node that we want to mount the element
  return ReactDOM.createPortal(
    <div>
      <h1>Portals Demo</h1>
    </div>,
    document.getElementById('portal-root')
    // portal-root is the id of our second div element in index.html file
  )
}

export default PortalDemo

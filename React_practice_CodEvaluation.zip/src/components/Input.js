import React, { Component } from 'react'

class Input extends Component {
    constructor(props) {
      super(props)
    
      this.inputref=React.createRef();
    }

    // Instead of componentDidMount(), we are creating the custom method that will focus the input element
    // this method will be called by the parent component
    focusInput(){
        this.inputref.current.focus()
    }
    
  render() {
    return (
      <div>
        <input type='text' ref={this.inputref}></input>
      </div>
    )
  }
}

export default Input

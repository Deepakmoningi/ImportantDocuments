import React, { Component } from 'react'

class User extends Component {
  render() {
    return (
      <div>
        {/*
        Currently name attribute will wont work like a variable
        because name attribute now have the reference of a method
        and to display the name Deepak we have to call the name() function
        name -> name()
        */}
        {this.props.name(true)}
      </div>
    )
  }
}

export default User

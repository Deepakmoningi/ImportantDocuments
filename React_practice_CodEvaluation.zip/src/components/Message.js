import React, {Component} from "react";

/* class Message extends Component{
    buttonClicked(){
        this.props.message="Thank you for subscribing";
    }
    render(){
        return (
            <div>
                <h1>{this.props.message}</h1>
                <button onClick={()=>this.buttonClicked()}>Subscribe</button>
            </div>
        )
    }
} */

class Message extends Component{
    // 1st step for using state object in our component
    // creating state object and initializing it:
    constructor(){
        super()

        /* here we need to call this super() method because we extend reacts component class
        and a call has to be made to the base class constructor.
        */

        // creating the state object:
        this.state={
            // state object's property:
            message: "Welcome Visitor"
        }
        /* here we need to use the this keyword because we are inseid the class component
        state is a reserved keyword in react, when we write like this react will understand our intension */
    }

    // Button click Event Handler:
    changeMessage(){
        /* To change the state of the component, we need to call setState() method
        this method will accepts an object as a parameter that contains new state of the component
        The setState() method is used to alter the state of a class component.
        */ 
        this.setState({
            message:"Thank you for subscribing"
        })
    }

    render(){
        // 2nd step: binding the state object's property
        return (
        <div>
            <h1>{this.state.message}</h1>
            {/* 3rd step: Create a button html to create and handle an event to change the message value dynamically. */}
            {/* Add a click event to our button and a write  a method to handle the click event after button clicking. */}
            {/* For an event we need to assign a handler and that should be in the curly braces */}
            <button onClick={()=> this.changeMessage()}>Subscribe</button>
        </div>
        );
    }
}

export default Message;
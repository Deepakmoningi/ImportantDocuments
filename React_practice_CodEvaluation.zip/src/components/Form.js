import React, { Component } from 'react'

class Form extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
        // setting this value to the input tag value
         username:'',
         comments:'',
         topic:'react'
      }
    }
    
    handleUsernameChange= (event)=>{
        // if any change in inputs value then updating the state and the state value will be the input's value again
        this.setState({
            // assigning the updated input value to the state objects property
            username:event.target.value
        })
    }

    handleCommentsChange = (event)=>{
        this.setState({
            comments:event.target.value
        })
    }

    handleTopicChange = (event)=>{
        this.setState({
            topic:event.target.value
        })
    }
     
    handleSubmit= (event)=>{
      // here event has the form data that which user has entered
      alert(`${this.state.username} ${this.state.comments} ${this.state.topic}`)
      // to prevent the default behaviour of form submission meaning it will not reload the page when we submit the form
      event.preventDefault();
    }
  render() {
    // destructuring the state object's properties
    const {username, comments, topic}= this.state;
    return (
      <form onSubmit={this.handleSubmit}>
        <div>
            <label>
                Username
            </label>
            <input type='text' value={username} onChange={this.handleUsernameChange}></input>
        </div>
        <div>
            <label>
                Comments
            </label>
            <textarea type='text' value={comments} onChange={this.handleCommentsChange}></textarea>
        </div>
        <div>
            <label>
                Topic
            </label>
            <select value={topic} onChange={this.handleTopicChange}>
                <option value="react">react</option>
                <option value="angular">Angular</option>
                <option value="vue">Vue</option>
            </select>
        </div>
        <button type='submit'>Submit</button>
      </form>
    )
  }
}

export default Form

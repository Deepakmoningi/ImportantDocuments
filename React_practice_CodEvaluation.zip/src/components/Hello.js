import React from "react";

const Hello = () =>{

    // With JSX
    // return (
    //     <div>
    //         <h1>Hello Deepak</h1>
    //     </div>
    // ) 

    //without JSX
    return React.createElement(
        'div',
        {id:'hello', className:'testClass'},
        React.createElement('h1',null,'Hello Nani')
    )
} 

export default Hello;

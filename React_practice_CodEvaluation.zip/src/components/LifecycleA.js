import React, { Component } from 'react'
import LifecycleB from './LifecycleB';
class LifecycleA extends Component {
    //mounting life cycle method
    constructor(props) {
      super(props)
    
      this.state = {
         name:'Deepak'
      }
      console.log("LifecycleA constructor");
    }

    // mounting lifecycle method
    //update life cycle method
    // this method should return new state or null
    static getDerivedStateFromProps(props, state){
        console.log('LifecycleA getDerivedStateFromProps')
        return null
    }
    
    // Mounting lifecycle method
    componentDidMount(){
        console.log('LifecycleA componentDidMount')
    }

    // Update lifecycle method
    shouldComponentUpdate(){
        console.log('LifecycleA shouldComponentUpdate')
        return true
    }

    //Update lifecycle method
    getSnapshotBeforeUpdate(prevProps, prevState)
    {
        console.log('LifecycleA getSnapshotBeforeUpdate')
        return null
    }

    //update life cyle method
    componentDidUpdate(){
        console.log('LifecycleA componentDidUpdate')
    }

    changeState = () => {
        this.setState({
            name:'Codevolution'
        })
    }

    // moutnting life cycle method
    // update life cycle method 
  render() {
    console.log('LifecycleA render')
    return (
      <div>
        LifecycleA
        {/* To trigger the update lifecycle methods we need to change the state on a button click */}
        <button onClick={this.changeState}>Change state</button>
        <LifecycleB></LifecycleB>

      </div>
    )
  }
}

export default LifecycleA

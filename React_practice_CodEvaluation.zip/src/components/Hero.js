import React from 'react'

function Hero({heroName}) {
    // throwing error wantedly to demonstrate the error boundary functionality:
    if(heroName == 'Joker'){
        throw new Error('not a Hero!')
    }
  return (
    <div>
      {heroName}
    </div>
  )
}

export default Hero

import React from 'react'
import Columns from './Columns'

function Table() {
  return (
    <table>
        <tbody>
            <tr>
                {/* Within this row we want to render the columns
                and the columns will be maintained in the seperate component which is our columns component*/}
                <Columns></Columns>
            </tr>
        </tbody>
    </table>
  )
}

export default Table

// Fr -> forward ref

import React from 'react'

// function FRInput() {
//   return (
//     <div>
//       <input type='text'></input>
//     </div>
//   )
// }

// Here the FRInput is our child component, we will modify this component 

// New way to define a functional component:
// replacing traditional function with the arrow function

// To forward a ref we use React.forwardRef() method and this method is gong to be assigned to the constant
// receiving a ref to this/child component from parent, once we recieve we attached this ref to input tag
const FRInput = React.forwardRef((props, ref)=>{
    return(
        <div>
            <input type='text' ref={ref} ></input>
            {/* As we assigned the ref paramter (which came from parent)
            to the ref attribute in input element inside child component
            then the inputRef reference variable will now onwards point to this input element
            */}
        </div>
    )
}) 
export default FRInput

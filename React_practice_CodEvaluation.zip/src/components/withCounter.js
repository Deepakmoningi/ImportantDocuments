// Here file name is a HOC convention:
import React, { Component } from "react";
// arrow function:
const withCounter = (WrappedComponent,incrementNumber) => {
    class WithCounter extends Component{
        // counter functionality (common code for two components)
        constructor(props) {
            super(props)
          
            this.state = {
               count : 0
            }
          }
          incrementCount = () => {
              // getting prevState object
              this.setState((prevState) => {
                  // after receiving the prev state we are modifying(incrementing by 1) and returning the new state object
                  return {count : prevState.count + incrementNumber }
              })
          }
        render(){
            // Here we passed count and incrementCount as a props so that the original component can make use of these props
            return <WrappedComponent count={this.state.count} incrementCount={this.incrementCount} {...this.props}></WrappedComponent>
        }
    }
    return WithCounter
}
export default withCounter
import React, { Component } from 'react'
class Incrementer extends Component {
    constructor(props) {
        super(props)
      
        this.state = {
           count : 0
        }
      }
      incrementCount = () => {
          this.setState((prevState) => {
              return {
                  count : prevState.count + 1
              }
          })
      } 
  render() {
    return (
      <div>
        {/* here the JSX will be empty because the render prop will control what should render by this Incrementer component */}
        {/* 
        As per our example we will render both clickCounterTwo and HoverCounterTwo and pass down the count state and incrementCount method.
        */}
        {this.props.render(this.state.count, this.incrementCount)}
      </div>
    )
  }
}
export default Incrementer

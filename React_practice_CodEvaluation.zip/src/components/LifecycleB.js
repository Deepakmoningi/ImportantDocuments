import React, { Component } from 'react'

class LifecycleB extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         name:'Deepak'
      }
      console.log("LifecycleB constructor");
    }

    // this method should return new state or null
    static getDerivedStateFromProps(props, state){
        console.log('LifecycleB getDerivedStateFromProps')
        return null
    }
    
    componentDidMount(){
        console.log('LifecycleB componentDidMount')
    }

    // Update lifecycle method
    shouldComponentUpdate(){
        console.log('LifecycleB shouldComponentUpdate')
        return true
    }

    //Update lifecycle method
    getSnapshotBeforeUpdate(prevProps, prevState)
    {
        console.log('LifecycleB getSnapshotBeforeUpdate')
        return null
    }

    //update life cyle method
    componentDidUpdate(){
        console.log('LifecycleB componentDidUpdate')
    }

  render() {
    console.log('LifecycleB render')
    return (
      <div>
        LifecycleB
      </div>
    )
  }
}

export default LifecycleB

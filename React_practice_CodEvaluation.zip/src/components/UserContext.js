// step 1: Creating the user context
import React, { useContext } from "react";
// imported react for using the createContext() method to create context

// Here Simham is the default value:
const UserContext = React.createContext('Simham')

// provider and consumer 

const UserProvider = UserContext.Provider
const UserConsumer = UserContext.Consumer

export {UserProvider,UserConsumer}

// step 1:
// exporting the userContext itself, such that component can make use this directly
export default UserContext



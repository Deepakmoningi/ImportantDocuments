import React from 'react'

function Columns() {
  return (
    <>
        <td>
            Name
        </td>
        <td>
            Deepak
        </td>
    </>
  )
}

export default Columns

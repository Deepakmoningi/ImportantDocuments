import React, { Component } from 'react'

class RefsDemo extends Component {
    constructor(props) {
      super(props)
        // 1st step
        //creating a ref, here we created a property and we assigned the React.createref to it.
      this.inputRef= React.createRef()

      // 1st step for callback(cb) ref
      // creating a callback ref
      this.cbRef=null

      // second step
      // we will create a method that will assign a dom element to the ref that we created in step 1 (in line number 12)
      // this method will accepts an argument it is a dom element and we need to assign it to the callback ref.
      this.setCbRef = (element) => {
        this.cbRef=element
      }

    }
    
    componentDidMount(){
        //3rd step
        //input ref has current property(this will point to the input element because we added a reference in the second step)
        //and we are focusing it using the focus method
        // this.inputRef.current.focus();
        // console.log(this.inputRef);

        // code for callback ref:
        if(this.cbRef){
            // unlike the previous approach here we can access the DOM node directly
            // here we don't need current
            this.cbRef.focus()
        }
    }

    clickHandler= () =>{
        alert(this.inputRef.current.value)
    }

  render() {
    return (
      <div>
        {/* 2nd step */}
        {/* We need to attach the ref to the input element, to attach the ref we can make use of the reserved ref attribute */}
        <input type='text' ref={this.inputRef}></input>

        {/* 3rd step */}
        {/* Attaching the callback ref to the input element */}
        {/* Here we attached the setCbref because this is the property that sets the ref */}
        {/* As we attached the ref to this input element then this element will be passed as a paramter to the setCbRef property/method */}
        <input type='text' ref={this.setCbRef}></input>
        <button onClick={this.clickHandler}>Click</button>
      </div>
    )
  }
}

export default RefsDemo

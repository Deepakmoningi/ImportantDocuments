import React from 'react';

// After creating the component, importing the react is the first step we must do.


// Functional component
// function Greet(){
//     return <h1>Hello Deepak</h1>
// }

// Same Functional component using es6 arrow function:
// const Greet = (props) =>{
//     //props.name="Kumar";
//     return (
//         <div>
//             <h1>Hello {props.name} a.k.a {props.heroName}</h1>
//             <p>{props.children}</p>
//         </div>
//     )
// }

/* 
We wrote HTML but it is not going to rendered in the browser,
because it is not connected to the rest of our application, it is not connected to app.js component,
so to link the component we need to export this greet() functional component from greet.js and import this greet functional component inside the app.js component and include it in this file.
*/

// Destructuring props with fucntional component:
/* 
instead of passing the props paramter directly to the function parameters 
here we will directly extract the properties (name,heroName) from props object directly
this is first way to destructuring the props in function paramater
*/ 
// const Greet = ({name,heroName}) =>{
//     return (
//         <div>
//             <h1>Hello {name} a.k.a {heroName}</h1>
//         </div>
//     )
// }

/* 
There is a another way to destructure the props,
Here we can destructure the props inside the function body:
*/

const Greet = (props) =>{
    // here we are telling react to extract the name and heroName properties from the props object.
    // We must use {} when we want to destructure the props on both the cases.
    const {name, heroName} = props;
    return (
        <div>
            <h1>Hello {name} a.k.a {heroName}</h1>
        </div>
    )
}
export default Greet;
import React, { Component } from 'react'
import withCounter from './withCounter'
import UpdatedComponent from './withCounter'

class ClickCounter extends Component {
    
  render() {
    // destructuring the state object
    // const {count} = this.state

    // now destructuring the props
    const {count, incrementCount} = this.props
    return (
      <div>
        {/* Using the props(destructured) sent by the withCounter component */}
        <button onClick={incrementCount}>{this.props.name} Clicked {count} times</button>
      </div>
    )
  }
}

// instead of exporting the HoverCounter or ClickCounter, we are exporting the Higher order component 
export default withCounter(ClickCounter,5);

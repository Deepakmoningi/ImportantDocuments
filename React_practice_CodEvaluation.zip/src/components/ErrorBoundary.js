import React, { Component } from 'react'

class ErrorBoundary extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         hasError:false
      }
    }
    
    // to make this class to become a error boundary we need to define either one ar two error related life cycle methods:

    // first method:
    // this method receives error as a paramter
    static getDerivedStateFromError(error){
        // returning a new state object:
        // if an error is there when rendering any component we are setting the hasError property to true
        return {
            hasError:true
        }
    }

    // second method
    // this method is only useful for logging the errors
    componentDidCatch(error, info){
        console.log(error);
        console.log(info);
    }

  render() {
    // using the state property to create a fallback UI
    if(this.state.hasError){
        return <h1>Something went wrong</h1>
    }
    return this.props.children
  }
}

export default ErrorBoundary

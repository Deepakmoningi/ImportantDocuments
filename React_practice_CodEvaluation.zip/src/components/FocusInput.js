import React, { Component } from 'react'
import Input from './Input'

class FocusInput extends Component {
    constructor(props) {
      super(props)
    
      this.componentRef = React.createRef()
    }
    
    clickHandler=()=>{
        // Here the current will gives access to the input/ child component
        // Now here current means the input/ child component
        console.log(this.componentRef)
        this.componentRef.current.focusInput()
    }
  render() {
    return (
      <div>
        {/* child component tag */}
        {/* Attaching the ref property to the component instead to the DOM element like input, text area or something */}

        <Input ref={this.componentRef}></Input>

        {/* 
        What we want to acheive here is when we click on this focus input button in the parent component
        then the input element in the child component should recieve the focus like it should be highlited in the browser
        */}

        {/* Here we are adding the click handler to the button and handler method will call the child components method using the ref */}

        <button onClick={this.clickHandler}>Focus Input</button>
      </div>
    )
  }
}

export default FocusInput

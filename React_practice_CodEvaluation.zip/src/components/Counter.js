import React, { Component } from 'react'

export class Counter extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         count:0
      }
    }

    increment(){
        // updating the state object's property without using setState() method
        //this.state.count= this.state.count+1;

        // updating the state object's property(count) using setState() method
        // this.setState({
        //     count:this.state.count+1
        // },
        // // second parameter whichh is a callback for logging the updated count value:
        // ()=>{
        //   console.log('Callback value', this.state.count)
        // })


        // we will get previousState of the component as a parameter for this function. 
        this.setState((prevState)=>({
          count: prevState.count+1
        }))

        // logging the current count value after button click:
        console.log(this.state.count);
    }

    incrementFive(){
      this.increment();
      this.increment();
      this.increment();
      this.increment();
      this.increment();
    }
    
  render() {
    return (
      <div>
        <div>count- {this.state.count}</div>
        <button onClick={()=> this.incrementFive()}>Increment</button>
      </div>
    )
  }
}

export default Counter

import React, { Component } from 'react'
import withCounter from './withCounter'
import UpdatedComponent from './withCounter'

class HoverCounter extends Component {

  render() {
    // destructuring the state object
    // const {count} = this.state

    //destrutruing the props:
    const {count, incrementCount} = this.props
    return (
      <div>
        {/* using onmouseover to raise the event */}
        {/* Using the props(destructured) sent by the withCounter component */}
        <h2 onMouseOver={incrementCount}>Hovered {count} times</h2>
      </div>
    )
  }
}

// instead of exporting the HoverCounter or ClickCounter, we are exporting the Higher order component 
export default withCounter(HoverCounter,10)

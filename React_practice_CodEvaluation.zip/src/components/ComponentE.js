import React, { Component } from 'react'
import ComponentF from './ComponentF'
import UserContext from './UserContext'

export class ComponentE extends Component {
  render() {
    return (
      <div>
        Component E Context {this.context}
        <ComponentF></ComponentF>
      </div>
    )
  }
}

// step 2:
// assigning the userContext to the components context
ComponentE.contextType = UserContext

export default ComponentE

import React, {Component} from 'react';
/*
Before creating a class component we need to import two things
1) react
2) component class from react to make our class as a component class
*/


/* 
To make this class to be a react component we must do two things:
1) Our class must extends component class from react,
2) The class must implement render() method this must return null or html

*/
// class Welcome extends Component{
//     render(){
//         return <h1>Welcome {this.props.name} a.k.a {this.props.heroName}</h1>
//     }
// }

// destructuring props using class component:
/* 
When we destructure the props or state using class component,
then we need to destructure the props inside the render method.
If we have multiple properties inside the props object then we can specify the props inside {} which we want to use in our component.
*/
class Welcome extends Component{
    render(){
        const {name,heroName}=this.props
        return <h1>Welcome {name} a.k.a {heroName}</h1>
    }
}

export default Welcome
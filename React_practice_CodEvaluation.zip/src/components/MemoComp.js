import React from 'react'
//destructured the name prop 
function MemoComp({name}) {
    console.log('Rendering Memo component')
  return (
    <div>
      {name}
    </div>
  )
}

// Here 
export default React.memo(MemoComp)

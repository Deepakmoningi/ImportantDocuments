import React, { Component } from 'react'

class UserGreeting extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
        isLoggedIn: false
      }
    }

    
  render() {

    // using short circuit oprator approach using ampresand symbols
    return this.state.isLoggedIn && <div>Welcome Nani</div>

    // using ternary operator approach using question mark symbol
    // return(
    //     this.state.isLoggedIn ?
    //     <div>Welcome Nani</div> :
    //     <div>Welcome Guest</div>
    // )

    // using element variables
    // let message;
    // if(this.state.isLoggedIn){
    //     message= <div>Welcome Nani</div>
    // }
    // else{
    //     message= <div>Welcome Guest</div>
    // }
    // return <div>{message}</div>

    // using if/else
    // if(this.state.isLoggedIn){
    //     return (
    //         <div>
    //           Welcome Nani
    //         </div>
    //     )
    // }
    // else{
    //     return (
    //         <div>
    //           Welcome Guest
    //         </div>
    //     )
    // } 
  }
}

export default UserGreeting

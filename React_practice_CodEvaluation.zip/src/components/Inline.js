import React from 'react'
import styles from '../appStyles.module.css'


const heading={
    // here the key is a css property name but here it has to be in camel case and the value must be specified as a string. 
    fontSize: '72px',
    // we can specify multiple css properties also
    color: 'blue'
}

function Inline() {
  return (
    <div>
        {/* To show the advantage of using the module style sheet */}
        <h1 className={styles.success}>Success</h1>
        {/* To show the disadvantage of regular style sheet */}
        <h1 className='error'>Error</h1>
      <h1 style={heading}>Inline</h1>
    </div>
  )
}

export default Inline

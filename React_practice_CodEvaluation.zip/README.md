# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

The page will reload when you make changes.\
You may also see any lint errors in the console.

### `npm test`

Launches the test runner in the interactive watch mode.\
See the section about [running tests](https://facebook.github.io/create-react-app/docs/running-tests) for more information.

### `npm run build`

Builds the app for production to the `build` folder.\
It correctly bundles React in production mode and optimizes the build for the best performance.

The build is minified and the filenames include the hashes.\
Your app is ready to be deployed!

See the section about [deployment](https://facebook.github.io/create-react-app/docs/deployment) for more information.

### `npm run eject`

**Note: this is a one-way operation. Once you `eject`, you can't go back!**

If you aren't satisfied with the build tool and configuration choices, you can `eject` at any time. This command will remove the single build dependency from your project.

Instead, it will copy all the configuration files and the transitive dependencies (webpack, Babel, ESLint, etc) right into your project so you have full control over them. All of the commands except `eject` will still work, but they will point to the copied scripts so you can tweak them. At this point you're on your own.

You don't have to ever use `eject`. The curated feature set is suitable for small and middle deployments, and you shouldn't feel obligated to use this feature. However we understand that this tool wouldn't be useful if you couldn't customize it when you are ready for it.

## Learn More

You can learn more in the [Create React App documentation](https://facebook.github.io/create-react-app/docs/getting-started).

To learn React, check out the [React documentation](https://reactjs.org/).

### Code Splitting

This section has moved here: [https://facebook.github.io/create-react-app/docs/code-splitting](https://facebook.github.io/create-react-app/docs/code-splitting)

### Analyzing the Bundle Size

This section has moved here: [https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size](https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size)

### Making a Progressive Web App

This section has moved here: [https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app](https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app)

### Advanced Configuration

This section has moved here: [https://facebook.github.io/create-react-app/docs/advanced-configuration](https://facebook.github.io/create-react-app/docs/advanced-configuration)

### Deployment

This section has moved here: [https://facebook.github.io/create-react-app/docs/deployment](https://facebook.github.io/create-react-app/docs/deployment)

### `npm run build` fails to minify

This section has moved here: [https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify](https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify)


**React Fundamentals**
1) Greet.js -> functional component
2) Welcome.js -> class component
3) Hello.js -> JSX flexibility

4) Greet.js -> props with functional component
5) Welcome.js -> props with class component

6) Message.js -> state and setState()
7) Counter.js -> Dos and Donts while using setState()

8) Greet.js -> destructuring props with functional component
9) Welcome.js -> destructuring props with functional component

10) FunctionClick.js -> Event handling using functional component
11) ClassClick.js -> Event handiling using class component

13) Eventhandler.js -> Binding event handlers

14) ParentComponent.js, ChildComponent.js -> methods as props

15) UserGreeting.js -> Conditional rendering

16) NameList.js, Person.js -> List Rendering using map method and using parent/child components(refactoring)

17) Stylesheet.js -> Styling the react component using a style sheet

18) Inline.js -> Styling the react component using inline styling

19) Form.js -> Basics of form and form submission and making the default html/ normal component to the controlled component

20) LifecycleA.js, LifecycleB.js -> Mounting and update lifecycle methods.

21) FragmentDemo.js, Table.js, Columns.js -> Using react.fragments instead of using div while returning the JSX

22) PureComp.js, RegComp.js, ParentComp.js -> Class component extending Pure component instead regular component from react to avoid re rendering in particular scenarios

23) MemoComp.js -> avoid re rendering functional component using react.memo

24) RefsDemo.js -> using refs and callback refs to access the DOM nodes directly

25) Input.js, FocusInput.js -> using refs with class components

26) FRInput.js, FRParentInput.js -> forwarding refs

27) PortalDemo.js -> portals in react

28) Hero.js, ErrorBoundary.js -> creating Error boundary class using error life cycle methods

29) ClickCounter.js, HoverCounter.js -> Demo for Why we need higher order components in react

30) withCounter.js -> What is Higher order component

31) ClickCounterTwo.js, HoverCounterTwo.js -> Demo for Why we need render props in react

32) Incrementer.js -> How to use render props in react

33) ComponentC.js, ComponentE.js, ComponentF.js, UserContext.js -> How to use Context Api in react


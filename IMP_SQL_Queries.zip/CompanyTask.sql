create database Company;

create table tbl_department(Dept_Id int primary key,Dept_name nvarchar(20),Dept_location nvarchar(20)) /*parent table*/
insert into tbl_department values(3,'C#','Germany');
select * from tbl_department;
create table tbl_employee(Emp_Id int primary key,Emp_Name nvarchar(20),Annual_salary int,E_Dept_Id int foreign key references tbl_department(Dept_Id));
insert into tbl_employee values(5,'marry',410000,2);
select * from tbl_employee;
create table tbl_salary_structure(Dept_Id int foreign key references tbl_department(Dept_Id),basic_pay float,hra float,ma float,ppf float,IT float);

create table tbl_monthly_salary_distribution(E_Id_Indexer INT NOT NULL IDENTITY(1,1) PRIMARY KEY,E_Id int foreign key references tbl_employee(Emp_Id),D_Id int foreign key references tbl_department(Dept_Id),E_name varchar(20),basic_pay float,hra float,ma float,ppf float,IT float,Monthly_Salary int,Annual_salary int,Month_Year Date);

create table tbl_attendancetracker(Attendance_Id INT NOT NULL IDENTITY(1,1) PRIMARY KEY, Emp_Id int foreign key references tbl_employee(Emp_Id),Check_In_Time Datetime,Check_Out_Time Datetime,working_Hours int );

select* from tbl_department;
select* from tbl_employee;
select* from tbl_salary_structure;
select* from tbl_monthly_salary_distribution;
select *from tbl_attendancetracker;
select * from tbl_empSignups;

ALTER TABLE tbl_employee
ADD empUsername nvarchar(50);

select* from tbl_employee;
select * from tbl_empSignups;

delete from tbl_empSignups where id=5;

delete from tbl_employee where Emp_Id between 1 and 10;

truncate table tbl_monthly_salary_distribution;

truncate table tbl_attendancetracker;

truncate table tbl_empSignups;













create or alter procedure spMasterProcedure�
(@Emp_Id numeric ,@Emp_Name varchar(50),@Annual_salary numeric,@E_Dept_Id numeric,@empUsername nvarchar(50),@Action VARCHAR(10))
AS
BEGIN����� 
	SET NOCOUNT ON;
	--INSERT
	IF @Action = 'INSERT'
	BEGIN
		insert into tbl_employee values(@Emp_Id,@Emp_Name,@Annual_salary,@E_Dept_Id,@empUsername);
		select * from tbl_employee;
	END����� 
	--UPDATE
	IF @Action = 'UPDATE'
	IF EXISTS(SELECT 1 FROM tbl_employee WITH(NOLOCK)
	WHERE Emp_Id = @Emp_Id)
	BEGIN
		update tbl_employee
		set Emp_Id=@Emp_Id,Emp_Name=@Emp_Name,Annual_salary=@Annual_salary,E_Dept_Id=@E_Dept_Id,empUsername=@empUsername
		where Emp_Id=@Emp_Id
	END�
	else
		begin
			print('Employee not found')
		end
	--DELETE
	IF @Action = 'DELETE'
		BEGIN�
			delete from tbl_employee��
			where Emp_Id=@Emp_Id�
		END
END

execute spMasterProcedure @Action='INSERT',
						@Emp_Id=6,���
						@Emp_Name='Jayanth',�
						@Annual_salary=600000,�
						@E_Dept_Id=3,
						@empUsername='meber@gmail.com';

execute spMasterProcedure @Action='update',
						@Emp_Id=6,
						@Emp_Name='Jayant',
						@Annual_salary=610000,
						@E_Dept_Id=3,
						@empUsername='test@gmail.com';

execute spMasterProcedure @Action='delete',
						@Emp_Id=6,
						@Emp_Name='williams',
						@Annual_salary=350000,
						@E_Dept_Id=2,
						@empUsername='';
						
select * from tbl_employee;
select * from tbl_employee;
--select * from tbl_department;
select * from tbl_monthly_salary_distribution;
insert into tbl_employee values(11,'jointest1',100000,2,'jointest1@gmail.com');

select min(Annual_salary) as ls from tbl_employee 
where Annual_salary > (select min(Annual_salary) from tbl_employee);

select E_Dept_Id,avg(Annual_salary) as avg from tbl_employee
group by E_Dept_Id
order by avg desc

select Emp_id,Emp_Name,basic_pay from tbl_employee left JOIN  tbl_monthly_salary_distribution
on tbl_employee.Emp_Id = tbl_monthly_salary_distribution.E_Id;

select * from tbl_employee;
select * from tbl_empSignups;

select id,username,userrole,E_Dept_Id from tbl_employee 
full outer join tbl_empSignups 
on tbl_employee.empUsername = tbl_empSignups.username
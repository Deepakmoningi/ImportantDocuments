create or alter procedure spSalaryTableStructure
(@Dept_Id int,@basic_pay float,@hra float,@ma float,@ppf float,@IT float)
as
begin
	insert into tbl_salary_structure values(@Dept_Id,@basic_pay,@hra,@ma,@ppf,@IT)
	select*from tbl_salary_structure
end

exec spSalaryTableStructure @Dept_Id=3,
							@basic_pay=65,
							@hra=8,�
							@ma=9,
							@ppf=8,
							@IT=10;


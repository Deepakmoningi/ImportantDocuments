create table tbl_salary (empID Int primary key identity(1,1), salary int )

insert into tbl_salary values(60000);

select top 1 max(salary) as highestSalary from tbl_salary
where salary <(select MAX(salary) from tbl_salary);

select * from tbl_salary;

select top 1 salary from(select top 1 salary from tbl_salary
order by salary desc) as innerQuery
order by salary asc;

select top 1 salary from(select top 1 salary from tbl_salary
order by salary asc) as innerQuery
order by salary desc;
insert into tbl_state values(11213,'Madhya Pradesh');


delete from tbl_state where Name='Madhya Pradesh';

select * from tbl_state;

select * from tbl_city;

select * from tbl_User;

insert into tbl_city values(NewId(),'Chennai','caab5f0f-a71f-43a4-9235-6068ce5c90af');




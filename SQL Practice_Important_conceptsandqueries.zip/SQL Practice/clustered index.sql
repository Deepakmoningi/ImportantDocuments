insert into tbl_employee2 values(3,'Deepak',2500,'Male','Tekkali')
insert into tbl_employee2 values(5,'Vamsi',2330,'Male','Skota')
insert into tbl_employee2 values(1,'Raju',2800,'Male','vsp')
insert into tbl_employee2 values(2,'Rani',2000,'Female','npm')
insert into tbl_employee2 values(4,'Panni',1800,'Female','apl')
insert into tbl_employee2 values(6,'Panni',1800,'Female','apl')

select * from tbl_employee2

exec sp_helpindex tbl_employee2

create clustered index IX_tbl_employee2_Gender_Salary
on tbl_employee2 (Gender desc,Salary asc)

create nonclustered index IX_tbl_employee2_Name
on tbl_employee2 (Name)

create unique clustered index UIX_tbl_employee2_id
on tbl_employee2(id)
select * from [dbo].[tbl_employee]

select * from [dbo].[tbl_department]


-- query to get the who(employee name), maximum salary per each department and the dept id
-- querty(1), guest(2), abc(3)

-- changing the query to get the name and max slary per each dept using sub query

-- it will work if the interviewwer asks us to get the data from only one table

select Emp_Name,Annual_salary,E_Dept_Id from tbl_employee
where Annual_salary in 
(
	select max(Annual_salary)
	from tbl_employee
	group by E_Dept_Id
)

-- If the interviewerr aks us to get the datausing two tables, 
-- it means the department id should be present in both the tables

select E.Emp_Name, E.Annual_salary, D.dept_id  from tbl_employee E
join tbl_department D
on e.E_Dept_Id = D.Dept_Id
join
-- kind of subquery to get the max salaries dept wise
(
	select E_Dept_Id,MAX(Annual_salary) as [max salary] from tbl_employee
	group by E_Dept_Id
) as [Max_salaries]
on D.Dept_Id = Max_salaries.E_Dept_Id
and E.Annual_salary = Max_salaries.[max salary]
order by D.Dept_Id asc
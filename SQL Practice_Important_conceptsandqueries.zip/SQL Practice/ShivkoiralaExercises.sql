select * from[dbo].[tblAddress]

--select * from[dbo].[tblAncillary]
select * from[dbo].[tblCustomer]
--select * from[dbo].[tblModel]
select * from [dbo].[tblProduct]
select * from [dbo].[tblProductCustomer]


-- select max value and the corresponding product and
-- min value and the corresponding product from the products table:

-- my query
select * from tblProduct where ProductCost = (select MAX(ProductCost) from tblProduct)
union
select * from tblProduct where ProductCost = (select Min(ProductCost) from tblProduct)

-- my query
select ProductCost as [max value], ProductName as [product with max value] from tblProduct 
where ProductCost = (select MAX(ProductCost) from tblProduct)

-- correct one:
select MAX(ProductCost) as [Max value],
(select ProductName from tblProduct where ProductCost = (select max(ProductCost) from tblProduct)) as [Product with max value],
min(ProductCost) as [Min value],
(select ProductName from tblProduct where ProductCost = (select min(ProductCost) from tblProduct)) as [Product with min value]
from tblProduct


select * from [dbo].[tblProduct]
select * from [dbo].[tblProductCustomer]

-- my query:
select p.productname,count(pc.Productid_fk) as [count], ISNULL(cast(sum(p.ProductCost) as nvarchar(50)),'NA') as [total sales] from tblProduct p
left join [tblProductCustomer] pc
on p.ProductId = pc.Productid_fk
group by ProductName

-- correct one: 
SELECT 
    ProductName,
    [count],
    CASE 
        WHEN [count] = 0 THEN 'NA'
        ELSE CAST([total sales] AS VARCHAR(50))
    END AS [total sales]
FROM (
    SELECT 
        p.ProductName,
        COUNT(pc.Productid_fk) AS [count], 
        SUM(p.ProductCost) AS [total sales]
    FROM 
        tblProduct p
    LEFT JOIN 
        tblProductCustomer pc
    ON 
        p.ProductId = pc.Productid_fk
    GROUP BY 
        p.ProductName, p.ProductCost
) AS subquery;

-- correct one:
SELECT 
    p.ProductName,
    COUNT(pc.Productid_fk) AS [count], 
    CASE 
        WHEN COUNT(pc.Productid_fk) = 0 THEN 'NA'
        ELSE CAST(COUNT(pc.Productid_fk) * p.ProductCost AS VARCHAR(50))
    END AS [total sales]
FROM 
    tblProduct p
LEFT JOIN 
    tblProductCustomer pc
ON 
    p.ProductId = pc.Productid_fk
GROUP BY 
    p.ProductName,p.ProductCost;

-- for testing
select * from tblProduct p
left join [tblProductCustomer] pc
on p.ProductId = pc.Productid_fk

-- Copilot questions:
select * from [dbo].[tblProduct]
select * from [dbo].[tblProductCustomer]
-- Write a query to retrieve the product names and the corresponding customer IDs for all products that have been purchased.

select p.ProductName,pc.CustomerId_fk from tblproduct p
join tblProductCustomer pc
on p.ProductId = pc.Productid_fk


--Write a query to retrieve all product names along with the customer IDs. If a product has not been purchased, show �No Customer� instead of the customer ID.

select ProductName, ISNULL(cast(pc.CustomerId_fk as varchar(50)),'No customer') as [customer id] from tblProduct p
left join tblProductCustomer pc
on p.ProductId = pc.Productid_fk

--Write a query to find the total sales amount for each product. If a product has no sales, show �NA� for the total sales.
select productname,
case 
when [count] = 0 then 'NA'
else cast([total sales] as varchar(50))
end
from
(select p.ProductName,count(pc.productid_fk) as [count],sum(p.ProductCost) as [total sales] from tblProduct p
left join tblProductCustomer pc
on p.ProductId = pc.Productid_fk
group by p.ProductName,p.ProductCost) as subquery


-- Write a query to find pairs of products that have the same cost.

select * from [dbo].[tblProduct]

-- wont work
select ProductName,count(*) from [dbo].[tblProduct]
group by ProductName,ProductCost
having count(*) > 0 

-- wont work
select * from tblproduct where productcost in
(select count(*) as [products count],ProductCost from tblProduct
group by ProductCost
having count(*)>1) as subquery

-- correct one
(select p1.ProductName,p2.ProductName,p1.ProductCost from tblProduct p1
join tblProduct p2
on p1.ProductCost = p2.ProductCost
where p1.ProductId < p2.ProductId)


--Write a query to find the products purchased in the year 2019 along with the customer IDs
select * from [dbo].[tblProduct]
select * from [dbo].[tblProductCustomer]

select p.ProductName,pc.CustomerId_fk,pc.SalesDate from tblProduct p
join tblProductCustomer pc
on p.ProductId = pc.Productid_fk
where YEaR(pc.SalesDate)=2019;

--Write a query to retrieve all products and their corresponding customer IDs, 
--including products that have not been purchased and customers who have not purchased any products.
select * from [dbo].[tblProduct]
select * from [dbo].[tblProductCustomer]
select * from tblCustomer

select p.ProductName, pc.CustomerId_fk from tblProduct p
left join tblProductCustomer pc
on p.ProductId = pc.Productid_fk

-- customers who haven't purchased any product

select CustomerId,CustomerName from tblCustomer where CustomerId not in(select CustomerId_fk from tblProductCustomer)

-- Write a query to find the product names and the number of times each product has been purchased
select * from [dbo].[tblProduct]
select * from [dbo].[tblProductCustomer]

select p.ProductName,count(pc.Productid_fk) as [number of sales] from tblProduct p
join tblProductCustomer pc
on p.ProductId = pc.Productid_fk
group by p.ProductName

select p.productName, (select count(*) from tblProductCustomer pc where pc.Productid_fk=p.Productid AND
p.productId Exists (select pc1.Productid_fk from tblProductCustomer pc1 where pc1.Productid_fk=p.ProductId))
from tblProduct p ;




insert into tbl_employee1 values(3,'Namani',3200,'Male')

select * from tbl_employee1

create index IX_tbl_employee1_Salary
on tbl_employee1(Salary desc)

execute sp_helpindex tbl_employee1
insert into tbl_employee values(8,'mucky','Female',3)

select *from tbl_employee


create proc spgetNameGenderbyDeptId 
@gender nvarchar(40),
@Departmentid int
as
begin
select id, name,gender,Departmentid from tbl_employee where gender = @gender and Departmentid = @Departmentid
end

spgetNameGenderbyDeptId 'Male',3

create procedure spGetEmpCountbyGender
@Gender nvarchar(30),
@Empcount int output
as
begin
	select @Empcount = COUNT(id) from tbl_employee where gender=@Gender
end

declare @TotalCount int
execute spGetEmpCountbyGender 'Male',@TotalCount output
print @TotalCount

sp_help spGetEmpCountbyGender
select *from tbl_employee

create or alter procedure spgetnamebyid
(@id int, @EmpNameRes nvarchar(50) output)
as
begin
		select @EmpNameRes= (select Emp_Name from tbl_employee where Emp_Id=@id)
	
end

declare @Response nvarchar(50)
execute spgetnamebyid @id=5, @EmpnameRes=@Response output
select @Response
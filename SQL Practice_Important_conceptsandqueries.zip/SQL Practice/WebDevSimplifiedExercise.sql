create DATABASE record_company;

use  record_company;

create table bands(id int primary key , name varchar(100));

create table albums(id int primary key, name varchar(100), release_year varchar(100), band_id int foreign key references bands(id));

create table songs (id int primary key , name varchar(100), length float, album_id int foreign key references albums(id));

create table auditForTableBands(id int identity(1,1),auditData nvarchar(100));

select * from bands;

select * from albums;

select * from songs;



-- Select only the Names of all the Bands

select name as 'Band Name' from bands;

--Select the Oldest Album

select top 1 * from albums order by release_year;

-- this will include null values too, to get rid of this write the query like below:

select top 1 * from albums
where release_year is not null
order by release_year;

--Get all Bands that have Albums

select distinct band.name as 'Band Name' from bands band
join albums 
on band.id=albums.band_id;

--Get all Bands that have No Albums

select bands.name as 'Band Name', count(albums.id) from bands 
left join albums 
on bands.id=albums.band_id
group by(bands.name)
having count(albums.id)=0;
 
-- the below query shows why we used having count and group by on above query, because if we use left join we will get all the columns from left table but for the right table for all non matching records it will be zero so simply using it:

 select bands.name as 'Band Name', count(albums.id) as 'Album Id' from bands 
 left join albums 
 on bands.id=albums.band_id
 group by(bands.name);

--Get the Longest Album

select top 1 albums.name as Name ,albums.release_year as 'Release Year', sum(songs.length) as 'Duration' from albums
join songs 
on albums.id=songs.album_id
group by albums.name, albums.release_year
order by duration desc;

--Update the Release Year of the Album with no Release Year

update albums
set release_year=1986
where release_year is null;

-- Insert a record for your favorite Band and one of their Albums

insert into albums values(19,'test',2023,7);

--Delete the Band and Album you added now

delete from bands where id=7;

-- The above code will give you error because band id 7 has a foreign key relationship with the albums table with id 19,
-- so you first remove the relationship between them,
-- The order of how you delete the records is important since album has a foreign key to band.
-- first we need to delete the album we added 19 and we need to delete the band we already have 7:

-- album deletion:

delete from albums where id=19;

-- band deletion:

delete from bands where id=7;

--Get the Average Length of all Songs

select avg(length) as 'Average song duration' from songs;

--Select the longest Song off each Album

select albums.name as Album, albums.release_year as 'Release Year', max(songs.length) as 'Duration' 
from albums
join songs
on albums.id=songs.album_id
group by albums.name, albums.release_year;

--Get the number of Songs for each Band

select bands.id, bands.name as 'Band', COUNT(songs.id) as 'Number of Songs' 
from bands
join albums
on bands.id=albums.band_id
join songs
on albums.id=songs.album_id
group by bands.name,bands.id;


-- self learning:

--view:

create view [test-view] as
select songs.name, songs.length as 'Duration' from songs
where songs.length>4;

select * from [test-view];

DROP VIEW [test-view];

--Triggers

create or alter trigger tr_bands_ForInsert
on bands
for insert
as
begin 
	declare @ID int;
	select @ID=ID from inserted;
	insert into auditForTableBands values('New Band with ID: ' + cast(@ID as nvarchar(5)) + ' is added on ' + cast(GETDATE() as nvarchar(20)))
end

insert into bands values(8,'testband');

select * from auditForTableBands;

truncate table auditfortablebands;

create or alter trigger tr_bands_ForDelete
on bands
for delete
as
begin
 declare @ID int;
 select @ID=ID from deleted;
 insert into auditForTableBands values('The Band ID: '+ cast(@ID as nvarchar(5)) + ' is deleted on ' + CAST(GETDATE() as nvarchar(25)));
end

delete from bands where id =8;
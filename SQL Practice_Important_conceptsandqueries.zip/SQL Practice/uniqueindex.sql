insert into tbl_employee3 values(1,'Deepak','Moningi',2000)
insert into tbl_employee3 values(2,'Vamsi','Lakkoju',3000)
insert into tbl_employee3 values(3,'Sarayu','Moningi',6000)
insert into tbl_employee3 values(4,'jaya','ramu',1000)
insert into tbl_employee3 values(5,'Deepak','Moningi',6000)

delete from tbl_employee3 where Salary=6000

sp_helpindex tbl_employee3

select * from tbl_employee3

drop index tbl_employee3.PK_tbl_employee3

create unique nonclustered index UIX_tblemployee3_FirstName_LastName
on tbl_employee3(FirstName,LastName)
const myform=document.querySelector('#my-form');
const nameInput=document.querySelector('#name');
const emailInput=document.querySelector('#email');
const msg=document.querySelector('.msg');
const userList=document.querySelector('#users');

// we can write event listener functions like this too..

myform.addEventListener('submit',onSubmit);
// since we are writing the event listener to submit button,
// we can write like 'submit' event directly,
// so when we click on the submit button the onSubmit() function will be executed..

function onSubmit(e){
    e.preventDefault();

    //console.log(nameInput.value);
    // this will log the value that we enter in the name input field

    // **important- form validation
    if(nameInput.value ==='' || emailInput.value === '')
    {
        msg.classList.add('error');
        msg.innerHTML='Plese fill all the fields';

        // to dissappear after 3 seconds we will use settimeout() method

        setTimeout(()=>{
            msg.remove();
        },3000)
    } else{
        // if we enter name and email correctly inside our form then:
        // after entering the name and email we are putting those two things inside the userList we declared in the line 5

        const li=document.createElement('li');
        //we need to create an list item and insert them into the DOM.
        li.appendChild(document.createTextNode(`${nameInput.value}:${emailInput.value}`));
        //we are writing inside of li, and we are adding text node,
        // in the createtextnode() we can put anything we want to ad inside the 'li'
        // if we add the things into something we can use append child,
        // this append child will add the thing to the specified element,
        // here the values of name and email is added to the li.
        

        // after that those li we need to add into the userList to display:
        userList.appendChild(li);

        // clear the fields:

        nameInput.value='';
        emailInput.value='';
    }
}

// we know that we need to pass an event parameter,
// for the functions that we are passing to the event listener.
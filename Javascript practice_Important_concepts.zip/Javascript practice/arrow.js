function addNums(num1,num2){
    return num1+num2;
}

console.log(addNums(3,2));


// now we will write the same function like arrow fn's it is very handy and it is introduced in ES6

const arrowAddnNums=(num1,num2)=>{
    return num1+num2;
}

console.log(arrowAddnNums(5,5));

/* to convert just assign the arrow fn to a variable 
and left side of arrow function will be a parameters  
and function name we need to change it as a variable.
*/
/*
by using dom-document object model
--selection concept--
we can easily selecting html things from the dom.
we can take html elements and put them into variables and we can work with them. 
*/

console.log(window);
/*
  window object is the parent object for the browser
  if we do like this we can see all the properties and methods that window object/class provides in the console.
  famous methods like fetch to make http requests,
  alert- it will produce a popup in the ui page,
  document- by using this we can select things from the document,
  localstorage
*/

// single element selectors
console.log(document.getElementById('my-form'));
// document is what we want to use to select things from the document(dom) rendered HTML.
// here we are taking the id from the html for my form. It will log that element(form) into the console.
// we will get entire form like html in the console.

console.log(document.querySelector('.container'));
// previously people used jquery that made it easy to select other things than id, so for things like classes, tags, we can use quesry selector for this,
// this query selector works jus like jquery for selecting single element slector.
// this is also a single element selector but it can select html classes, other elements too.
// as this is a single element selector it will only select first one/first occurance in html document.
//eg:

console.log(document.querySelector('h1'));
// it will only log the first h1 element in the html doc, it will not search for other h1's in the document


//mutliple element selector
console.log(document.querySelectorAll('.item'));

console.log(document.getElementsByClassName('item'));

/*
The difference between both 31 and 33 line codes are:
for queryselector we need to pass . with the element like .item because it can select id element, class element and so on..
and main thing is it will return Nodelist it is similar to array only and we can perform array operations too..

for the elementby class name() we can pass without . bcz any way we know that we are passing the class to it so .item is no need we can directly pass a class name like item.
and it will return HTML collection and we can't do array oprations on it,
if we want to do func kind of things then we need to manually convert htmt collection to array collection.
*/

// looping through elements in the dom

const items=document.querySelectorAll('.item');

items.forEach((item)=>{
    console.log(item);
})


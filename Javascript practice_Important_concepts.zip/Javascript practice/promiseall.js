/* 
Promise all, it is useful when we have a lot of different promises, 
we don't need to write .then aand .then for every promise if we use promise.all,
*/

const promise1=new Promise((resolve,reject)=>{
    //if(!true){
    if(true){
        resolve("Hello wolrd");
    }
    else{
        reject("Rejected");
    }
})

const promise2 = 10;

const promise3= new Promise((resolve, reject)=>{
    setTimeout(()=>{
        //if(!true){
        if(true){
            resolve("Good bye");
        }else{
            reject("Something went wrong");
        }
    },2000)
})

const promise4= fetch("https://jsonplaceholder.typicode.com/users")
.then((response)=>{
    return response.json();
    //If we use fecth in Javascript first we need to format it,
    //we need to convert the result to json what we get from api before utilizing it
})
/* 
Now we need to call all the promises,
and we need to pass what are the promises we want to call inside a array and we need to pass that array to promise.all method.
*/

Promise.all([promise1,promise2,promise3,promise4])
.then((values)=>{
    console.log(values);
})
.catch((errors)=>{
    console.log(errors);
})

/* 
Here the ouptput is only rejected but what we expect the output is rejected, 10,something went wrong,
but promises not work like that,
It will work like if any one of the promises in array rejects then the promise.all immediately rejects with the reason of the first promise,
promise.all will execute the .then() method only if all the promises are resolved,
if anyone of the promise is not resolved then it will reject and return the reject response of the first promise.
*/
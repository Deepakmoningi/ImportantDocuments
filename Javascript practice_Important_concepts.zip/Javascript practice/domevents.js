// we can actually listen to an event after event completion.

const btn=document.querySelector('.btn');

btn.addEventListener('click',(e)=>{
    e.preventDefault();
    console.log(e);
    // e is event object
    console.log(e.target.class);// it will give btn whcih is a button class in html
    //this will log the buttons class of the button.
    console.log(e.target);// it will give html element for that button
    // this will actually give the html element that the event is on, we can find  this target in the console.

    document.querySelector('#my-form').style.background='#ccc';
    // this will change form color to dark grey when we click on button, we get the form id and changing the form background..

    document.querySelector('body').classList.add('bg-dark');
    // this is very important because here we are fetching the body element from html
    // and adding the style we wrote using a class in css for entire body.
    // same time we are using three files components js,html,css..
    // once we click on button it will first change the form color and then it will change the body color based on css class style. 
});

/*for event listener() function we need to pass two arguments 
one is which event we want to listen.
another one is a callback function that we want to be  called  after the event completion,
what we specified here(click-mouse click) the function will execute..
when we using event the function requires event parameter too so i mentioned as 'e'
for the 6th line code we actually submitting a form submission using that button class(.btn),
so we need to stop the default behaviour to see the click event that we are logging in the console..
*/



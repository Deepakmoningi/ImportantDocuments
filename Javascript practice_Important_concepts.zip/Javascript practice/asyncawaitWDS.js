/* 
Web Dev Simplified
*/

// first we will see with promises
// after we will convert the same code to async and await

function makeRequest(host){
    return new Promise((resolve,reject)=>{
        console.log(`Making request to ${host}`);
        if(host==="Google"){
            resolve("Google says Hi");
        }
        else{
            reject("We can only make request to Google")
        }
    })
}

function processResponse(response){
    return new Promise((resolve,reject)=>{
        console.log("Processing the response");
        resolve(`Extra Information: ${response}`)
    })
}

// makeRequest("Google")
// .then((response)=>{
//     console.log("response received");
//     return processResponse(response);
// })
// .then((processedResponse)=>{
//     console.log(processedResponse);
// })
// .catch((err)=>{
//     console.log(err);
// })

// this single catch block can handle reject callbacks from the two promise functions above.

/* 
Here in line 30 we actually used promis chaining,
what it will do is every .then method can return a promise so we returned a promise here,
here we are calling the processResponse and passing the response to it ,
How Javascript will execute this means, as we returning the promise in first then() it will chain the first then() and second then() methods,
Here processResponse is returned from the first then() call back,
This causes the second then() needs to wait for processResponse promise to resolve before executing,
meaning once the processResponse on line number 30 resolves then only it will call or execute the second.then(), this is also like a normal promise only.
The main purpose for this promise chaining is to sequence asynchronous operations.
*/

// Now the same example we will write using async and await

async function tryAsync(){
    try{
    console.log("This is from Async");
    const response= await makeRequest("FB");
    console.log("Response received");// if js will execute this line means js executed the 56th line because of async
    // Javascript will run the 57th line in background and it will return the response when it got and assign it to the response variable,
    // This is called asynchronous programming 
    // why we are mentioning this is we used promise chaining to get async and sequention excution for our code,
    // so by using this async and await also is in sequential and async.
    // meaning once the make request() execution will run on background meanwhile js will execute other code,
    // once makerequest is completed it will assign the response to response variable and then it will complete the processResponse
    const test= await processResponse(response);
    console.log(test);
    }
    catch(err){
        console.log(err);
    }
    

}

tryAsync();

/* 
Things we need to make sure while using aync/await:
we must wrap our code inside the function like we did in 54th line,
we must name that function with async keyword at the beggining at the function definition,
we must use await keyword before all of our code that is going to be asynchronous other wise it will only return the promise insted of actual result of the promise executed.
*/
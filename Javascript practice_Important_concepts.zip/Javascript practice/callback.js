const posts=[
    {title:'Post one', body:'This is Post one'},
    {title:'Post two', body:'This is Post two'},
];

// we will write a function to get this above posts and display on html
function getPosts(){
    // we are trying to make posts are coming from the server if posts were coming from the server it will take one second so we will write set timout method.
    // settimeout is a asynchronous function:
    setTimeout(() => {
       let output;
       posts.forEach((post)=>{
        output=output+ `<li>${post.title}</li>`;
       });
       document.body.innerHTML=output;
    }, 1000);
    // () =>{ } this is the arrow function and if we want we can write normal function at there but arrow fn is ES6 style.
    // after 1000 milliseconds the browser will load the two posts to give a feel that posts are coming from the server.
}


// function to create a post after 2000 milliseconds
function createPost(post, callback){
    setTimeout(()=>{
        posts.push(post);
        callback();
    },2000);

}

createPost({title:'post three', body:'This is post three'},getPosts)

console.log(posts);
/*
Here browser only displays two posts only even we added another post this is happened because
create post took more time than get post before creating the post the get post is complted and DOM is printed(html is rendered) and we can't do anything beyond this point.
Third post is added to the posts array but it is not rendered.
So, here the callback function come into picture for asynchronous programming.
we can write/ pass call back function to the createPost() function and we can make getPosts() method as a call back fn in the createPost() fun.
Here in the createPost we have added callback(we can add whatever we want) and we are calling the function(getPosts()) in line 26 with callback(),
By calling of createPost function we need to post which method should be call backed so we passed getPosts() while calling,
*What happened is after pushing the new post into the posts array, it dont need to wait for the CreatePost to complete 3 seconds to complete.
paralelly happening- meaning post is creating at the same time posts are fecting and both are happening at the same time.
As we wrote setTimeout() for create post it will call callback function(getposts()) after the timeout completion only..
*/


/*
Why we need to use call back?
best example to acheive asynchronous programming
*/

// best example
// here settimeout will take call back function

// console.log('start');
// setTimeout(function(){
//     console.log('hello JS')
// },3000);
// console.log('end');

// if we run this the output will be:
/*
start
end
hello js

here 56th line will be executed after that 60th also will be executed and after that 
57 to 59 number line codes will be executed it will run on background meanwhile remaining lines of code will be executed. It will not block the remaining code execution.  
perfect example for asynchronous programming.
*/
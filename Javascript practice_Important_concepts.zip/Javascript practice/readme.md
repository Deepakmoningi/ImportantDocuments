**order**:

arrows,
callbacks,
higher order array methods/functions,
promises,
promises.all,
async/await,
async/awaitWDS,
dom
dom manipulation
dom event
dom form

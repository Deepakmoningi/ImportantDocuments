const posts=[
    {title:'Post one', body:'This is Post one'},
    {title:'Post two', body:'This is Post two'},
];

function getPosts(){
    setTimeout(() => {
       let output='';
       posts.forEach((post)=>{
        output=output+ `<li>${post.title}</li>`;
       });
       document.body.innerHTML=output;
    }, 1000);
}

function createPost(post){
    // here at promise method arguments we need to write a function, and we are writing arrow function here..
    //and we need to two important arguments to the function:
    //resolve- when we want to resolve a promise successfully we can call resolve(),
    //reject - if something goes wrong we can call reject.

    return new Promise((resolve,reject)=>{
        setTimeout(()=>{
            posts.push(post);

        const error=false;

        if(!error){
            resolve();
        }else{
            reject("something went wrong in promise");
        }
        },2000)
    })
}

//getPosts();
createPost({title:'post 3', body:'this is post 3'})
.then(getPosts)
.catch(error=>console.log(error));




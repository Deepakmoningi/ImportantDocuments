const posts=[
    {title:'Post one', body:'This is Post one'},
    {title:'Post two', body:'This is Post two'},
];

// we will write a function to get this above posts and display on html
function getPosts(){
    // we are trying to make posts are coming from the server if posts were coming from the server it will take one second so we will write set timout method
    setTimeout(() => {
       let output='';
       posts.forEach((post)=>{
        output=output+ `<li>${post.title}</li>`;
       });
       document.body.innerHTML=output;
    }, 1000);
    // () =>{ } this is the arrow function and if we want we can write normal function at there but arrow fn is ES6 style.
    // after 1000 milliseconds the browser will load the two posts to give a feel that posts are coming from the server.
}

// promises
// new promise(res,rej) to create a promise
//resolve and reject are callback functions
// function to create a post after 2000 milliseconds
function createPost(post){
    return new Promise((resolve,reject)=>{
        setTimeout(()=>{
            posts.push(post);

            // to resolve the promise creating a variable for general checking like error checking..

            const error =false;

            // if there is no error in the promise then we aee calling resolve
            if(!error){
                resolve();
            }
            // if any error is there then we are calling reject
            else{
                reject('Something went wrong');
            }
        },2000);

    })
}


/*
Here in line 25 promise takes a call back function and we can write arrow function using es6 and it takes two parameters,
resolve, reject.
resolve- when we want to resolve a promise successfully we can call resolve(),
reject - if something goes wrong we can call reject.
what we doing is we wrote set timeout so we need to wait for 2 seconds and then add the post and then check for any error if not then calling resolve and then calling getPosts method.
*/


// calling create post with promise
// we have not written any call back function after post object because create post function is returning a promise now..
// so we need to use .then() syntax
createPost({title:'Post three', body:'This is post three'})
// if promise is resolved then only .then() will execute ore else . catch() will come into action..
.then(getPosts)
.catch(err=>console.log(err));
// if there is any error in the promise to deal with that we need to write catch here and do whatever we want..
const posts = [
    {title:'Post one', body:'This is Post one'},
    {title:'Post two', body:'This is Post two'},
]


function getPosts(){
    setTimeout(()=>{
        let output='';
        posts.forEach((post)=>{
            output=output+`<li>${post.title}</li>`
        })
        document.body.innerHTML=output;
    },1000)
}

// getPosts();

// addPost({title:'Post three', body:'This is Post three'});

// function addPost(post){
//     setTimeout(()=>{
//         posts.push(post);
//     },2000);
// }

// here addpost is taking more time that getpost method,
//by the completion of addpost() method the get posts() method is completed and ecxecuted,
// meaning DOM is printed(HTML is renderred) and beyond this we can't do anything.
// even the post is added to the posts array but it will not rendered in the browser bcoz html is printed before execution of addPost() method.
// to overcome this we need to make our code asynchronous and java script offers us callback functions to acheive asynchronous behavoiur.

// writing the same code using call back function:

function addPostWithCallBack(post,callback){
    setTimeout(() => {
        posts.push(post);
        callback();
    }, 2000);
}

addPostWithCallBack({title:'Post three', body:'This is Post three'},getPosts);
// we can actually manipulate or changing things in the DOM.
// DOM is a ui that we are seeing in the localhost screen.

const ul=document.querySelector('.items');

//ul.remove();
// it will remove entire items which are class associated things from the DOM.

ul.firstElementChild.textContent='Hello';
// it will replace with the html text with the Hello for the first list item.

ul.children[1].textContent='Deepak';
// as this is a node list we can access ul list elements with children and indexes.
// we can use innerText property also instead of textContent.

ul.lastElementChild.innerHTML='<h1>Good evening</h1>';
// we can add html dynamically to a element/list item in ul, we can do this thing also using JS
// if we want to add a html dynamically then we need to use innerHtml.

const btn=document.querySelector('.btn');

btn.style.background='red';
// what we did here is we fetched button using its class from html and we are changing the button background in js file using queryselector.


const posts=[
    {title:'Post one', body:'This is Post one'},
    {title:'Post two', body:'This is Post two'},
];

// we will write a function to get this above posts and display on html
function getPosts(){
    // we are trying to make posts are coming from the server if posts were coming from the server it will take one second so we will write set timout method
    setTimeout(() => {
       let output='';
       posts.forEach((post)=>{
        output=output+ `<li>${post.title}</li>`;
       });
       document.body.innerHTML=output;
    }, 1000);
    // () =>{ } this is the arrow function and if we want we can write normal function at there but arrow fn is ES6 style.
    // after 1000 milliseconds the browser will load the two posts to give a feel that posts are coming from the server.
}

// promises
// new promise(res,rej) to create a promise
//resolve and reject are callback functions
// function to create a post after 2000 milliseconds
function createPost(post){
    return new Promise((resolve,reject)=>{
        setTimeout(()=>{
            posts.push(post);

            // to resolve the promise creating a variable for general checking like error checking..

            const error =false;

            // if there is no error in the promise then we aee calling resolve
            if(!error){
                resolve();
            }
            // if any error is there then we are calling reject
            else{
                reject('Something went wrong');
            }
        },2000);

    })
}

/* 
Async await are same like promises, 
async and await was introduced in ES7, this will deal with promises only but in a different way.
async and await are way to handle responses,
for this we must need a function that labeled await before the function name
*/

/* 
This function must be lableled as async then only we can use await inside the function while calling the api,
awaits, it waits for asynchronous process or action to complete
*/
async function init(){
    await createPost({title:"Post three", body:"This is Post three"});

    getPosts();
}

init();

/* 
Here what js will do is, it will wait for createpost to be done,
once the createpost is done with it's execution then only it will call getPosts(),
once the Javascript hits this await fetch method what it will do is leave that function and Javascript will execute other methods or code inside the program,
once the fetch method execution completed meaning once we get data from the api, Javascript will comeback to line 77 and returns the result into the variable res.
here we dont need to use promises to handle this.
This is more elegant way to use promises in Javascript
*/

// implementing fetch api call using async and await

async function getUsers(){
    const res= await fetch("https://jsonplaceholder.typicode.com/users");

    const data =await res.json();
    console.log(data);
}

getUsers();

/* 
Here we are doing the same what we did in promiseall.js file for promise 4,
we are fetching the data from the api,
even this await will return a promise to res variable but we can't use .then and .catch,
so, we can directly convert that response came from api to json and log that,
using async and await the code looks better when compared to promises. 
*/



/*
Highorder array methods
foreach- loops through the given array
map - allows us to create a new array from an array
filter - allows us to create a new array from an array based on a condition
*/

// these are very powerful bcoz it deals with functional programming.


const todos=[
    {
        id:1,
        text:'learn daily',
        isCompleted: false
    },
    {
        id:2,
        text:'eat badam daily',
        isCompleted: true
    },
    {
        id:3,
        text:'eat food daily',
        isCompleted: true
    }
];


/*This highorder array methods will take function as a parameters,
here we are passing function as a parameter to foreach array method 
and that function is a callback function.
SO for every todo in the todos array this callback function will be called and executed 
*/

// todos.forEach(function(todo){
//     console.log(todo.text);
// })

// we can rewrite the same thing using arrow function like ES6
// this will give same output too

todos.forEach((todo)=>{
    console.log(todo.text);
})

// map: it exeutes a provided call back function for each element in the array 
const todoText= todos.map(function(todo){
    return todo.text;
})

console.log(todoText);

// filter
const todoCompleted=todos.filter(function(todo){
    return todo.isCompleted === true;
})

console.log(todoCompleted);

// filter plus map

const todosCompleted=todos.filter(function(todo){
    return todo.isCompleted === true;
}).map(function(todo){
    return todo.text;
})

console.log(todosCompleted);
